CREATE TABLE "t_version" ("value" INTEGER, "desc" TEXT);

CREATE TABLE "t_binary" ("id" INTEGER PRIMARY KEY, "name" TEXT, "system" INTEGER, "parent_id" INTEGER);

CREATE INDEX "t_binary_parent_id" ON t_binary (parent_id);

CREATE TABLE "t_constant" ("id" INTEGER PRIMARY KEY, "value" TEXT, "binary_id" INTEGER);

CREATE INDEX "t_constant_binary_id" ON t_constant (binary_id);

CREATE TABLE "t_local_file" ("id" INTEGER PRIMARY KEY, "path" TEXT, "update_time" INTEGER, "size" INTEGER, "binary_id" INTEGER, "system" INTEGER);

CREATE INDEX "t_local_file_binary_id" ON t_local_file (binary_id);

CREATE TABLE "t_meta_data" ("id" INTEGER PRIMARY KEY, "value" TEXT, "type" INTEGER, "binary_id" INTEGER, "parent_id" INTEGER);

CREATE INDEX "t_meta_data_binary_id" ON t_meta_data (binary_id);

CREATE INDEX "t_meta_data_parent_id" ON t_meta_data (parent_id);

CREATE TABLE "t_symbol" ("id" INTEGER PRIMARY KEY, "value" TEXT, "binary_id" INTEGER, "type" INTEGER);

CREATE INDEX "t_symbol_binary_id" ON t_symbol (binary_id);

INSERT INTO "t_version" VALUES(1, "start");