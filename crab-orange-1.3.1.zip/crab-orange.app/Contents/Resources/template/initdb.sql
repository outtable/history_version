CREATE TABLE "t_activity_code" ("Id" INTEGER PRIMARY KEY AUTOINCREMENT, "user" TEXT, "product_type" TEXT, "valid_date" DATE, "listen_file_data" BLOB, "product_code" TEXT, "bundle_identifier" TEXT, "main_bundle_identifier" TEXT, "language" INTEGER, "unique_id" TEXT, "plan_keys" INTEGER, "parent_id" INTEGER, "device_id" TEXT,  "plan_key" TEXT, "valid_product_code" TEXT, "rand_seed" INTEGER);

CREATE TABLE "t_archive_file" ("id" INTEGER PRIMARY KEY AUTOINCREMENT, "name" TEXT, "bundle_id" INTEGER, "target_id" INTEGER);

CREATE INDEX "i_archive_file_name" on t_archive_file(name);

CREATE TABLE "t_bundle" ("id" INTEGER PRIMARY KEY AUTOINCREMENT UNIQUE, "name" TEXT, "version" INTEGER);

CREATE TABLE "t_constant" ("id" INTEGER PRIMARY KEY AUTOINCREMENT, "string_id" INTEGER, "bundle_id" INTEGER, "target_id" INTEGER, "object_file_id" INTEGER, "tag_id" INTEGER);

CREATE TABLE "t_constant_new_value" ("string_id" INTEGER, "new_value" TEXT, "bundle_id" INTEGER);

CREATE INDEX "i_constant_new_value_string_id" on t_constant_new_value(string_id);

CREATE TABLE "t_exclude_link_file" ("id" INTEGER PRIMARY KEY AUTOINCREMENT, "file" TEXT, "target_id" INTEGER);

CREATE INDEX "i_exclude_link_file_file" on t_exclude_link_file(file);

CREATE TABLE "t_export_file" ("id" INTEGER PRIMARY KEY AUTOINCREMENT, "name" TEXT, "crc32" INTEGER, "last_modifier_time" TEXT, "bundle_id" INTEGER);

CREATE INDEX "i_export_file_name" on t_export_file(name);

CREATE TABLE "t_export_symbol" ("id" INTEGER PRIMARY KEY AUTOINCREMENT, "string_id" INTEGER, "tag_id" INTEGER, "export_file_id" INTEGER);

CREATE TABLE "t_file_group" ("id" INTEGER PRIMARY KEY AUTOINCREMENT UNIQUE, "prefix" TEXT, "new_prefix" TEXT, "bundle_id" INTEGER);

CREATE TABLE "t_file_rename" ("id" INTEGER PRIMARY KEY AUTOINCREMENT, "file_name" TEXT, "new_name" TEXT, "bundle_id" INTEGER, "kind" INTEGER);

CREATE INDEX "i_file_rename_name" on t_file_rename(file_name);

CREATE TABLE "t_input_link_file" ("id" INTEGER PRIMARY KEY AUTOINCREMENT, "file" TEXT, "target_id" INTEGER);

CREATE TABLE "t_object_dir" ("id" INTEGER PRIMARY KEY AUTOINCREMENT, "path" TEXT, "archive_file_id" INTEGER, "arch_type" INTEGER);

CREATE TABLE "t_object_file" ("id" INTEGER PRIMARY KEY AUTOINCREMENT, "name" TEXT, "bundle_id" INTEGER, "target_id" INTEGER);

CREATE INDEX "i_object_file_name" on t_object_file(name);

CREATE TABLE "t_source_map_file" ("id" INTEGER PRIMARY KEY AUTOINCREMENT, "file" TEXT, "target_id" INTEGER);

CREATE TABLE "t_string" ("id" INTEGER, "value" TEXT, "bundle_id" INTEGER);

CREATE INDEX "i_string_id" on t_string(id);

CREATE INDEX "i_string_id_and_bundle_id" on t_string(id,bundle_id);

CREATE INDEX "i_string_value" on t_string(value);

CREATE TABLE "t_symbol" ("id" INTEGER, "string_id" INTEGER, "bundle_id" INTEGER, "version" INTEGER, "tag_id" INTEGER);

CREATE TABLE "t_symbol_rename" ("string_id" INTEGER, "new_name" TEXT, "bundle_id" INTEGER, "tag_id" INTEGER);

CREATE INDEX "i_symbol_rename_string_id" on t_symbol_rename(string_id);

CREATE TABLE "t_tag" ("id" INTEGER PRIMARY KEY AUTOINCREMENT, "name" TEXT);

CREATE TABLE "t_target" ("id" INTEGER PRIMARY KEY AUTOINCREMENT, "name" TEXT, "bundle_id" INTEGER, "version" INTEGER);

CREATE TABLE "t_version" ("value" INTEGER, "desc" TEXT);

CREATE TABLE "t_warning" ("id" INTEGER PRIMARY KEY AUTOINCREMENT, "source_file_id" INTEGER, "message" TEXT, "group_name" TEXT, "status" INTEGER, "lineno" INTEGER, "code" TEXT);

CREATE TABLE "t_match_string" ("id" INTEGER PRIMARY KEY AUTOINCREMENT, "source_file_id" INTEGER, "value" TEXT, "type" TEXT, "status" INTEGER);

CREATE TABLE "t_exclude_member" ("id" INTEGER PRIMARY KEY AUTOINCREMENT, "source_file_id" INTEGER, "class_name" TEXT, "status" INTEGER);

CREATE INDEX "i_match_string_value" on t_match_string(value);

CREATE INDEX "t_exclude_member_class_name" on t_exclude_member(class_name);

CREATE TABLE "t_source_file" ("id" INTEGER PRIMARY KEY AUTOINCREMENT, "name" TEXT, "bundle_id" INTEGER, "target_id" INTEGER);

CREATE INDEX "i_source_file_name" on t_source_file(name);

CREATE TABLE "t_backup_file" ("id" INTEGER PRIMARY KEY AUTOINCREMENT, "bundle_id" INTEGER, "filename" TEXT, "backup" TEXT);

CREATE TABLE "t_temp_file" ("id" INTEGER PRIMARY KEY, "bundle_id" INTEGER, "filename" TEXT);

CREATE TABLE "t_path_map" ("id" INTEGER, "path" TEXT, "newpath" TEXT, "bundle_id" INTEGER, "target_id" INTEGER, "type" INTEGER);

INSERT INTO "t_version" VALUES(1, "start");

CREATE INDEX "i_symbol_tag_id" ON t_symbol (tag_id);

CREATE INDEX "t_constant_bundle_id" ON t_constant (bundle_id);

CREATE INDEX "t_constant_target_id" ON t_constant (target_id);

CREATE INDEX "t_constant_new_value_bundle_id" ON t_constant_new_value (bundle_id);

CREATE INDEX "t_file_rename_bundle_id" ON t_file_rename (bundle_id);

CREATE INDEX "t_match_string_source_file_id" ON t_match_string (source_file_id);

CREATE INDEX "t_object_file_bundle_id" ON t_object_file (bundle_id);

CREATE INDEX "t_path_map_bundle_id" ON t_path_map (bundle_id);

CREATE INDEX "t_path_map_target_id" ON t_path_map (target_id);

CREATE INDEX "t_source_file_bundle_id" ON t_source_file (bundle_id);

CREATE INDEX "t_source_file_target_id" ON t_source_file (target_id);

CREATE INDEX "t_symbol_bundle_id" ON t_symbol (bundle_id);

CREATE INDEX "t_string_bundle_id" ON t_string (bundle_id);

CREATE INDEX "t_symbol_rename_bundle_id" ON t_symbol_rename (bundle_id);

CREATE INDEX "t_temp_file_bundle_id" ON t_temp_file (bundle_id);

CREATE INDEX "t_export_file_bundle_id" ON t_export_file (bundle_id);

CREATE INDEX "t_export_symbol_export_file_id" ON t_export_symbol (export_file_id);

CREATE INDEX "t_warning_source_file_id" ON t_warning (source_file_id);

CREATE TABLE "t_configs" ("bundle_id" INTEGER, "name" TEXT, "value" TEXT);