#!/usr/bin/python
# -*- coding: UTF-8 -*-

import sys
import os
import confuse_utils
import json
import shutil
import datetime

abs_file_path = os.path.abspath(__file__)
exe_dir = abs_file_path[0:abs_file_path.rfind('/')]

def all_pairs(path, dict):
	temp = []
	result = []
	items = path.split('/')
	result.append(items)
	if len(items) == 1:
		if items[0] in dict:
			newvalue = dict[items[0]]
			result.append([newvalue])
	for i in range(1, len(items) + 1):
		temp = []
		cur = '/'.join(items[0:i])
		if cur in dict:
			newvalue = dict[cur]
			paths = items[:]
			paths[i - 1] = newvalue.split('/')[-1]
			result.append(paths)
			temp.append(paths)

	for i in range(0, len(temp)):
		paths = temp[i][:]
		for j in range(0, len(paths) - 1):
			paths[j] = paths[j + 1]
			result.append(paths)
	return result

def get_dat_file_path(workspace_dir, package_dir):
	depend_files = confuse_utils.read_settings_file(package_dir + '/depend_files.txt')

	if 'cosdk' in depend_files:
		oldcat_items = depend_files['cosdk']

	old_cat_dat_path = ''
	for item in oldcat_items:
		if item.endswith('.dat'):
			old_cat_dat_path = '%s/%s' % (workspace_dir, item.replace('{..}/', '../'))
	return old_cat_dat_path

def load_confuse_type(package_dir, result):
	filename = '%s/default_script.txt' % package_dir
	script_settings = confuse_utils.read_settings_file('%s/default_script.txt' % package_dir)
	#获取所有需要处理的文件后缀
	resource_suffixs = script_settings['resource-suffixs']
	for suffix in resource_suffixs:
		pairs = suffix.split('=')
		name = pairs[0].strip()
		value = pairs[1].strip()
		exts = value.split('|')
		for ext in exts:
			result[ext[1:]] = True

def get_date_time():
	cur = datetime.datetime.now().date()
	return '%s' % cur

def gen_path_map(work_dir, bundle_id, main_project_file, target_name, configure, workspace_dir, dat_file):
	print('##gen path map %s##' % (target_name))
	new_target_name = confuse_utils.get_symbol_new_name(work_dir, bundle_id, target_name, 'target')
	package_dir = '%s/packages/%s' % (work_dir, bundle_id)
	archive_path = '%s/%s.xcarchive' % (package_dir, target_name)
	app_build_settings = confuse_utils.get_build_settings(work_dir, bundle_id, main_project_file, configure, target_name, use_cache_file=True)
	app_product_file = confuse_utils.get_build_settings_value(app_build_settings, 'FULL_PRODUCT_NAME', '')
	app_path = '%s/Products/Applications/%s' % (archive_path, app_product_file)
	fixupDict = confuse_utils.get_fixup_path_map(work_dir, bundle_id, target_name, False)
	tempDict = {}
	keys = list(fixupDict.keys())
	for key in keys:
		value_pairs = all_pairs(fixupDict[key], fixupDict)
		key_pairs = all_pairs(key, fixupDict)
		for key_pair in key_pairs:
			if len(key_pair) > 1:
				curkey = '/'.join(key_pair)
			else:
				curkey = key_pair[0]
			for value_pair in value_pairs:
				if len(value_pair) > 1:
					curvalue = '/'.join(value_pair)
				else:
					curvalue = value_pair[0]
				if curkey != curvalue:
					tempDict[curkey] = curvalue
	
	idmap = confuse_utils.get_all_rename_map(work_dir, bundle_id, False)

	objcClassDict = {}
	objcProtocolDict = {}
	objcSelectorDict = {}
	objcIvarDict = {}
	objcPropertyDict = {}
	confuseTypeDict = {}
	swiftRecordDict = {}

	load_confuse_type(package_dir, confuseTypeDict)
	keys = list(idmap.keys())
	for key in keys:
		if key.endswith('<objcinterface>'):
			objcClassDict[key[:-15]] = idmap[key]
		elif key.endswith('<swiftrecord-meta>'):
			objcClassDict[key[:-18]] = idmap[key]
		elif key.endswith('<swiftprotocol-meta>'):
			objcProtocolDict[key[:-20]] = idmap[key]
		elif key.endswith('<swiftrecord>'):
			swiftRecordDict[key[:-13]] = idmap[key]
		elif key.endswith('<objcprotocol>'):
			objcProtocolDict[key[:-14]] = idmap[key]
		elif key.endswith('<objcmethod>'):
			objcSelectorDict[key[:-12]] = idmap[key]
		elif key.endswith('<objcivar>'):
			objcSelectorDict[key[:-10]] = idmap[key]
		elif key.endswith('<objcproperty>'):
			objcPropertyDict[key[:-14]] = idmap[key]
	
	settingsDict = {}
	settingsDict['debug'] = confuse_utils.get_run_settings_value(work_dir, bundle_id, 'debug-mode', False)
	settingsDict['fixupEnabled'] = confuse_utils.get_run_settings_value(work_dir, bundle_id, 'replace-main', False)

	bundle_info = confuse_utils.fetch_bundle_activite_code(bundle_id)
	settingsDict['validProductCode'] = bundle_info['valid_product_code']
	settingsDict['uniqueId'] = bundle_info['unique_id']
	settingsDict['randSeed'] = confuse_utils.get_seed_key(package_dir)
	settingsDict['buildDate'] = get_date_time()

	jsonDict = {}
	jsonDict['fixup'] = tempDict
	jsonDict['route'] = confuse_utils.get_route_path_map(work_dir, bundle_id, target_name, False)
	jsonDict['image-name'] = confuse_utils.get_image_name_path_map(work_dir, bundle_id, target_name, False)
	jsonDict['objc-class'] = objcClassDict
	jsonDict['swift-record'] = swiftRecordDict
	jsonDict['objc-protocol'] = objcProtocolDict
	jsonDict['objc-selector'] = objcSelectorDict
	jsonDict['objc-ivar'] = objcIvarDict
	jsonDict['objc-property'] = objcPropertyDict
	jsonDict['confuse-type'] = confuseTypeDict
	jsonDict['settings'] = settingsDict

	print('#### fixup ####')
	for key in list(tempDict.keys()):
		print('%s => %s' % (key, tempDict[key]))
	
	print('#### route ####')
	itemDict = jsonDict['route']
	for key in list(itemDict.keys()):
		print('%s => %s' % (key, itemDict[key]))

	print('#### image-name ####')
	itemDict = jsonDict['image-name']
	for key in list(itemDict.keys()):
		print('%s => %s' % (key, itemDict[key]))

	print('#### objc-class ####')
	itemDict = jsonDict['objc-class']
	for key in list(itemDict.keys()):
		print('%s => %s' % (key, itemDict[key]))

	print('#### swift-record ####')
	itemDict = jsonDict['swift-record']
	for key in list(itemDict.keys()):
		print('%s => %s' % (key, itemDict[key]))

	print('#### objc-protocol ####')
	itemDict = jsonDict['objc-protocol']
	for key in list(itemDict.keys()):
		print('%s => %s' % (key, itemDict[key]))
	
	print('#### objc-selector ####')
	itemDict = jsonDict['objc-selector']
	for key in list(itemDict.keys()):
		print('%s => %s' % (key, itemDict[key]))

	print('#### objc-ivar ####')
	itemDict = jsonDict['objc-ivar']
	for key in list(itemDict.keys()):
		print('%s => %s' % (key, itemDict[key]))

	print('#### confuse-type ####')
	confuseTypeDict = jsonDict['confuse-type']
	for key in list(confuseTypeDict.keys()):
		print('%s => %s' % (key, confuseTypeDict[key]))

	dat_file_path = get_dat_file_path(workspace_dir, package_dir)

	if len(dat_file_path) == 0:
		print('not found *.dat file in build settings.')
		sys.exit(1)
	
	app_dat_path = '%s/%s' % (app_path, dat_file)

	if not os.path.exists(dat_file_path):
		print('not found %s' % dat_file_path)
		sys.exit(1)

	if os.path.exists(app_dat_path):
		os.remove(app_dat_path)
	shutil.copy(dat_file_path, app_dat_path)
	
	with open(app_dat_path, 'ab') as f:
		f.write(json.dumps(jsonDict).encode('utf-8'))

	pass

def main(argv):
	confuse_utils.print_cmd(argv)
	if len(argv) != 8:
		print('python gen_path_map.py [work dir] [bundle id] [main project file] [target name] [configure] [workspace dir] [dat file]')
		sys.exit(1)
	gen_path_map(argv[1], argv[2], argv[3], argv[4], argv[5], argv[6], argv[7])

main(sys.argv)
