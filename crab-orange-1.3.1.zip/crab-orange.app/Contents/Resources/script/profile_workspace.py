#!/usr/bin/python
# -*- coding: UTF-8 -*-

import sys
import os

from pbxproj import XcodeProject
import confuse_utils
import json
import struct
import sqlite3
from xml.dom.minidom import parse
import xml.dom.minidom
import hmap
import shutil
import threading
import importlib

importlib.reload(sys)
#sys.setdefaultencoding("utf-8")

FILE_MASK_RENAME = 1

FILE_MASK_CONFUSE = 2

FILE_MASK_INFLATE = 4

MACH_O_TYPE_DYNAMIC = 'mh_dylib'

PRODUCT_TYPE_FRAMEWORK = 'com.apple.product-type.framework'

all_folder_suffix = {}

all_file_suffix = {}

type_suffixs = {}

language_suffixs = {}

source_suffix_items = []

code_types = []

all_file_map = {}

source_code_map = {
	'sourcecode.c.c' : '.c', 
	'sourcecode.c.objc' : '.m',
	'sourcecode.cpp.cpp' : '.cpp',
	'sourcecode.cpp.objcpp' : '.mm',
	'sourcecode.swift' : '.swift'
}

#exclude_source_file_type = ['.swift']

workspace_project_infos = []
workspace_project_ref_products = {} #某个工程依赖的目标文件
workspace_project_ref_targets = {} #某个工程依赖的外部targets
workspace_project_new_products = {} #某个工程会生成的所有文件
workspace_project_embed_files = {} #某个工程需要拷贝的编译参数
workspace_valid_infos = {} #用于做一些验证

project_references = []

def get_file_type(filepath):
	idx = filepath.rfind('.')
	if idx == -1:
		return '.[None]'
	#ret = filepath[idx:].lower()
	ret = filepath[idx:]
	if ret.rfind('/') != -1:
		return '.[None]'
	return ret

exclude_file_types = ['.xcconfig']

def get_file_flag(filetype, filepath):
	flag = 0

	if filetype == '.xcdatamodeld':
		if confuse_utils.is_confuse_include(filetype, filepath) and (filetype in all_folder_suffix) == False:
			flag = flag | FILE_MASK_CONFUSE
		return flag
		
	if filetype in all_file_suffix:
		if confuse_utils.is_rename_include(filetype, filepath):
			flag = FILE_MASK_RENAME
		if confuse_utils.is_confuse_include(filetype, filepath) and (filetype in all_folder_suffix) == False:
			flag = flag | FILE_MASK_CONFUSE

		if filetype not in source_suffix_items:
			return flag

		if confuse_utils.is_inflate_include(filetype, filepath):
			flag = flag | FILE_MASK_INFLATE
	return flag

def get_file_support_flag(filetype):
	if filetype == '.xcdatamodeld':
		return FILE_MASK_CONFUSE
	
	if filetype in all_file_suffix:
		flag =  FILE_MASK_CONFUSE
		if filetype in source_suffix_items:
			flag = flag | FILE_MASK_INFLATE
		else:
			flag = flag | FILE_MASK_RENAME
		return flag
	return 0

def append_file_info(project, file_id, filepath, last_known_file_type, all_file_suffix, files_map, xcconfig_files, workspace_dir, is_ref_folder):
	#print 'file id %s name:%s' % (file_id, filepath)
	filetype = get_file_type(filepath)
	if last_known_file_type in source_code_map:
		filetype = source_code_map[last_known_file_type]
	if filetype == '.xcconfig':
		xcconfig_files.append({'id' : file_id, 'path' : filepath})
		return
	
	if is_ref_folder:
		filetype = 'folder'

	if (filetype in files_map) == False:
		files_map[filetype] = []
	files = files_map[filetype]
	filekey = filepath.lower()
	if filekey in all_file_map:
		return

	#print('%s %s' % (file_id, filepath))
	all_file_map[filekey] = True
	if  (filetype in all_file_suffix) == False or is_ref_folder:
		files.append({'id' : file_id, 'path' : filepath, 'flags' : 0, 'ref-folder' : '', 'support-flags' : 0, 'type' : filetype})
	else:
		flag = get_file_flag(filetype, os.path.relpath(filepath, workspace_dir))
		support_flag = get_file_support_flag(filetype)
		files.append({'id' : file_id, 'path' : filepath, 'flags' : flag, 'ref-folder' : '', 'support-flags' : support_flag, 'type' : filetype})
	pass

def get_ref_folder(ref_parent_folder, file_name):
	#print 'ref_parent_folder:%s\n' % ref_parent_folder
	#print 'file_name:%s\n' % file_name
	start = len(ref_parent_folder) + 1
	end = file_name.rfind('/')
	if end != -1:
		return file_name[start:end]
	return file_name[start:]

def add_follder_files(folder_files_map, filename, file_info):
	#print('add %s to %s' % (file_info['path'], filename))
	if filename in folder_files_map.keys():
		folder_files_map[filename].append(file_info)
	else:
		folder_files_map[filename] = [file_info]

def load_folder_file_info(filepath, exts, all_file_suffix, files_map, folder_files_map, workspace_dir, is_ref_folder, ref_parent_folder):
	for root, dirnames, filenames in os.walk(filepath):
		if len(dirnames):
			for name in dirnames:
				filename = os.path.join(root, name)
				#print('dir %s' % filename)
				filetype = get_file_type(name)
				if filetype == '[None]':
					filetype = 'folder'
				matchtype = False
				if exts == None:
					matchtype = True
				elif filetype in exts:
					matchtype = True
				if matchtype:
					if filename in all_file_map:
						continue
					all_file_map[filename] = True
					if filetype in files_map:
						files = files_map[filetype]
					else:
						files = []
						files_map[filetype] = files
					flag = get_file_flag(filetype, os.path.relpath(filename, workspace_dir))
					support_flag = get_file_support_flag(filetype)
					if is_ref_folder and not filepath.endswith('.bundle'):
						flag = 0
						support_flag = 0
					if is_ref_folder:
						file_info = {'id' : 0, 'path' : filename, 'flags' : flag, 'support-flags' : support_flag, 'ref-folder' : get_ref_folder(ref_parent_folder, filename), 'type' : filetype}
					else:
						file_info = {'id' : 0, 'path' : filename, 'flags' : flag, 'support-flags' : support_flag, 'type' : filetype}
					files.append(file_info)
					add_follder_files(folder_files_map, filepath, file_info)

		if len(filenames):
			for name in filenames:
				filename = os.path.join(root, name)
				filetype = get_file_type(name)
				matchtype = False
				if exts == None:
					matchtype = True
				elif filetype in exts:
					matchtype = True
				if matchtype:
					if filename in all_file_map:
						continue
					all_file_map[filename] = True
					if filetype in files_map:
						files = files_map[filetype]
					else:
						files = []
						files_map[filetype] = files
					flag = get_file_flag(filetype, os.path.relpath(filename, workspace_dir))
					support_flag = get_file_support_flag(filetype)
					if is_ref_folder:
						file_info = {'id' : 0, 'path' : filename, 'flags' : flag, 'support-flags' : support_flag, 'ref-folder' : get_ref_folder(ref_parent_folder, filename), 'type' : filetype}
						#print '%s ref-folder:%s\n' % (filename, get_ref_folder(ref_parent_folder, filename))
					else:
						file_info = {'id' : 0, 'path' : filename, 'flags' : flag, 'support-flags' : support_flag, 'type' : filetype}
					files.append(file_info)
					add_follder_files(folder_files_map, filepath, file_info)
	pass

def get_abs_path(relpath, file_info, project_settings):
	path = file_info['path']
	if path == None:
		return os.path.abspath(relpath)
	if file_info.sourceTree =='<group>':
		abspath = relpath + '/' + path
	elif file_info.sourceTree in project_settings:
		abspath = project_settings[file_info.sourceTree] + '/' + path
	else:
		abspath = path
	return os.path.abspath(abspath)

def make_header_map_file_name(work_dir, bundle_id, project_name, target_name):
	if target_name == None:
		header_map_file = '%s/packages/%s/%s.hmap' % (work_dir, bundle_id, project_name)
	else:
		header_map_file = '%s/packages/%s/%s-%s.hmap' % (work_dir, bundle_id, project_name, target_name)
	return header_map_file

def copy_list(dst, src):
	if isinstance(src, list):
		for v in src:
			if v not in dst:
				dst.append(v)
	else:
		if src not in dst:
			dst.append(src)

def remake_products_frameworks(package_dir, project_name, product_files):
	for item in product_files:
		if isinstance(item, list):
			for product_file in item:
				products_dir = '%s/Framework-Products/%s/%s' % (package_dir, confuse_utils.md5str(project_name), confuse_utils.get_file_name(product_file))
				if os.path.exists(products_dir):
					shutil.rmtree(products_dir)
				os.makedirs(products_dir)
		else:
			products_dir = '%s/Framework-Products/%s/%s' % (package_dir, confuse_utils.md5str(project_name), confuse_utils.get_file_name(item))
			if os.path.exists(products_dir):
				shutil.rmtree(products_dir)
			os.makedirs(products_dir)

def gen_header_map_file(work_dir, bundle_id, project_name, target_name, header_files, header_files_target):
	header_map_file = make_header_map_file_name(work_dir, bundle_id, project_name, target_name)
	mapfile = hmap.HMapFile()

	keys = list(header_files.keys())
	values = {}
	for key in keys:
		value = header_files[key]
		if value in values:
			temp = [key]
			copy_list(temp, values[value])
			values[value] = temp
		else:
			values[value] = key
	
	if header_files_target != None:
		package_dir = '%s/packages/%s' % (work_dir, bundle_id)
		remake_products_frameworks(package_dir, project_name, list(header_files_target.values()))
	
	paths = []
	for item in list(values.values()):
		if isinstance(item, list):
			copy_list(paths, item)
		else:
			paths.append(item)

	for path in paths:
		if header_files_target == None:
			prefix = confuse_utils.get_file_dir(path) + '/'
			suffix = confuse_utils.get_full_file_name(path)
			mapfile.add(prefix, suffix)
		else:
			product_files = header_files_target[path]
			products_dir = '%s/Framework-Products/%s/' % (package_dir, confuse_utils.md5str(project_name))
			if isinstance(product_files, list):
				for product_file in product_files:
					if product_file.endswith('.framework'):
						link_file = '%s/%s/%s' % (products_dir, confuse_utils.get_file_name(product_file), confuse_utils.get_full_file_name(path))
						os.symlink(path, link_file)
						prefix = products_dir
						suffix = '%s/%s' % (confuse_utils.get_file_name(product_file), confuse_utils.get_full_file_name(path))
					else:
						start = path.rfind('/')
						start = path.rfind('/', 0, start - 1)
						prefix = path[0:start + 1]
						suffix = path[start + 1:]
					mapfile.add(prefix, suffix)
			else:
				product_file = product_files
				if product_file.endswith('.framework'):
					link_file = '%s/%s/%s' % (products_dir, confuse_utils.get_file_name(product_file), confuse_utils.get_full_file_name(path))
					os.symlink(path, link_file)
					prefix = products_dir
					suffix = '%s/%s' % (confuse_utils.get_file_name(product_file), confuse_utils.get_full_file_name(path))
				else:
					start = path.rfind('/')
					start = path.rfind('/', 0, start - 1)
					prefix = path[0:start + 1]
					suffix = path[start + 1:]
				mapfile.add(prefix, suffix)
	mapfile.save(header_map_file)
	#mapfile.dump(open('%s.dump.txt' % header_map_file, 'w'))
	return header_map_file

def load_project_files(project, project_settings, valid_infos, relpath, group, all_folder_suffix, all_file_suffix, files_map, xcconfig_files, folder_files_map, workspace_dir, quote_header_files):
	group_path = get_abs_path(relpath, group, project_settings)
	#print 'group_path:%s' % group_path
	for child_id in group.children:
		child = project.get_object(child_id)
		if isinstance(child, project._get_class_reference('XCVersionGroup')):
			filepath = get_abs_path(group_path, child, project_settings)
			if os.path.isdir(filepath):
				append_file_info(project, child_id, filepath, None, all_file_suffix, files_map, xcconfig_files, workspace_dir, False)
			pass
		elif isinstance(child, project._get_class_reference('PBXVariantGroup')):
			for cur_child_id in child.children:
				child_file = project.get_object(cur_child_id)
				filepath = get_abs_path(group_path, child_file, project_settings)
				if os.path.exists(filepath):
					append_file_info(project, child_id, filepath, None, all_file_suffix, files_map, xcconfig_files, workspace_dir, False)
			pass
		elif isinstance(child, project._get_class_reference('PBXGroup')):
			load_project_files(project, project_settings, valid_infos, group_path, child, all_folder_suffix, all_file_suffix, files_map, xcconfig_files, folder_files_map, workspace_dir, quote_header_files)
			pass
		elif isinstance(child, project._get_class_reference('PBXFileReference')):
			child_path = child['path']
			filepath = get_abs_path(group_path, child, project_settings)
			is_folder = False
			folder_suffixs = None
			is_ref_folder = False
			last_known_file_type = None
			if hasattr(child, 'lastKnownFileType'):
				last_known_file_type = child.lastKnownFileType
				if last_known_file_type == 'folder':
					is_folder = True
					is_ref_folder = True

			if hasattr(child, 'explicitFileType'):
				last_known_file_type = child.explicitFileType

			if os.path.exists(filepath):
				#print 'path:%s file_type:%s' % (filepath, last_known_file_type)
				if last_known_file_type in source_code_map.keys():
					valid_infos['has_%s' % source_code_map[last_known_file_type]] = True
				if last_known_file_type == 'sourcecode.c.h' or last_known_file_type == 'sourcecode.cpp.h':
					dirname = confuse_utils.get_file_dir(filepath)
					
					if filepath not in quote_header_files:
						quote_header_files[filepath] = len(list(quote_header_files.keys()))

				ext_start = filepath.rfind('.')
				if ext_start != -1:
					ext_name = filepath[ext_start:]

					if ext_name in all_folder_suffix:
						is_folder = True
						folder_suffixs = all_folder_suffix[ext_name]
				if is_folder:
					if last_known_file_type == 'wrapper.plug-in' and filepath.endswith('.bundle'):
						load_folder_file_info(filepath, folder_suffixs, all_file_suffix, files_map, folder_files_map, workspace_dir, True, filepath[0:filepath.rfind('/')])
					else:
						load_folder_file_info(filepath, folder_suffixs, all_file_suffix, files_map, folder_files_map, workspace_dir, is_ref_folder, filepath[0:filepath.rfind('/')])

				#print('file:%s' % filepath)
				append_file_info(project, child_id, filepath, last_known_file_type, all_file_suffix, files_map, xcconfig_files, workspace_dir, is_ref_folder)
			#else:
			#	print 'not found file:%s' % filepath
			pass
	pass

def remove_source_file_keys(keys):
	ret = []
	for key in keys:
		if key not in source_suffix_items:
			ret.append(key)
	return ret

def found_target_dependencies(target_dependencies, workspace_project_ref_products, project_name, target_names):
	project_ref_products = workspace_project_ref_products[project_name]
	for target_name in target_names:
		if target_name in project_ref_products:
			target_dependencies.append({'project' : project_name, 'target' : target_name})
	pass

def found_project_and_target(project_infos, ref_target_id):
	for project_info in project_infos:
		project_name = project_info['name']
		targets = project_info['targets']
		for target in targets:
			target_id = target['id']
			target_name = target['name']
			if target_id == ref_target_id:
				found_project_name = project_name
				found_target_name = target_name
				return found_project_name, found_target_name
	return None,None

def	found_target_project_dependencies(project_infos, target_dependencies, workspace_project_ref_products, workspace_project_new_products, project_name, target_id, target_name):
	project_ref_products = workspace_project_ref_products[project_name]
	if target_name in project_ref_products:
		ref_files = project_ref_products[target_name]
		for ref_file in ref_files:
			found_project_name, found_target_name = found_ref_file(workspace_project_new_products, project_name, ref_file)
			if found_project_name != None:
				target_dependencies.append({'project' : found_project_name, 'target' : found_target_name})
	project_ref_targets = workspace_project_ref_targets[project_name]
	#print('%s:%s' % (project_name, project_ref_targets))
	for ref_target_id in project_ref_targets:
		found_project_name , found_target_name = found_project_and_target(project_infos, ref_target_id)

		if found_project_name != None:
			target_dependencies.append({'project' : found_project_name, 'target' : found_target_name})
	pass

def append_list(result, items):
	for item in items:
		result.append(item)

def is_product_file(workspace_project_new_products, file_id):
	for project_name in workspace_project_new_products.keys():
		project_new_products = workspace_project_new_products[project_name]
		for target_name in project_new_products.keys():
			if project_new_products[target_name]['id'] == file_id:
				return True
	return False

def gen_profile_file(workspacefile, file_name, projects, workspace_valid_infos, workspace_project_ref_products, workspace_project_new_products, workspace_project_embed_files, format_version):
	with open(file_name, 'w') as f:
		write_json_dict = {}
		write_json_dict['format-version'] = int(format_version)
		write_json_dict['workspace-file'] = workspacefile
		projects_json_array = []
		write_json_dict['projects'] = projects_json_array
		for i in range(0, len(projects)):
			project = projects[i]
			project_json_dict = {}
			projects_json_array.append(project_json_dict)
			#xcconfigs
			xcconfigs = project['xcconfigs']
			xcconfigs_json = {}
			for xcconfig in xcconfigs:
				xcconfigs_json[xcconfig['id']] = xcconfig['path']
			project_json_dict['xcconfigs'] = xcconfigs_json
			#name
			project_name = project['name']
			project_json_dict['name'] = project_name
			#path
			project_path = project['path']
			project_json_dict['path'] = project_path
			#valid-infos
			valid_infos_json = {}
			project_json_dict['valid-infos'] = valid_infos_json
			valid_infos = workspace_valid_infos[project_name]
			keys = list(valid_infos.keys())
			for j in range(0, len(keys)):
				key = keys[j]
				value = valid_infos[key]
				valid_infos_json[key] = value

			project_embed_files = workspace_project_embed_files[project_name]

			#分析出的targets数量
			targets_json_array = []
			project_json_dict['targets'] = targets_json_array
			targets = project['targets']
			for j in range(0, len(targets)):
				target = targets[j]
				target_id = target['id']
				target_name = target['name']
				product_type = target['product-type']
				mach_o_type = target['mach-o-type']
				target_json_dict = {}
				targets_json_array.append(target_json_dict)
				#root_dirs = target['root_dirs']
				#name
				target_json_dict['name'] = target_name
				target_json_dict['product-type'] = product_type
				target_json_dict['mach-o-type'] = mach_o_type
				#dependencies
				target_dependencies_json_array = []
				target_json_dict['dependencies'] = target_dependencies_json_array
				target_dependencies = []
				found_target_dependencies(target_dependencies, workspace_project_ref_products, project_name, target['dependencies'])
				found_target_project_dependencies(projects, target_dependencies, workspace_project_ref_products, workspace_project_new_products, project_name, target_id, target_name)
				for k in range(0, len(target_dependencies)):
					target_dependencie = target_dependencies[k]
					depend_project_name = target_dependencie['project']
					depend_target_name = target_dependencie['target']
					target_depend_json_dict = {}
					target_dependencies_json_array.append(target_depend_json_dict)
					target_depend_json_dict['project'] = depend_project_name
					target_depend_json_dict['target'] = depend_target_name
				
				#source files
				source_files_json_array = []
				target_json_dict['source-files'] = source_files_json_array
				target_source_files = target['source-files']
				keys = list(target_source_files.keys())
				for j in range(0, len(keys)):
					key = keys[j]
					file_info_json_dict = {}
					source_files_json_array.append(file_info_json_dict)
					file_info_json_array = []
					file_info_json_dict[key] = file_info_json_array
					files = target_source_files[key]
					for l in range(0, len(files)):
						info = files[l]
						file_info_json_dict = {}
						file_info_json_array.append(file_info_json_dict)
						file_info_json_dict['path'] = info['path']
						file_info_json_dict['type'] = info['type']
						file_info_json_dict['flags'] = info['flags']
						file_info_json_dict['support-flags'] = info['support-flags']
						if 'ref-folder' in info:
							file_info_json_dict['ref-folder'] = info['ref-folder']

				#framework files
				target_framework_files = target['framework-files']
				framework_files_json_array = []
				target_json_dict['framework-files'] = framework_files_json_array
				keys = list(target_framework_files.keys())
				for j in range(0, len(keys)):
					key = keys[j]
					framework_file_json_dict = {}
					framework_files_json_array.append(framework_file_json_dict)
					file_info_json_dict_array = []
					framework_file_json_dict[key] = file_info_json_dict_array
					files = target_framework_files[key]
					for l in range(0, len(files)):
						info = files[l]
						file_info_json_dict = {}
						file_info_json_dict_array.append(file_info_json_dict)
						file_info_json_dict['path'] = info['path']
						file_info_json_dict['type'] = info['type']
						file_info_json_dict['flags'] = info['flags']
						file_info_json_dict['support-flags'] = info['support-flags']
						if 'ref-folder' in info:
							file_info_json_dict['ref-folder'] = info['ref-folder']
				
				#embed files
				target_embed_files = project_embed_files[target_name]
				target_embed_files_json_array = []
				target_json_dict['embed-build-files'] = target_embed_files_json_array
				for embed_file in target_embed_files:
					if embed_file not in target_embed_files_json_array:
						embed_file_id = embed_file['id']
						embed_file_path = embed_file['path']
						embed_install_path = embed_file['install']
						if not is_product_file(workspace_project_new_products, embed_file_id):
							target_embed_files_json_array.append({'path' : embed_file_path, 'install-path' : embed_install_path})

				#resource files
				resource_files_json_array = []
				target_resource_files = target['resource-files']
				target_json_dict['resource-files'] = resource_files_json_array
				keys = list(target_resource_files.keys())
				for j in range(0, len(keys)):
					key = keys[j]
					resource_file_json_dict = {}
					resource_files_json_array.append(resource_file_json_dict)
					file_info_json_array = []
					resource_file_json_dict[key] = file_info_json_array
					files = target_resource_files[key]
					for l in range(0, len(files)):
						info = files[l]
						file_info_json_dict = {}
						file_info_json_array.append(file_info_json_dict)
						file_info_json_dict['path'] = info['path']
						file_info_json_dict['type'] = info['type']
						file_info_json_dict['flags'] = info['flags']
						file_info_json_dict['support-flags'] = info['support-flags']
						if 'ref-folder' in info:
							file_info_json_dict['ref-folder'] = info['ref-folder']

			project_files = project['files']
			files_json_array = []
			target_json_dict['files'] = files_json_array
			keys = list(project_files.keys())
			keys = remove_source_file_keys(keys)

			for j in range(0, len(keys)):
				key = keys[j]
				file_json_dict = {}
				files_json_array.append(file_json_dict)
				file_info_json_array = []
				file_json_dict[key] = file_info_json_array
				files = project_files[key]
				for l in range(0, len(files)):
					info = files[l]
					file_info_json_dict = {}
					file_info_json_array.append(file_info_json_dict)
					file_info_json_dict['path'] = info['path']
					file_info_json_dict['type'] = info['type']
					file_info_json_dict['flags'] = info['flags']
					file_info_json_dict['support-flags'] = info['support-flags']
					if 'ref-folder' in info:
						file_info_json_dict['ref-folder'] = info['ref-folder']

			#对应target有生成的product名
			products_json_dict = {}
			project_json_dict['products'] = products_json_dict
			products = project['products']
			j = 0
			for target_name, product_info  in list(products.items()):
				temp_json_dict = {}
				products_json_dict[target_name] = temp_json_dict
				k = 0
				for product_key, product_value in list(product_info.items()):
					temp_json_dict[product_key] = product_value
					k = k + 1
				j = j + 1
			
			#project-header-map-file
			project_header_map_file = project['project-header-map-file']
			project_json_dict['project-header-map-file'] = project_header_map_file
			#public-header-map-file
			public_header_map_file = project['public-header-map-file']
			project_json_dict['public-header-map-file'] = public_header_map_file
		check_confilict_source_files(projects_json_array)
		json_str = json.dumps(write_json_dict,ensure_ascii=False,indent=2)
		f.write(json_str)
		f.close()
	pass

def check_confilict_source_files(projects):
	for project in projects:
		targets = project['targets']
		for target in targets:
			object_names = {}
			source_files = target['source-files']
			for source_file in source_files:
				for file_type in source_file.keys():
					files = source_file[file_type]
					for file in files:
						file_path = file['path']
						#print('%s' % file_path)
						name = confuse_utils.get_file_name(file_path)
						filekey = name.lower()
						if filekey not in object_names:
							object_names[filekey] = 0
						else:
							ext = confuse_utils.get_file_extension(file_path)
							count = object_names[filekey] + 1
							object_names[filekey] = count
							new_path = '%s/%s_%d.%s' % (confuse_utils.get_file_dir(file_path), name, count, ext)
							file['alias-path'] = new_path
							#print('😄%s' % new_path)
	pass

def gen_code_file(files, file_name, has_compiler_flags):
	with open(file_name, 'w') as fh:
		for info in files:
			if info['flags'] & FILE_MASK_CONFUSE or info['flags'] & FILE_MASK_INFLATE:
				fh.write('%s\n' % info['path'])
				if has_compiler_flags:
					if 'compiler-flags' in info:
						fh.write('%s\n' % info['compiler-flags'])
					else:
						fh.write('\n')
		fh.close()
	pass


def add_file_infos_to_map(map, files):
	for file_info in files:
		file = file_info['path']
		type = get_file_type(file)
		if type in map:
			map[type].append(file_info)
		else:
			map[type] = [file_info]

#def get_root_dirs(workspace_dir, source_files_map, resource_files_map):
#	ret = {}
#	keys = list(source_files_map.keys())
#	for key in keys:
#		files = source_files_map[key]
#		for info in files:
#			filename = info['path']
#			relfilename = os.path.relpath(filename, workspace_dir)
#			ret[confuse_utils.get_file_dir(relfilename)] = True

#	keys = list(resource_files_map.keys())
#	for key in keys:
#		files = resource_files_map[key]
#		for info in files:
#			filename = info['path']
#			relfilename = os.path.relpath(filename, workspace_dir)
#			ret[confuse_utils.get_file_dir(relfilename).encode('utf-8')] = True
#	keys = list(ret.keys())
#	keys = sorted(keys,key = lambda i:len(i))
#	result = []
#	if len(keys):
#		result.append(keys[0])
#	for key in keys:
#		match_start = False
#		for item in result:
#			if key.startswith(item):
#				match_start = True
#				break
#
#		if match_start == False:
#			result.append(key)
#	return result

def get_build_setting_value(project, buildConfigurationList, name, target_name, defvalue=None):
	value = defvalue
	for buildConfigurationId in buildConfigurationList['buildConfigurations']:
		buildConfiguration = project.get_object(buildConfigurationId)
		buildSettings =  buildConfiguration['buildSettings']
		old_value = value
		if hasattr(buildSettings, name):
			value = buildSettings[name]
			if old_value != value and old_value != defvalue:
				confuse_utils.trace_error('%s conflict（%s,%s) in %s' % (name, old_value, value, target_name))
	return value

def get_link_product_file_target_id(project, rootObject, file_ref_id):
	for targetId in rootObject.targets:
		targetObject =  project.get_object(targetId)
		if hasattr(targetObject, 'productReference'):
			productReference = targetObject['productReference']
			if productReference == file_ref_id:
				return targetId
	return None

def append_folder_files(files, folder_files_map, filepath):
	childs = folder_files_map[filepath]
	append_list(files, childs)
	for child in childs:
		childpath = child['path']
		if childpath in folder_files_map.keys():
			append_folder_files(files, folder_files_map, childpath)

def get_project_references(project,rootObject):
	ret = []
	if hasattr(rootObject, 'projectReferences'):
		refFiles = rootObject.projectReferences
		for refFile in refFiles:
			refFileId = refFile.ProjectRef
			refFile = project.get_object(refFileId)
			file_path = project._source_root + '/' + refFile.path
			if os.path.exists(file_path):
				ret.append(file_path)
	return ret

def get_embed_install_path(file_ref):
	dstPathMap = {10 : '${Frameworks}', 1 : '${Wrapper}', 6 : '${Executables}', 7 : '${Resources}', 15 : '${JavaResources}', 11 : '${SharedFrameworks}', 16 : '${Products}', 13 : '${PlugIns}'}
	dstSubfolderSpec = int(file_ref['dstSubfolderSpec'])
	dstPath = file_ref['dstPath']
	if dstSubfolderSpec == 0:
		return dstPath
	if dstSubfolderSpec in dstPathMap.keys():
		return dstPathMap[dstSubfolderSpec] + '/' + dstPath
	return '${Unsupport}' + '/' + dstPath

def profile_project(project_references_lock, project_file, work_dir, bundle_id, main_bundle_id, project_name, targets, files_map, xcconfig_files, valid_infos, project_ref_targets, project_ref_products, project_new_products, project_embed_files, workspace_file, project_header_files, public_header_files, public_target_header_files):
	pbxprojfile = '%s/project.pbxproj' % project_file
	package_dir = '%s/packages/%s' % (work_dir, bundle_id)
	workspace_dir = workspace_file[:workspace_file.rfind('/')]
	
	if len(main_bundle_id):
		cache_dir = '%s/cache/%s' % (work_dir, main_bundle_id)
	else:
		cache_dir = '%s/cache' % package_dir

	#删除save_project时备份的文件
	back_file = pbxprojfile + '.back'
	if os.path.exists(back_file):
		os.remove(back_file)
	print(('load %s ...' % project_file))
	project = XcodeProject.load(pbxprojfile)
	print('load done.')

	#加载project下的所有文件
	rootObject = project.get_object(project.rootObject)
	mainGroupId = rootObject.mainGroup
	mainGroup = project.get_object(mainGroupId)

	#print('😄 %s' % rootObject.projects)

	project_files_map = {}
	folder_files_map = {}
	
	print('get project settings.')
	project_settings = confuse_utils.get_project_build_settings(project_file)

	print('load project files ...')
	append_project_files = get_project_references(project, rootObject)
	with project_references_lock:
		for append_project_file in append_project_files:
			project_references.append(append_project_file)
	
	load_project_files(project, project_settings, valid_infos, project._source_root, mainGroup, all_folder_suffix, all_file_suffix, project_files_map, xcconfig_files, folder_files_map, workspace_dir, project_header_files)
	print('load done.')
	file_info_map = {}
	#创建索引
	for key in list(project_files_map.keys()):
		files = project_files_map[key]
		for file in files:
			file_info_map[file['id']] = file
	remove_file_refs = []

	project_build_phrase_file_refs = {}

	target_info_map = {}
	for targetId in rootObject.targets:
		target_build_phrase_file_refs = []
		project_build_phrase_file_refs[targetId] = target_build_phrase_file_refs

		source_files = []
		framework_files = []
		target_object =  project.get_object(targetId)
		target_name = target_object['name']

		confuse_utils.remove_xcsets_file(work_dir, bundle_id, project_file, 'Debug', target_name)
		confuse_utils.remove_xcsets_file(work_dir, bundle_id, project_file, 'Release', target_name)
		
		buildConfigurationList = project.get_object(target_object['buildConfigurationList'])
		for buildConfigurationId in buildConfigurationList['buildConfigurations']:
			buildConfiguration = project.get_object(buildConfigurationId)
			buildSettings =  buildConfiguration['buildSettings']
			configName = buildConfiguration['name']
			if hasattr(buildConfiguration, 'baseConfigurationReference'):
				baseConfigurationReference = buildConfiguration['baseConfigurationReference']
				for xcconfig_file in xcconfig_files:
					if xcconfig_file['id'] == baseConfigurationReference:
						xcconfig_files.append({'id' : '%s.%s' % (target_name, configName), 'path' : xcconfig_file['path']})
		install_path = get_build_setting_value(project, buildConfigurationList, 'INSTALL_PATH', 'target:%s' % target_name, '')
		product_reference_id = target_object['productReference']
		productReference = project.get_object(product_reference_id)
		productType = target_object['productType']
		if productType == None:
			productType = get_build_setting_value(project, buildConfigurationList, 'PRODUCT_TYPE', 'target:%s' % target_name, '')
		machoType = get_build_setting_value(project, buildConfigurationList, 'MACH_O_TYPE', 'target:%s' % target_name, '')
		#print('target:%s=%s machotype:%s' % (target_name, machoType,productType))
		if machoType == MACH_O_TYPE_DYNAMIC:
			valid_infos['has_dynamic_lib'] = True
		if productType == PRODUCT_TYPE_FRAMEWORK and machoType == '':
			valid_infos['has_dynamic_lib'] = True
		resource_files = []
		target_ref_products = []
		project_ref_products[target_name] = target_ref_products
		product_file_name = None
		if productReference != None:
			product_file_path = None
			product_file_name = productReference['name']
			if hasattr(productReference, 'path'):
				product_file_name = productReference['path']
			project_new_products[target_name] = {'id' : product_reference_id, 'name' : product_file_name, 'install-dir' : install_path}

		sdkroot = get_build_setting_value(project, buildConfigurationList, 'SDKROOT', 'target:%s' % target_name)
		if sdkroot == None:
			sdkroot = get_build_setting_value(project, project.get_object(rootObject['buildConfigurationList']), 'SDKROOT', 'project')

		print(('%s.%s' % (target_name, sdkroot)))
		if sdkroot != 'iphoneos':
			continue

		target_embed_files = []
		project_embed_files[target_name] = target_embed_files

		buildPhases = target_object['buildPhases']
		for buildPhaseId in buildPhases:
			buildPhase = project.get_object(buildPhaseId)
			if isinstance(buildPhase, project._get_class_reference('PBXHeadersBuildPhase')):
				files = buildPhase['files']
				for fileId in files:
					phase_file = project.get_object(fileId)
					fileRefId = phase_file['fileRef']
					if fileRefId in file_info_map:
						input_file_info = file_info_map[fileRefId]
						if hasattr(phase_file, 'settings'):
							settings = phase_file['settings']
							if settings['ATTRIBUTES'][0] == 'Public':
								file_path = input_file_info['path']
								#print 'public:%s' % file_path
								public_header_files[file_path] = len(list(public_header_files.keys()))
								#print '########'
								#print public_header_files
								#print '########'
								if file_path in public_target_header_files:
									project_file_names = [product_file_name]
									copy_list(project_file_names, public_target_header_files[file_path])
									public_target_header_files[file_path] = project_file_names
								else:
									public_target_header_files[file_path] = product_file_name
								#print public_target_header_files

			if isinstance(buildPhase, project._get_class_reference('PBXCopyFilesBuildPhase')):
				files = buildPhase['files']
				for fileId in files:
					phase_file = project.get_object(fileId)
					fileRefId = phase_file['fileRef']
					if fileRefId in file_info_map:
						input_file_info = file_info_map[fileRefId]
						fileRef = project.get_object(fileRefId)
						explicit_file_type = None
						if hasattr(fileRef, 'lastKnownFileType'):
							explicit_file_type = fileRef.lastKnownFileType
						if hasattr(fileRef, 'explicitFileType'):
							explicit_file_type = fileRef.explicitFileType
						#print 'explicit_file_type:%s' % (explicit_file_type)
						if explicit_file_type == 'sourcecode.c.h' or explicit_file_type == 'sourcecode.cpp.h':
							file_path = input_file_info['path']
							#print 'copy public:%s' % file_path
							public_header_files[file_path] = len(list(public_header_files.keys()))
							#print '########'
							#print public_header_files
							#print '########'
							if product_file_name in public_target_header_files:
								project_file_names = [product_file_name]
								copy_list(project_file_names, public_target_header_files[file_path])
								public_target_header_files[file_path] = project_file_names
							else:
								public_target_header_files[file_path] = product_file_name
						elif explicit_file_type == 'wrapper.framework':
							file_path = input_file_info['path']
							target_embed_files.append({'id' : fileRefId, 'path' : file_path, 'install' : get_embed_install_path(buildPhase)})
					else:
						target_build_phrase_file_refs.append(fileRefId)

			if isinstance(buildPhase, project._get_class_reference('PBXSourcesBuildPhase')):
				files = buildPhase['files']
				for fileId in files:
					phase_file = project.get_object(fileId)
					fileRefId = phase_file['fileRef']
					compiler_flags = None
					settings = phase_file['settings']
					if settings != None:
						compiler_flags = settings['COMPILER_FLAGS']
					if fileRefId in file_info_map:
						input_file_info = file_info_map[fileRefId]
						if compiler_flags != None:
							input_file_info['compiler-flags'] = compiler_flags
						source_files.append(input_file_info)
						remove_file_refs.append(fileRefId)
			elif isinstance(buildPhase, project._get_class_reference('PBXFrameworksBuildPhase')):
				files = buildPhase['files']
				for fileId in files:
					framework_build_pahse = project.get_object(fileId)
					fileRefId = framework_build_pahse['fileRef']
					fileRef = project.get_object(fileRefId)
					if not hasattr(fileRef, 'sourceTree'):
						continue
					if fileRef.sourceTree == 'BUILT_PRODUCTS_DIR':
						target_build_phrase_file_refs.append(fileRefId)
						file_ref_name = fileRef.get_name()
						if file_ref_name not in target_ref_products:
							target_ref_products.append(file_ref_name)
					elif fileRef.sourceTree == 'sourceTree':
						if fileRefId in file_info_map:
							input_file_info = file_info_map[fileRefId]
							framework_files.append(input_file_info)
							remove_file_refs.append(fileRefId)
			elif isinstance(buildPhase, project._get_class_reference('PBXResourcesBuildPhase')):
				files = buildPhase['files']
				for fileId in files:
					resource_build_pahse = project.get_object(fileId)
					fileRefId = resource_build_pahse['fileRef']
					if fileRefId in file_info_map:
						input_file_info = file_info_map[fileRefId]
						file_path = input_file_info['path']
						if file_path in folder_files_map.keys():
							append_folder_files(resource_files, folder_files_map, file_path)
						resource_files.append(input_file_info)
						remove_file_refs.append(fileRefId)

		dependencies = target_object['dependencies']
		depend_targets = []

		for dependencie_id in dependencies:
			depend_object = project.get_object(dependencie_id)
			depend_target_id = depend_object['target']
			depend_target = project.get_object(depend_target_id)
			if depend_target == None:
				target_proxy_id = depend_object['targetProxy']
				target_proxy = project.get_object(target_proxy_id)
				project_ref_targets.append(target_proxy['remoteGlobalIDString'])
				continue
			depend_target_name = depend_target['name']
			if depend_target_name == None:
				continue
			depend_targets.append(depend_target_name)

		source_files_map = {}
		add_file_infos_to_map(source_files_map, source_files)
		all_key = list(source_files_map.keys())
		source_group_map = {}
		for suffix in source_suffix_items:
			source_group_map[suffix] = True
		for key in all_key:
			if (key in source_group_map) == False:
				del source_files_map[key]

		framework_files_map = {}
		add_file_infos_to_map(framework_files_map, framework_files)
		resource_files_map = {}
		add_file_infos_to_map(resource_files_map, resource_files)
		#root_dirs = get_root_dirs(workspace_dir, source_files_map, resource_files_map)
		#targets.append({'name' : target_name, 'root_dirs' : root_dirs, 'dependencies' : depend_targets, 'source-files' : source_files_map, 'framework-files' : framework_files_map, 'resource-files' : resource_files_map})
		#print('😊 %s:%s' % (targetId, target_name))
		target_info = {'id' : targetId, 'name' : target_name, 'product-type' : productType,  'mach-o-type' : machoType, 'dependencies' : depend_targets, 'source-files' : source_files_map, 'framework-files' : framework_files_map, 'resource-files' : resource_files_map}
		targets.append(target_info)
		#gen code file
		target_info_map[target_name] = target_info
		for code_type in code_types:
			result_code_files = []
			suffixs = language_suffixs[code_type]
			for file_info in source_files:
				match = False
				for suffix in suffixs:
					if file_info['type'] == suffix:
						match = True
						break
				if match:
					result_code_files.append(file_info)
			gen_code_file(result_code_files, '%s/%s.%s.%s.code-files' % (package_dir, confuse_utils.get_file_name(project_name), target_name, code_type), True)


	for targetId in list(project_build_phrase_file_refs.keys()):
		target_object =  project.get_object(targetId)
		target_name = target_object['name']
		target_build_phrase_file_refs = project_build_phrase_file_refs[targetId]
		for target_build_phrase_file_ref_id in target_build_phrase_file_refs:
			depend_target_id = get_link_product_file_target_id(project, rootObject, target_build_phrase_file_ref_id)
			if depend_target_id != None:
				depend_target_object = project.get_object(depend_target_id)
				target_info = target_info_map[target_name]
				depend_targets = target_info['dependencies']
				depend_target_name = depend_target_object['name']
				if depend_target_name not in depend_targets:
					depend_targets.append(depend_target_name)

	for type in list(project_files_map.keys()):
		project_files = project_files_map[type]
		result_files = []
		for file_info in project_files:
			isremove = False
			for remove_file_ref in remove_file_refs:
				if file_info['id'] == remove_file_ref:
					isremove = True
					break
			if isremove == False:
				result_files.append(file_info)

		if len(result_files):
			files_map[type] = result_files

	with project_references_lock:
		for project_file in append_project_files:
			project_references.append(project_file)
	pass

def found_ref_file(project_new_products, project_name, ref_file):
	for product_project_name in project_new_products.keys():
		if product_project_name != project_name:
			new_files = project_new_products[product_project_name]
			for target_name, product_file in new_files.items():
				if product_file['name'] == ref_file:
					#print('😊 found %s in %s %s' % (ref_file, product_project_name, target_name))
					return product_project_name, target_name
	return None, None

def get_project_info_by_name(project_infos, name):
	for project_info in project_infos:
		project_name = project_info['name']
		if project_name == name:
			return project_info
	return None

def get_project_ref_files(project_ref_products):
	ret = []
	for key in project_ref_products.keys():
		items = project_ref_products[key]
		for item in items:
			if item not in ret:
				ret.append(item)
	return ret

def insert_project_infos(result, project_name, depend_project_name):
	first_index = 0
	second_index = 0
	for i in range(0, len(result)):
		item = result[i]
		if item['name'] == project_name:
			first_index = i
			break
	for i in range(0, len(result)):
		item = result[i]
		if item['name'] == depend_project_name:
			second_index = i
			break
	
	if second_index > first_index:
		result.insert(first_index, result[second_index])
		del result[second_index + 1]

def sort_project_info(result, project_infos, project_name, project_ref_products, project_new_products, project_ref_targets):
	ref_targets = project_ref_targets[project_name]
	found_project_name = None
	found_target_name = None
	for ref_target_id in ref_targets:
		found_project_name, found_target_name = found_project_and_target(project_infos, ref_target_id)
		if found_project_name != None:
			sort_project_info(result, project_infos, found_project_name, project_ref_products, project_new_products, project_ref_targets)
			insert_project_infos(result, project_name, found_project_name)
	found_project_name = None
	found_target_name = None
	ref_files = get_project_ref_files(project_ref_products[project_name])
	for ref_file in ref_files:
		found_project_name, found_target_name = found_ref_file(project_new_products, project_name, ref_file)
		if found_project_name != None:
			sort_project_info(result, project_infos, found_project_name, project_ref_products, project_new_products, project_ref_targets)
			insert_project_infos(result, project_name, found_project_name)

def sort_project_infos(project_infos, project_ref_products, project_new_products, project_ref_targets):
	#print project_ref_products
	#print project_new_products
	result = []
	for project_info in project_infos:
		result.append(project_info)
	for project_info in project_infos:
		project_name = project_info['name']
		sort_project_info(result, project_infos, project_name, project_ref_products, project_new_products, project_ref_targets)
	return result

def export_listen_file(work_dir, bundle_id):
	package_dir = '%s/packages/%s' % (work_dir, bundle_id)
	listen_file_name = '%s/%s.listenkey' % (package_dir, bundle_id)
	#查找缓存
	connect = sqlite3.connect('%s/symbols.db' % work_dir)
	cur = connect.cursor()

	cur.execute('select listen_file_data from t_activity_code where bundle_identifier = \"%s\"' % bundle_id)
	res = cur.fetchone()
	if res != None:
		file_data = res[0]
		lf = open(listen_file_name, 'wb')
		lf.write(file_data)
		lf.close()
	pass

def get_dir_name(workspace_file):
	return workspace_file[0:workspace_file.rfind('/')]

def load_project_info(lock, ref_proj_lock, project, work_dir, bundle_id, main_bundle_id, workspace_file):
	targets = []
	project_path = project['path']
	project_name = project['name']
	global workspace_project_new_products
	global workspace_project_new_product
	global workspace_project_infos
	global workspace_project_embed_files
	project_ref_products = {}
	project_new_products = {}
	project_ref_targets = []
	project_embed_files = {}
	valid_infos = {}
	with lock:
		workspace_project_new_products[project_name] = project_new_products
		workspace_project_ref_products[project_name] = project_ref_products
		workspace_project_ref_targets[project_name] = project_ref_targets
		workspace_project_embed_files[project_name] = project_embed_files
		workspace_valid_infos[project_name] = valid_infos
	files_map = {}
	project_header_files = {}
	public_header_files = {}
	public_target_header_files = {}
	xcconfig_files = []
	profile_project(ref_proj_lock, project_path, work_dir, bundle_id, main_bundle_id, project_name, targets, files_map, xcconfig_files, valid_infos, project_ref_targets, project_ref_products, project_new_products, project_embed_files, workspace_file, project_header_files, public_header_files, public_target_header_files)
	project_header_map_file = gen_header_map_file(work_dir, bundle_id, confuse_utils.get_file_name(project_name), 'project', project_header_files, None)
	public_header_map_file = gen_header_map_file(work_dir, bundle_id, confuse_utils.get_file_name(project_name), 'public', public_header_files, public_target_header_files)
	project_info = {'name' : project_name, 'path' : project_path, 'targets' : targets, 'files' : files_map, 'products' : project_new_products, 'project-header-map-file' : project_header_map_file, 'public-header-map-file' : public_header_map_file, 'xcconfigs' : xcconfig_files}
	with lock:
		workspace_project_infos.append(project_info)

def list2Dict(items):
	ret = {}
	for item in items:
		pair = item.split('=')
		if len(pair) == 2:
			key = pair[0].strip()
			value = pair[1].strip()
			ret[key] = value
	return ret

def clean_temp_file(package_dir, workspace_file):
	os.system('rm -rf %s/file_rename.txt' % package_dir)
	os.system('rm -rf %s/warning.txt' % package_dir)
	workspace_dir = workspace_file[:workspace_file.rfind('/')]
	file_name = '%s/confuse_archive_configs.txt' % (package_dir)
	settings = confuse_utils.read_settings_file(file_name)
	if 'archives' not in settings:
		return
	archives = settings['archives']
	for archive in archives:
		if archive not in settings:
			continue
		archive_info = list2Dict(settings[archive])
		if 'file' not in archive_info.keys():
			continue
		archive_file = archive_info['file']
		archive_path = '%s/%s' % (workspace_dir, archive_file)
		if archive_path.endswith('.framework'):
			archive_path = '%s/%s' % (archive_path, confuse_utils.get_file_name(archive_file))
		unarchive_dir = '%s.unarchive' % (archive_path)
		if os.path.exists(unarchive_dir):
			shutil.rmtree(unarchive_dir)
	pass

def make_archive_xcconfig(workspace_file, package_dir, scheme, configure):
	cmd = 'xcodebuild -showBuildSettings -workspace \"%s\" -scheme \"%s\" -configuration \"%s\"' % (pstr(workspace_file), scheme, configure)
	b = os.popen(cmd)
	lines = b.readlines()
	envs = {}
	

def profile_workspace(work_dir, bundle_id, main_bundle_id, workspace_file, profile_file, format_version):
	if os.path.exists(workspace_file) == False:
		confuse_utils.trace_error('not found %s' % workspace_file)

	package_dir = '%s/packages/%s' % (work_dir, bundle_id)
	#移除临时文件
	clean_temp_file(package_dir, workspace_file)
	#os.system('rm -rf %s/output.txt' % package_dir)

	#导出listen_file
	export_listen_file(work_dir, bundle_id)

	#加载排除设置
	confuse_utils.read_exclude_file_configs(package_dir)

	#加载default_script.txt
	script_settings = confuse_utils.read_settings_file('%s/default_script.txt' % package_dir)

	global code_types

	code_types = script_settings['language']

	#获取所有需要处理的文件后缀
	resource_suffixs = script_settings['resource-suffixs']

	for suffix in resource_suffixs:
		pairs = suffix.split('=')
		name = pairs[0].strip()
		value = pairs[1].strip()
		exts = value.split('|')
		for ext in exts:
			all_file_suffix[ext] = True
		type_suffixs[name] = exts

	source_suffixs = script_settings['source-suffixs']

	for suffix in source_suffixs:
		pairs = suffix.split('=')
		name = pairs[0].strip()
		value = pairs[1].strip()
		exts = value.split('|')
		for ext in exts:
			all_file_suffix[ext] = True
		language_suffixs[name] = exts

	source_suffix_items.append('.xcdatamodeld')#core data
	language = script_settings['language']
	for codeType in language:
		items = language_suffixs[codeType]
		for item in items:
			source_suffix_items.append(item)

	#获取所有目录类型
	folders = script_settings['folders']
	for folder in folders:
		all_folder_suffix[folder] = []

	#设置目录下需要检查的文件
	for key in list(all_folder_suffix.keys()):
		files = script_settings[key]
		for f in files:
			folder = all_folder_suffix[key]
			folder.append(f)

	#all_code_files = []
	projects = []
	wcwfile = '%s/contents.xcworkspacedata' % workspace_file
	# 使用minidom解析器打开 XML 文档
	DOMTree = xml.dom.minidom.parse(wcwfile)
	Workspace = DOMTree.documentElement
	FileRefs = Workspace.getElementsByTagName('FileRef')

	for i in range(0, len(FileRefs)):
		FileRef = FileRefs[i]
		location = FileRef.getAttribute('location')
		pair = location.split(':')
		projectname = str(pair[1])
		projectfile = get_dir_name(workspace_file) + '/' + projectname
		projects.append({'path' : projectfile, 'name' : projectname})

	#遍历所有xcodeproj文件
	project_infos_lock = threading.Lock()
	project_references_lock = threading.Lock()
	load_finish = {}

	while True:
		threads = []
		for project in projects:
			project_name = project['name']
			if project_name in load_finish:
				continue
			load_finish[project_name] = True
			thread = threading.Thread(target = load_project_info, args = (project_infos_lock, project_references_lock, project, work_dir, bundle_id, main_bundle_id, workspace_file))
			thread.start()
			threads.append(thread)

		for thread in threads:
			thread.join()
		
		projects.clear()
		for path in project_references:
			projects.append({'name' : confuse_utils.get_full_file_name(path), 'path' : path})
		project_references.clear()
		if len(projects) == 0:
			break
	
	#gen_code_file(all_code_files, '%s/all-code-files.txt' % (package_dir), False)

	global workspace_project_infos
	global workspace_project_ref_products
	global workspace_project_new_products
	global workspace_project_embed_files

	workspace_project_infos = sort_project_infos(workspace_project_infos, workspace_project_ref_products, workspace_project_new_products, workspace_project_ref_targets)

	#print workspace_project_new_products
	#for project_info in workspace_project_infos:
	#	project_name = project_info['name']
	#	dependencies = []
	#	project_info['dependencies'] = dependencies
	#	ref_files = found_ref_file(workspace_project_ref_products[project_name])
	#	found_project_name = None
	#	for ref_file in ref_files:
	#		found_project_name, target_name = found_ref_file(workspace_project_new_products, project_name, ref_file)
	#		if found_project_name != None:
	#			dependencies.append({'project' : found_project_name, 'target' : target_name})

	print('gen profile file ...')
	#print workspace_project_infos
	#print workspace_project_new_products
	#print workspace_project_ref_products
	gen_profile_file(workspace_file, profile_file, workspace_project_infos, workspace_valid_infos, workspace_project_ref_products, workspace_project_new_products, workspace_project_embed_files, format_version)
	print('done.')
	#print '=================所有导入库================'
	#print target_link_libraries
	pass

# cd /Users/crab/Documents/myprojects/iOS-artifact/resource/projectmanager/other/script
# python profile_workspace.py /Users/crab/Library/ipa-artifact com.zuimeiqidai.my.samplecode com.zuimeiqidai.my.samplecode /Users/crab/Library/ipa-artifact/packages/com.zuimeiqidai.my.samplecode/workspace-info.json /Users/crab/Library/ipa-artifact/packages/com.zuimeiqidai.my.samplecode/workspace.profile asdfasdfa123123123
# cat /Users/crab/Library/ipa-artifact/packages/com.zuimeiqidai.my.samplecode/workspace.profile
def main(argv):
	confuse_utils.print_cmd(argv)
	if len(argv) != 7:
		print('python profile_workspace.py [work dir] [bundle id] [main bundle id] [workspace file] [profile file] [format version]')
		return
	profile_workspace(argv[1], argv[2], argv[3], argv[4], argv[5], argv[6])
	
main(sys.argv)