#!/usr/bin/python
# -*- coding: UTF-8 -*-

import sys
import os
from pbxproj import XcodeProject
from xml.dom.minidom import parse
import xml.dom.minidom
import biplist
import importlib

importlib.reload(sys)
#sys.setdefaultencoding("utf-8")

abs_file_path = os.path.abspath(__file__)
exe_dir = abs_file_path[0:abs_file_path.rfind('/')]

def get_dir_name(workspace_file):
	return workspace_file[0:workspace_file.rfind('/')]

def valid_bundle_id(bundle_id):
	for i in range(0, len(bundle_id)):
		valid = False
		if bundle_id[i] >= 'a' and bundle_id[i] <= 'z':
			valid = True
		if bundle_id[i] >= 'A' and bundle_id[i] <= 'Z':
			valid = True
		if bundle_id[i] >= '0' and bundle_id[i] <= '9':
			valid = True
		if bundle_id[i] == '.':
			valid = True
		if valid is False:
			return False

	return True

def get_info_plist_value(info_file, key, defvalue):
	if os.path.exists(info_file):
		with open(info_file, 'rb') as f:
			text = f.read()
			json = biplist.readPlistFromString(text)
			if key in json:
				return json[key]
			return defvalue
	return 'None'

def get_workspace_info(workspace_file, workspace_info_file):
	with open(workspace_info_file, 'w') as fh:
		wcwfile = '%s/contents.xcworkspacedata' % workspace_file

		print('加载 %s ...' % wcwfile)

		# 使用minidom解析器打开 XML 文档
		DOMTree = xml.dom.minidom.parse(wcwfile)
		Workspace = DOMTree.documentElement
	 
		print('加载成功!')

		fh.write('{')

		FileRefs = Workspace.getElementsByTagName('FileRef')

		fh.write('\"workspace-file\":\"%s\"' % workspace_file)
		fh.write(',\"projects\": [')

		for i in range(0, len(FileRefs)):
			FileRef = FileRefs[i]
			location = FileRef.getAttribute('location')
			pair = location.split(':')
			projectname = str(pair[1])
			projectfile = get_dir_name(workspace_file) + '/' + projectname
			pbxprojfile = '%s/project.pbxproj' % projectfile

			if i > 0:
				fh.write(',')
			fh.write('{')
			fh.write('\"name\" : \"%s\"' % projectname)
			fh.write(',\"path\" : \"%s\"' % projectfile)

			if os.path.exists(projectfile) is False:
				print(('not found %s' % projectfile))
				fh.write('}')
				continue

			print('加载 %s' % pbxprojfile)
			project = XcodeProject.load(pbxprojfile)
			print('加载成功!')

			rootObject = project.get_object(project.rootObject)
			targetInfos = {}

			for targetId in rootObject.targets:
				target = project.get_object(targetId)
				if target == None:
					continue
				print('check %s' % target.name)
				buildConfigurationList = project.get_object(target['buildConfigurationList'])
				for buildConfigurationId in buildConfigurationList['buildConfigurations']:
					buildConfiguration = project.get_object(buildConfigurationId)
					buildSettings =  buildConfiguration['buildSettings']
					if buildSettings == None:
						continue
					bundleId = buildSettings['PRODUCT_BUNDLE_IDENTIFIER']
					if bundleId == '${BUNDLE_ID}':
						bundleId = buildSettings['BUNDLE_ID']
					if bundleId == None:
						infoplist_file = buildSettings['INFOPLIST_FILE']
						if infoplist_file != None:
							bundleId = get_info_plist_value('%s/%s' % (project._source_root, infoplist_file), 'CFBundleIdentifier', None)
					targetInfos[target.name] = bundleId
			fh.write(',\"targets\" : ')
			fh.write('{')
			first = True
			for key in list(targetInfos.keys()):
				if first == True:
					fh.write('\"%s\" : \"%s\"' % (key, targetInfos[key]))
					first = False
				else:
					fh.write(',\"%s\" : \"%s\"' % (key, targetInfos[key]))
			fh.write('}')
			fh.write('}')
		fh.write(']')
		fh.write('}')
		fh.close()
	pass

# cd /Users/yangwei/Documents/myprojects/iOS-artifact/resource/projectmanager/other/script
# python get_workspace_info.py /Users/yangwei/Documents/swapshell/samplecode/objc_sample_code/SampleCode.xcworkspace /Users/yangwei/Library/ipa-artifact/packages/com.zuimeiqidai.my.samplecode/workspace-info.json

def main(argv):
	if len(argv) != 3:
		print('python get_workspace_info.py [*.workspace] [info file path]')
		sys.exit(1)
	
	get_workspace_info(argv[1], argv[2])

main(sys.argv)