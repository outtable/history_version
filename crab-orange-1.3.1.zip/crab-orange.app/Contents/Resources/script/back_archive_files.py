#!/usr/bin/python
# -*- coding: UTF-8 -*-

import sys
import os
import confuse_utils

def copy_file(work_dir, bundle_id, src_file, dst_file):
	print('back archive file %s to %s' % (src_file, dst_file))
	confuse_utils.fast_copy_file(src_file, dst_file)
	confuse_utils.add_backup_file(work_dir, bundle_id, src_file, dst_file)
	pass

def convert_list_to_dict(items):
	ret = {}
	for item in items:
		pair = item.split('=')
		if len(pair) == 2:
			key = pair[0].strip()
			value = pair[1].strip()
			ret[key] = value
	return ret

def back_archive_files(work_dir, bundle_id, workspace_dir):
	print('##backup archive files %s %s' % (work_dir, bundle_id))
	#print workspace_dir
	package_dir = '%s/packages/%s' % (work_dir, bundle_id)
	backup_dir = '%s/back' % package_dir
	configs_file = '%s/confuse_archive_configs.txt' % (package_dir)
	if not os.path.exists(configs_file):
		return
	settings = confuse_utils.read_settings_file(configs_file)
	#print settings
	if 'archives' not in settings:
		return
	archives = settings['archives']
	for archive in archives:
		if archive not in settings.keys():
			print('❌ 出错了，没能找到第三方SDK %s 的相关信息，请检查配置是否正确.' % archive)
			sys.exit(1)
		archive_info = convert_list_to_dict(settings[archive])
		archive_file = archive_info['file']
		archive_path = '%s/%s' % (workspace_dir, archive_file)
		if archive_path.endswith('.framework'):
			archive_path = '%s/%s' % (archive_path, confuse_utils.get_file_name(archive_file))
		backup_file = '%s/%s' % (backup_dir, archive_file.replace('../', '{..}/'))
		copy_file(work_dir, bundle_id, archive_path, backup_file)
	pass

def main(argv):
	if len(argv) != 4:
		print('python back_archive_files.py [work dir] [bundle id] [workspace dir]')
		sys.exit(1)
	back_archive_files(argv[1], argv[2], argv[3])

main(sys.argv)