#!/usr/bin/python
# -*- coding: UTF-8 -*-

import sys
import os
import confuse_utils
import json

#LinkStoryboards (in target: DebugModel)
#    cd /Users/crab/Desktop/DebugModel
#    export XCODE_DEVELOPER_USR_PATH=/Applications/Xcode.app/Contents/Developer/usr/bin/..
#    /Applications/Xcode.app/Contents/Developer/usr/bin/ibtool --errors --warnings --notices --module DebugModel --target-device iphone --minimum-deployment-target 9.0 --output-format human-readable-text 
#--link /Users/crab/Desktop/DebugModel/Products/Debug-iphoneos/DebugModel.app /Users/crab/Desktop/DebugModel/Build/Intermediates.noindex/DebugModel.build/Debug-iphoneos/DebugModel.build/Base.lproj/LaunchScreen.storyboardc /Users/crab/Desktop/DebugModel/Build/Intermediates.noindex/DebugModel.build/Debug-iphoneos/DebugModel.build/Base.lproj/Main.storyboardc

def link_storyboard_files(work_dir, bundle_id, main_project_file, target_name, configure, product_type, product_file, install_dir, project_file, product_target_name, src_files, ref_folders):
	print('##link storyboard by target %s files:%s##' % (product_target_name, src_files))
	package_dir = '%s/packages/%s' % (work_dir, bundle_id)
	cmds = []
	new_target_name = confuse_utils.get_symbol_new_name(work_dir, bundle_id, target_name, 'target')
	new_product_target_name = confuse_utils.get_symbol_new_name(work_dir, bundle_id, product_target_name, 'target')
	app_build_settings = confuse_utils.get_build_settings(work_dir, bundle_id, main_project_file, configure, target_name, use_cache_file=True)
	app_product_file = confuse_utils.get_build_settings_value(app_build_settings, 'FULL_PRODUCT_NAME', '')
	build_settings = confuse_utils.get_build_settings(work_dir, bundle_id, project_file, configure, product_target_name, use_cache_file=True)
	module_name = confuse_utils.get_build_settings_value(app_build_settings, 'MODULE_NAME', '')
	file_name = '%s/%s_environment_variables.txt' % (package_dir, target_name)
	envs = confuse_utils.read_properties_file(file_name)

	#new_target_name = confuse_utils.get_new_name(work_dir, bundle_id, target_name, 'target')
	supported_device_families = envs['SUPPORTED_DEVICE_FAMILIES']
	items = supported_device_families.split(',')
	target_devices = []

	for item in items:
		if item == '1':
			target_devices.append('iphone')
		elif item == '2':
			target_devices.append('ipad')

	archive_path = '%s/%s.xcarchive' % (package_dir, target_name)
	cmd = '${SYSTEM_DEVELOPER_BIN_DIR}/ibtool --errors --warnings --notices'
	cmd = '%s --module \"%s\"' % (cmd, module_name)
	for target_device in target_devices:
		cmd = '%s --target-device %s' % (cmd, target_device)
	cmd = '%s --minimum-deployment-target ${IPHONEOS_DEPLOYMENT_TARGET}' % (cmd)

	if product_type == '.appe':
		cmd = '%s --link \"%s/Products/Applications/%s/PlugIns/%s\"' % (cmd, archive_path, app_product_file, product_file)
	elif product_type == '.bundle':
		cmd = '%s --link \"%s/Products/Applications/%s/%s\"' % (cmd, archive_path, app_product_file, product_file)
	elif product_type == '.framework':
		cmd = '%s --link \"%s/Products/Applications/%s/Frameworks/%s\"' % (cmd, archive_path, app_product_file, product_file)
	else:
		cmd = '%s --link \"%s/Products/Applications/%s\"' % (cmd, archive_path, app_product_file)

	outfiles = []
	for src_file in src_files:
		dst_file = confuse_utils.get_file_rename(work_dir, bundle_id, src_file)
		file_name = confuse_utils.get_file_name(dst_file)
		src_dir = 'Base.lproj'
		#remove file
		if product_type == '.appe':
			file_path = '%s/Products/Applications/%s/PlugIns/%s/%s/%s.storyboardc' % (archive_path, app_product_file, product_file, src_dir, file_name)
		elif product_type == '.bundle':
			file_path = '%s/Products/Applications/%s/%s/%s.storyboardc' % (archive_path, app_product_file, product_file, file_name)
		elif product_type == '.framework':
			file_path = '%s/Products/Applications/%s/Frameworks/%s/%s.storyboardc' % (archive_path, app_product_file, product_file, file_name)
		else:
			file_path = '%s/Products/Applications/%s/%s/%s.storyboardc' % (archive_path, app_product_file, src_dir, file_name)
		cmds.append('rm -rf \"%s\"' % (file_path))
		outfile = '${TEMP_DIR}/%s/%s.storyboardc' % (src_dir, file_name)
		cmd = '%s \"%s\"' % (cmd, outfile)
		outfiles.append(outfile)

	for outfile in outfiles:
		filename = confuse_utils.replace_text_vars(envs, outfile)
		if os.path.exists(filename) == False:
			print('not found %s' % filename)
			sys.exit(1)
			
	cmds.append(cmd)

	for cmd in cmds:
		cmd_txt = confuse_utils.replace_text_vars(envs, cmd)
		print(cmd_txt)
		ret = os.system(cmd_txt)
		if ret != 0:
			sys.exit(ret)
	pass

def main(argv):
	if len(argv) != 13:
		print('python link_storyboard_files.py [work dir] [bundle id] [main project file] [target name] [configure] [product type] [product file] [install dir] [project file] [product target name] [src files] [ref floders]')
		return
	link_storyboard_files(argv[1], argv[2], argv[3], argv[4], argv[5], argv[6], argv[7], argv[8], argv[9], argv[10], confuse_utils.load_array_file(argv[11]), confuse_utils.load_array_file(argv[12]))
	
main(sys.argv)