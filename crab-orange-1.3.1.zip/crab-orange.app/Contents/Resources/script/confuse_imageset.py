#!/usr/bin/python
# -*- coding: UTF-8 -*-

import sys
import os
import confuse_utils
import image_utils
from PIL import Image, PngImagePlugin

import json
from pbxproj import XcodeProject

#import png
import random
import importlib

importlib.reload(sys)
#sys.setdefaultencoding("utf-8")

def get_contents_json(filename):
	with open(filename, 'r') as json_str:
		return json.load(json_str)
	return {}

def save_contents_json(filename, contents_json):
	with open(filename, 'w') as f:
		json.dump(contents_json, f)

def inflate_png_file(bundle_id, filename):
	img_file_back = filename + ".back"
	try:
		if os.path.exists(filename):
			ext = confuse_utils.get_file_extension(filename)
			if ext != 'png':
				return
			if not os.path.exists(img_file_back):
				os.rename(filename, img_file_back)
			img = Image.open(filename)
			png_info = PngImagePlugin.PngInfo()
			png_info.add_text('Author', bundle_id)
			img.save(filename, png_info=png_info)
			os.remove(img_file_back)
	except Exception as e:
		os.rename(img_file_back, filename)
		print('warning:inflate png error in %s %s' % (filename, e))
		pass

#def rename_image(filedir, imagename, newimagename, image_json, contents_json):
#	filename = filedir + '/' + imagename
#	newfilename = filedir + '/' + newimagename
#	image_json['filename'] = newimagename

#	if os.path.exists(filename):
#		print 'rename %s to %s' % (filename, newfilename)
#		os.rename(filename, newfilename)
#	save_contents_json(filedir + '/Contents.json', contents_json)
#	pass

def process_imageset_content(imagesetdir,package_dir,bundle_id):
	filename = imagesetdir + '/Contents.json'
	if os.path.exists(filename) == False:
		print('warning:not found %s' % filename)
		return
	need_rewrite = False
	contents_json = get_contents_json(filename)
	if 'images' in contents_json:
		images = contents_json['images']
		for image in images:
			if 'filename' in image:
				img_file = imagesetdir + '/' + image['filename']
				img_file_back = img_file + ".back"
				file_name = confuse_utils.get_file_name(img_file)
				file_ext = confuse_utils.get_file_extension(img_file)
				imageset_name = confuse_utils.get_file_name(imagesetdir)
				idx = file_name.rfind('@')
				if idx != -1:
					new_img_file = imageset_name + file_name[idx:] + '.' + file_ext
				else:
					new_img_file = imageset_name + '.' + file_ext
				image['filename'] = new_img_file
				try:
					if not os.path.exists(img_file):
						print('warning:no found %s' % img_file)
					else:
						if os.path.exists(img_file_back):
							if os.path.exists(img_file):
								os.remove(img_file)
							os.rename(img_file_back, img_file)
						os.link(img_file, img_file_back)
						src_img = Image.open(img_file)
						image_utils.encode_key_to_image(src_img, bundle_id)
						os.remove(img_file)
						src_img.save(img_file)
						os.remove(img_file_back)
						#inflate_png_file(bundle_id, img_file)
						os.rename(img_file, imagesetdir + '/' + new_img_file)
						need_rewrite = True
				except:
					os.rename(img_file_back, img_file)
					print('warning:io error in %s' % (img_file))
				#insert_text_chunk(imagepath, '%d-%d-%d' % (random.randint(0, 255), random.randint(0, 255), random.randint(0, 255)))
	if need_rewrite:
		os.remove(filename)
		with open(filename, 'w') as f:
			f.write(json.dumps(contents_json,ensure_ascii=False,indent=2))
			f.close()

def confuse_imageset_file(work_dir, bundle_id, main_project_file, target_name, configure, product_type, product_file, install_dir, project_file, product_target_name, src_file, ref_folder):
	package_dir = '%s/packages/%s' % (work_dir, bundle_id)
	print('##confuse imageset file %s##' % (src_file))
	#ImageFile.LOAD_TRUNCATED_IMAGES = True
	confuse_utils.dbfile_lock()
	src_dir = confuse_utils.get_file_rename(work_dir, bundle_id, src_file)
	confuse_utils.dbfile_unlock()
	process_imageset_content(src_dir, package_dir, bundle_id)
	pass

def main(argv):
	confuse_utils.print_cmd(argv)
	if len(argv) != 13:
		print('python confuse_imageset_file.py [work dir] [bundle id] [main project file] [target name] [configure] [product type] [product file] [install dir] [project file] [product target name] [src file] [ref folder]')
		sys.exit(1)
	confuse_imageset_file(argv[1], argv[2], argv[3], argv[4], argv[5], argv[6], argv[7], argv[8], argv[9], argv[10], argv[11], argv[12])
	
main(sys.argv)