#!/usr/bin/python
# -*- coding: UTF-8 -*-

import sys
import os
import getpass
import confuse_utils
import hashlib

### IDENTIFIER 1523ABF15654585452548AB
### PRODUCT_IDENTIFIER 1523ABF15654585452548AB
### TARGET_NAME TestObjC
### PRODUCT_TARGET_NAME TestObjCExt
### PROJECT_FILE TestObjC.xcodeproj
### BUNDLE_ID test.objc.bundle.id
### APP_PATH /Users/crab/XXXX.app
### APPEXT_PATH /Users/crab/XXXX.appext

def create_identifier(target_name):
	v = confuse_utils.md5str(target_name)
	return v[0:24].upper()

def write_template_file(template_file_name, out_file_name, envs):
	lines = []
	with open(template_file_name, 'r') as fin:
		lines = fin.readlines()
		fin.close()

	with open(out_file_name, 'w') as fout:
		for line in lines:
			i = 0
			while i < len(line):
				start = line.find('####')
				if start == -1:
					break
				end = line.find('####', start + 4)
				if end == -1:
					break;
				name = line[start + 4:end]
				if name in envs:
					line = line[0:start] + envs[name] + line[end + 4:]
				else:
					line = line[0:start] + line[end + 4:]
			fout.write(line)
		fout.close()
	pass

def copy_xcscheme(work_dir, bundle_id, main_project_file, configure, resource_dir, target_name, project_file, product_type, product_target_name):
	print('##copy xcscheme %s to %s##' % (product_target_name, project_file))
	new_target_name = confuse_utils.get_symbol_new_name(work_dir, bundle_id, target_name, 'target')
	new_product_target_name = '%s(%s)' % (product_target_name, bundle_id)
	if target_name != product_target_name:
		app_build_settings = confuse_utils.get_build_settings(work_dir, bundle_id, main_project_file, configure, target_name, True)
		app_product_file = confuse_utils.get_build_settings_value(app_build_settings, 'FULL_PRODUCT_NAME', '')
	build_settings = confuse_utils.get_build_settings(work_dir, bundle_id, project_file, configure, product_target_name, True)
	package_dir = '%s/packages/%s' % (work_dir, bundle_id)
	envs = {}
	md5_bundle_id = confuse_utils.md5str(bundle_id)
	envs['BUNDLE_ID'] = bundle_id
	envs['IDENTIFIER'] = create_identifier(target_name)
	envs['PRODUCT_TARGET_NAME'] = create_identifier(product_target_name)
	envs['TARGET_NAME'] = target_name
	envs['NEW_TARGET_NAME'] = new_target_name
	envs['PRODUCT_TARGET_NAME'] = product_target_name
	envs['NEW_PRODUCT_TARGET_NAME'] = new_product_target_name
	envs['PROJECT_FILE'] = confuse_utils.get_full_file_name(project_file)
	product_file = confuse_utils.get_build_settings_value(build_settings, 'FULL_PRODUCT_NAME', '')

	plist_template_file = '%s/xcschememanagement.plist' % resource_dir
	if product_type == '.app':
		scheme_template_file = '%s/app.xcscheme' % resource_dir
		envs['APP_PATH'] = '%s/%s.xcarchive/Products/Applications/%s' % (package_dir, target_name, product_file)
		#print('APP_PATH:%s' % envs['APP_PATH'])
		pass
	elif product_type == '.appext':
		scheme_template_file = '%s/appext.xcscheme' % resource_dir
		envs['APPEXT_PATH'] = '%s/%s.xcarchive/Products/Applications/%s/PlugIns/%s.appext' % (package_dir, target_name, app_product_file, product_file)
		#print('APPEXT_PATH:%s' % envs['APP_PATH'])
		pass

	dirname = '%s/xcuserdata/%s.xcuserdatad/xcschemes' % (project_file, getpass.getuser())
	plist_file = '%s/xcschememanagement.plist' % dirname
	shared_path = '%s/xcshareddata/xcschemes/%s.xcscheme' % (project_file, product_target_name)
	if os.path.exists(shared_path):
		envs['SCHEME_NAME'] = '%s.xcscheme_^#shared#^_' % new_product_target_name
		shared_path = '%s/xcshareddata/xcschemes/%s.xcscheme' % (project_file, new_product_target_name)
		write_template_file(scheme_template_file, shared_path, envs)
		confuse_utils.add_temp_file(work_dir, bundle_id, shared_path)
		if os.path.exists(plist_file):
			write_template_file(plist_template_file, plist_file, envs)
			confuse_utils.add_temp_file(work_dir, bundle_id, plist_file)
		return

	user_path = '%s/%s.xcscheme' % (dirname, product_target_name)
	if os.path.exists(user_path):
		envs['SCHEME_NAME'] = '%s.xcscheme' % new_product_target_name
		user_path = '%s/%s.xcscheme' % (dirname, new_product_target_name)
		write_template_file(scheme_template_file, user_path, envs)
		if os.path.exists(plist_file):
			write_template_file(plist_template_file, plist_file, envs)
		return
	
	os.system('mkdir -p %s' % dirname)
	user_path = '%s/%s.xcscheme' % (dirname, new_product_target_name)
	envs['SCHEME_NAME'] = '%s.xcscheme' % new_product_target_name
	write_template_file(scheme_template_file, user_path, envs)
	confuse_utils.add_temp_file(work_dir, bundle_id, user_path)
	if os.path.exists(plist_file):
		write_template_file(plist_template_file, plist_file, envs)
		confuse_utils.add_temp_file(work_dir, bundle_id, plist_file)
	pass

def main(argv):
	confuse_utils.print_cmd(argv)
	if len(argv) != 10:
		print('python copy_scheme.py [work dir] [bundle id] [main project file][configure] [resource dir] [target name] [project file] [product type] [product target name]')
		sys.exit(1)
	copy_xcscheme(argv[1], argv[2], argv[3], argv[4], argv[5], argv[6], argv[7], argv[8], argv[9])

main(sys.argv)