#!/usr/bin/python
# -*- coding: UTF-8 -*-

import sys
import os
import confuse_utils
import struct
import importlib

importlib.reload(sys)
#sys.setdefaultencoding('utf8')

def copy_file(work_dir, bundle_id, main_project_file, target_name, configure, product_type, product_file, install_dir, project_file, product_target_name, src_file, ref_folder):
	print('##copy resource %s##' % src_file)
	package_dir = '%s/packages/%s' % (work_dir, bundle_id)
	confuse_utils.dbfile_lock()
	app_build_settings = confuse_utils.get_build_settings(work_dir, bundle_id, main_project_file, configure, target_name, True)
	app_product_file = confuse_utils.get_build_settings_value(app_build_settings, 'FULL_PRODUCT_NAME', '')
	src_file = confuse_utils.get_file_rename(work_dir, bundle_id, src_file)
	confuse_utils.dbfile_unlock()
	file_name = confuse_utils.get_full_file_name(src_file)
	if len(ref_folder):
		file_name = ref_folder + '/' + file_name
	archive_path = '%s/%s.xcarchive' % (package_dir, target_name)
	if product_type == '.appe':
		file_path = '%s/Products/Applications/%s/PlugIns/%s/%s' % (archive_path, app_product_file, product_file, file_name)
	elif product_type == '.bundle':
		file_path = '%s/Products/Applications/%s/%s/%s' % (archive_path, app_product_file, product_file, file_name)
	elif product_type == '.framework':
		file_path = '%s/Products/Applications/%s/Frameworks/%s/%s' % (archive_path, app_product_file, product_file, file_name)
	else:
		file_path = '%s/Products/Applications/%s/%s' % (archive_path, app_product_file, file_name)
	confuse_utils.copy_file(src_file, file_path)
	pass

def main(argv):
	confuse_utils.print_cmd(argv)
	if len(argv) != 13:
		print('python copy_file.py [work dir] [bundle id] [main project file] [target name] [configure] [product type] [product file] [install dir] [project file] [product target name] [src file] [ref folder]')
		return
	copy_file(argv[1], argv[2], argv[3], argv[4], argv[5], argv[6], argv[7], argv[8], argv[9], argv[10], argv[11], argv[12])
	
main(sys.argv)