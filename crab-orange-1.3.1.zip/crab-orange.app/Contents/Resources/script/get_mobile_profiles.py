#!/usr/bin/python
# -*- coding: UTF-8 -*-

import sys
import confuse_utils
import json

def get_mobile_profiles(bundle_id, configure):
	ret = confuse_utils.get_mobile_device_profiles(bundle_id, configure)
	print(json.dumps(ret,ensure_ascii=False))
	pass

def main(argv):
	if len(argv) != 3:
		print('python get_mobile_profiles.py [bundle id] [configure]')
		sys.exit(1)
	
	get_mobile_profiles(argv[1], argv[2])

main(sys.argv)