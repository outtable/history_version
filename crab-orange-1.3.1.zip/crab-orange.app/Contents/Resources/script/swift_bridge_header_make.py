#!/usr/bin/python
# -*- coding: UTF-8 -*-
import sys
import os
import confuse_utils
import json
import shutil
import importlib
import hmap

importlib.reload(sys)
#sys.setdefaultencoding("utf-8")

PRODUCT_TYPE_FRAMEWORK = 'com.apple.product-type.framework'

def get_swift_file_list_path(work_dir, bundle_id, project_name, target_name):
	target_dir = confuse_utils.get_swift_bridge_headers_dir(work_dir, bundle_id, project_name, target_name)
	return '%s/Swift.FileList.txt' % (target_dir)

def gen_swift_list_file(work_dir, bundle_id, project_name, target_name, swift_source_files):
	target_dir = confuse_utils.get_swift_bridge_headers_dir(work_dir, bundle_id, project_name, target_name)
	if os.path.exists(target_dir):
		shutil.rmtree(target_dir)
	os.makedirs(target_dir)
	with open('%s/Swift.FileList.txt' % (target_dir), 'w') as save_f:
		for swift_source_file in swift_source_files:
			path = swift_source_file['path'].replace(' ', '\\ ')
			save_f.write('%s\n' % path)
		save_f.close()

def find_target(projects, dependencie):
	target_name = dependencie['target']
	project_name = dependencie['project']
	for project in projects:
		if project['name'] != project_name:
			continue
		for target in project['targets']:
			if target['name'] == target_name:
				return target, project
	return None, None

def get_depend_target_user_header_search_paths(work_dir, bundle_id, configure, projects, project, target, history):
	project_file = project['path']
	build_settings = confuse_utils.get_build_settings(work_dir, bundle_id, project_file, configure, target['name'], True)
	alwaysSearchUserPaths = confuse_utils.get_build_settings_value(build_settings, 'ALWAYS_SEARCH_USER_PATHS', 'YES')
	ret = []
	if alwaysSearchUserPaths == 'YES':
		ret = confuse_utils.get_user_header_search_paths_settings_value(build_settings)
	dependencies = target['dependencies']
	for dependencie in dependencies:
		findtarget,findproject = find_target(projects, dependencie)
		if findtarget == None or findtarget['name'] in history:
			continue
		paths = get_depend_target_user_header_search_paths(work_dir, bundle_id, configure, projects, findproject, findtarget, history)
		for path in paths:
			if path not in ret:
				ret.append(path)
		history.append(findtarget['name'])
	return ret

def gen_modules_file(cmds, work_dir, bundle_id, module_name, swift_header_file, header_dir, modules_dir, file_name, public_header_map_file):
	path = '%s/%s' % (modules_dir, file_name)
	hmap_file = hmap.HMapFile()
	hmap_file.load(public_header_map_file)
	file_map = hmap_file.map()
	
	print('😄 生成 %s' % path)
	with open(path, 'w') as f:
		text = ''
		text += 'framework module %s {\n' % module_name
		for key in file_map.keys():
			value = file_map[key]
			if value.startswith('\"') or value.endswith('\"'):
				value = value[1:-1]
			if value.startswith('\'') or value.endswith('\''):
				value = head_file[1:-1]
			full_name = confuse_utils.get_full_file_name(value)
			if value.find(module_name) != -1:
				cmds.append('echo "😄 link head file %s"' % full_name)
				cmds.append('link \"%s\" \"%s/%s\"' % (key, header_dir, confuse_utils.pstr(full_name)))
				if full_name.find('-umbrella.h') != -1:
					text += '\n  umbrella header \"%s\"\n' % full_name
		text += '\n  export *\n'
		text += '  module * { export * }\n'
		text += '}\n'
		text += 'module %s.Swift {\n' % module_name
		text += '  header \"%s\"\n' % swift_header_file
		text += '  requires objc\n'
		text += '}\n'
		f.write(text)
		f.close()

target_history = []

def create_swift_bridge_file_cmd(work_dir, bundle_id, main_target_name, new_main_target_name, project_name, target_name, build_settings, project_header_map_file, public_header_map_file, depend_user_header_search_paths, depend_project_header_map_files, depend_public_header_map_files):
	key = '%s.%s' % (project_name, target_name)
	if key in target_history:
		return
	target_history[key] = True
	print('target:%s' % target_name)
	ret_cmds = []
	framework_search_paths = confuse_utils.get_framework_search_paths_settings_value(build_settings)
	system_framework_search_paths = confuse_utils.get_system_framework_search_paths_settings_value(build_settings)

	head_search_paths = confuse_utils.get_header_search_paths_settings_value(build_settings)
	useHeaderMap = confuse_utils.get_build_settings_value(build_settings, 'USE_HEADERMAP', 'YES')
	user_head_search_paths = []
	if useHeaderMap == 'YES':
		user_head_search_paths = confuse_utils.get_user_header_search_paths_settings_value(build_settings)
	macros = confuse_utils.get_preprocess_settings_value(build_settings)
	dt_toolchain_dir = confuse_utils.get_build_settings_value(build_settings, 'DT_TOOLCHAIN_DIR', '')
	sdk_root = confuse_utils.get_build_settings_value(build_settings, 'SDKROOT', '')
	objc_bridge_header = confuse_utils.get_build_settings_value(build_settings, 'SWIFT_OBJC_BRIDGING_HEADER', '')
	source_root = confuse_utils.get_build_settings_value(build_settings, 'SOURCE_ROOT', '')
	product_name = confuse_utils.get_build_settings_value(build_settings, 'PRODUCT_NAME', '')
	swift_objc_interface_header_name = confuse_utils.get_build_settings_value(build_settings, 'SWIFT_OBJC_INTERFACE_HEADER_NAME', '')
	if objc_bridge_header.startswith('/') == False and len(objc_bridge_header):
		objc_bridge_header = '%s/%s' % (source_root, objc_bridge_header)
	project_type = confuse_utils.get_build_settings_value(build_settings, 'PRODUCT_TYPE', '')
	macho_type = confuse_utils.get_build_settings_value(build_settings, 'MACH_O_TYPE', '')
	full_product_name = confuse_utils.get_build_settings_value(build_settings, 'FULL_PRODUCT_NAME', '')
	os_version = confuse_utils.get_build_settings_value(build_settings, 'LLVM_TARGET_TRIPLE_OS_VERSION', '13.0')
	swift_version = int(float(confuse_utils.get_build_settings_value(build_settings, 'SWIFT_VERSION', '5')))
	product_module = confuse_utils.get_build_settings_value(build_settings, 'PRODUCT_MODULE_NAME', product_name)
	def_swift_header = '%s-Swift.h' % (confuse_utils.format_product_name(product_module))
	swift_header_name = confuse_utils.get_build_settings_value(build_settings, 'SWIFT_OBJC_INTERFACE_HEADER_NAME', def_swift_header)
	swift_bridge_headers_dir = confuse_utils.get_swift_bridge_headers_dir(work_dir, bundle_id, project_name, target_name)
	swift_header_file = '%s/%s' % (confuse_utils.pstr(swift_bridge_headers_dir), swift_header_name)
	define_module_file = confuse_utils.get_build_settings_value(build_settings, 'DEFINES_MODULE', False)
	if target_name == main_target_name:
		product_module = confuse_utils.format_product_name(new_main_target_name)
	cmd = '%s/usr/bin/swiftc -c -module-name \"%s\"' % (dt_toolchain_dir, product_module)
	cmd = '%s \"@%s\"' % (cmd, get_swift_file_list_path(work_dir, bundle_id, project_name, target_name))
	cmd = '%s -sdk %s' % (cmd, sdk_root)
	cmd = '%s -target arm64-apple-%s' % (cmd, os_version)
	cmd = '%s -module-cache-path %s/xcode/DerivedData/ModuleCache.noindex' % (cmd, work_dir)
	cmd = '%s -Xfrontend -serialize-debugging-options -enable-testing ' % (cmd)
	cmd = '%s -swift-version %d' % (cmd,swift_version)
	#cmd = '%s -I %s' % (cmd, project_header_map_file)

	cmd = "%s -Xcc -idirafter%s" % (cmd, project_header_map_file)
	cmd = "%s -Xcc -iquote -Xcc %s" % (cmd, project_header_map_file)
	cmd = "%s -Xcc -I%s" % (cmd, public_header_map_file)

	cmd = '%s -j12 ' % (cmd)
	
	for framework_search_path in system_framework_search_paths:
		if len(framework_search_path):
			cmd = "%s -Xcc \"-iframework%s\"" % (cmd, framework_search_path)

	cmd = "%s -F\"%s\"" % (cmd, confuse_utils.get_swift_bridge_headers_dir(work_dir, bundle_id))
	#cmd = "%s -iquote\"%s\"" % (cmd, confuse_utils.get_swift_bridge_headers_dir(work_dir, bundle_id, project_name, target_name))

	for framework_search_path in framework_search_paths:
		if len(framework_search_path) > 0:
			cmd = "%s -F\"%s\"" % (cmd, confuse_utils.pstr(framework_search_path))

	for head_search_path in head_search_paths:
		if len(head_search_path) > 0:
			cmd = "%s -Xcc \"-I%s\"" % (cmd, confuse_utils.pstr(head_search_path))

	for user_head_search_path in user_head_search_paths:
		if len(user_head_search_path) > 0:
			cmd = "%s -Xcc -iquote -Xcc \"%s\"" % (cmd, confuse_utils.pstr(user_head_search_path))

	for user_head_search_path in depend_user_header_search_paths:
		if len(user_head_search_path) > 0:
			cmd = "%s -Xcc -iquote -Xcc \"%s\"" % (cmd, confuse_utils.pstr(user_head_search_path))

	#print('😄:%s' % target_name)
	for project_header_map_file in depend_project_header_map_files:
		if len(project_header_map_file) > 0:
			#print('😊:%s' %project_header_map_file )
			args = "%s -Xcc -iquote -Xcc \"%s\"" % (cmd, project_header_map_file)

	for project_header_map_file in depend_public_header_map_files:
		if len(project_header_map_file) > 0:
			#print('😄:%s' % project_header_map_file)
			args = "%s -Xcc \"-I%s\"" % (cmd, project_header_map_file)

	for macro in macros:
		if len(macro) > 0:
			cmd = "%s -Xcc -D%s" % (cmd, macro)

	# 应该是无用的
	#if not define_module_file:
	#	other_ldflags_macros = confuse_utils.get_other_ldflags_settings_value(build_settings)
	#	for macro in other_ldflags_macros:
	#			cmd = "%s -Xcc %s" % (cmd, macro)
	
	#cmd = '%s -iquote%s' % (cmd, public_header_map_file)
	#print('😄:%s' % target_name)
	#print('public_header_map_file:%s' % (public_header_map_file))
	header_dir = confuse_utils.get_swift_bridge_headers_dir(work_dir, bundle_id, project_name, target_name) + '/' + full_product_name + '/Headers'
	if os.path.exists(header_dir):
		shutil.rmtree(header_dir)
	os.makedirs(header_dir)
	modules_dir = confuse_utils.get_swift_bridge_headers_dir(work_dir, bundle_id, project_name, target_name) + '/' + full_product_name + '/Modules'
	if os.path.exists(modules_dir):
		shutil.rmtree(modules_dir)
	os.makedirs(modules_dir)
	#print('1.创建 head dir : %s' % header_dir)
	#print('2.创建 module dir : %s' % modules_dir)
	cmd = '%s -emit-const-values' % cmd
	cmd = '%s -emit-objc-header -emit-objc-header-path \"%s/%s\"' % (cmd, header_dir, swift_header_name)
	if len(objc_bridge_header):
		cmd = '%s -import-objc-header \"%s\"' % (cmd, confuse_utils.pstr(objc_bridge_header))
	cmd = '%s -pch-output-dir \"%s\"' % (cmd, confuse_utils.pstr(swift_bridge_headers_dir))

	target_dir = confuse_utils.get_swift_bridge_headers_dir(work_dir, bundle_id, project_name, target_name)
	cmd = '%s -working-directory \"%s\"' % (cmd, target_dir)

	#if project_type == PRODUCT_TYPE_FRAMEWORK:
	#	cmd = '%s -import-underlying-module ' % cmd
	
	modulemapname = 'module.modulemap'
	copy_cmd = None
	gen_modules_cmds = []
	if project_type == PRODUCT_TYPE_FRAMEWORK:
		if define_module_file == True:
			gen_modules_file(gen_modules_cmds, work_dir, bundle_id, product_module, swift_header_name, header_dir, modules_dir, modulemapname, public_header_map_file)

		copy_cmd = 'link \"%s/%s\" \"%s\"' % (header_dir, swift_header_name, swift_header_file)

	if define_module_file:
		swift_module_dir = '%s/%s.swiftmodule' % (modules_dir, product_module)
		if os.path.exists(swift_module_dir):
			shutil.rmtree(swift_module_dir)
		os.makedirs(swift_module_dir)
		#cmd = '%s -emit-dependencies ' % (cmd)
		cmd = '%s -emit-module -emit-module-path \"%s/arm64-apple-ios.swiftmodule\"' % (cmd, swift_module_dir)
	for gen_module_cmd in gen_modules_cmds:
		ret_cmds.append(gen_module_cmd)
	ret_cmds.append(cmd)
	if copy_cmd != None:
		ret_cmds.append(copy_cmd)
	if project_type == PRODUCT_TYPE_FRAMEWORK:
		framework_dir = confuse_utils.get_swift_bridge_headers_dir(work_dir, bundle_id, project_name, target_name) + '/' + full_product_name
		ret_cmds.append('rm -rf \"%s/%s\"' % (confuse_utils.get_swift_bridge_headers_dir(work_dir, bundle_id), full_product_name))
		ret_cmds.append('mv \"%s\" \"%s\"' % (framework_dir,confuse_utils.get_swift_bridge_headers_dir(work_dir, bundle_id)))
	return ret_cmds

def get_project_dependenceies(projects, project_file):
	ret = []
	for project in projects:
		path = project['path']
		if path == project_file:
			targets = project['targets']
			for target in targets:
				dependencies =  target['dependencies']
				for dependencie in dependencies:
					ret.append(dependencie)
	return ret

def get_project_info_by_name(projects, name):
	for project in projects:
		if project['name'].endswith(name):
			return project
	return None

def get_depend_project_header_files(projects, project_file, project_header_map_files, public_header_map_files):
	dependencies = get_project_dependenceies(projects, project_file)
	for dependenc in dependencies:
		project_name = dependenc['project']
		target_name = dependenc['target']
		project_info = get_project_info_by_name(projects, project_name)
		project_header_map_files.append(project_info['project-header-map-file'])
		public_header_map_files.append(project_info['public-header-map-file'])

def append_once(arr, item):
	if item in arr:
		return
	arr.append(item)

def get_depend_targets(ret, project_info, target_name):
	targets = project_info['targets']
	project_name = project_info['name']
	for target in targets:
		if target['name'] == target_name:
			#print '####get_depend_targets####\n'
			#print '%s\n' % target
			if 'dependencies' in target:
				for item in target['dependencies']:
					if item['project'] != project_name:
						continue
					append_once(ret, item)
			break

def get_target_info_by_name(project_info, name):
	targets = project_info['targets']
	for target in targets:
		if target['name'] == name:
			return target
	return None

target_history = {}

def create_swift_bridge_cmds(ret_cmds, main_target_name, new_main_target_name, work_dir, bundle_id, projects, project_file, configure, project_info, target_info):
	project_name = project_info['name']
	target_name = target_info['name']
	key = '%s/%s' % (project_name, target_name)
	if key in target_history:
		return
	target_history[key] = True
	depend_targets = []
	get_depend_targets(depend_targets, project_info, target_name)
	for depend_target in depend_targets:
		create_swift_bridge_cmds(ret_cmds, main_target_name, new_main_target_name, work_dir, bundle_id, projects, project_file, configure, project_info, get_target_info_by_name(project_info, depend_target['target']))
	
	project_header_map_file = project_info['project-header-map-file']
	public_header_map_file = project_info['public-header-map-file']
	
	source_files = target_info['source-files']
	for source_file in source_files:
		if '.swift' in source_file:
			#print('target:%s' % target_name)
			build_settings = confuse_utils.get_build_settings(work_dir, bundle_id, project_file, configure, target_name, True)
			objc_bridge_header = confuse_utils.get_build_settings_value(build_settings, 'SWIFT_OBJC_INTERFACE_HEADER_NAME', '')
			#swift_bridge_header = confuse_utils.get_build_settings_value(build_settings, 'SWIFT_OBJC_INTERFACE_HEADER_NAME', '')
			#if len(objc_bridge_header) == 0:
			#	objc_bridge_header = confuse_utils.get_build_settings_value(build_settings, 'SWIFT_MODULE_NAME', '') + '-Swift.h'
				#continue
			#print('SWIFT_OBJC_INTERFACE_HEADER_NAME:%s' % objc_bridge_header)
			#if len(swift_bridge_header) == 0:
			#	continue
			swift_source_files = source_file['.swift']
			if len(swift_source_files) == 0:
				continue
			gen_swift_list_file(work_dir, bundle_id, project_file, target_name, swift_source_files)
			depend_user_header_search_paths = get_depend_target_user_header_search_paths(work_dir, bundle_id, configure, projects, project_info, target_info, [])
			depend_project_header_map_files = []
			depend_public_header_map_files = []
			get_depend_project_header_files(projects, project_file, depend_project_header_map_files, depend_public_header_map_files)
			new_cmds = create_swift_bridge_file_cmd(work_dir, bundle_id, main_target_name, new_main_target_name, project_file, target_name, build_settings, project_header_map_file, public_header_map_file, depend_user_header_search_paths, depend_project_header_map_files, depend_public_header_map_files)
			for new_cmd in new_cmds:
				ret_cmds.append(new_cmd)
			break

def swift_bridge_header_make(work_dir, bundle_id, main_project_file, main_bundle_id, main_target_name, configure, workspace_info_file):
	debug_enable = confuse_utils.get_run_settings_value(work_dir, bundle_id, 'debug', False)
	configure = 'Release'
	if debug_enable:
		configure = 'Debug'
	embed_swift = confuse_utils.get_run_settings_value(work_dir, bundle_id, 'embed-swift', False)
	if embed_swift != True:
		return

	print('##swift bridge header make %s' % (main_target_name))
	disable_rename_main_target = confuse_utils.get_run_settings_value(work_dir, bundle_id, 'disable-rename-main-target', False)
	if disable_rename_main_target:
		new_main_target_name = main_target_name
	else:
		new_main_target_name = confuse_utils.new_symbol_name(work_dir, bundle_id, main_target_name, 'target')
	
	cmds = []
	with open(workspace_info_file, 'r') as load_f:
		js = json.load(load_f)
		workspace_dir = confuse_utils.get_file_dir(js['workspace-file'])
		projects = js['projects']
		for project in projects:
			project_file = project['path']
			project_name = project['name']
			targets = project['targets']
			if len(targets) == 0:
				continue
			for target in targets:
				target_name = target['name']
				target_cmds = []
				create_swift_bridge_cmds(target_cmds, main_target_name, new_main_target_name, work_dir, bundle_id, projects, project_file, configure, project, target)
				for target_cmd in target_cmds:
					cmds.append(target_cmd)
    #pass
	for cmd in cmds:
		ret = confuse_utils.exec_cmd(cmd)
		if ret != 0:
			sys.exit(1)

#python '/Users/yangwei/Documents/myproject/ios-confuse/resource/crab-orange/resource/script/swift_bridge_header_make.py' '/Users/yangwei/Library/ipa-artifact' 'com.zuimeiqidai.ios.test.objc' 'test.objc' 'TestObjC' '/Users/yangwei/Library/ipa-artifact/packages/com.zuimeiqidai.ios.test.objc/workspace.profile'  
def main(argv):
	confuse_utils.print_cmd(argv)
	if len(argv) != 8:
		print('python swift_bridge_header_make.py [work dir] [bundle id] [main project file] [main bundle id] [main target name] [configure] [workspace info file]')
		sys.exit(1)
	swift_bridge_header_make(argv[1], argv[2], argv[3], argv[4], argv[5], argv[6], argv[7])

#print sys.argv
main(sys.argv)
