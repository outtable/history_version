from pbxproj.pbxsections.PBXGroup import PBXGroup

class XCVersionGroup(PBXGroup):
    pass
