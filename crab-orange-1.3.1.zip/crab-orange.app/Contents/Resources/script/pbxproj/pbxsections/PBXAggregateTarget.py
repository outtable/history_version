from pbxproj.pbxsections.PBXGenericTarget import PBXGenericTarget


class PBXAggregateTarget(PBXGenericTarget):
    pass
