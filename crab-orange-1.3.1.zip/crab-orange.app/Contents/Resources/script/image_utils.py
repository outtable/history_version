#!/usr/bin/python
# -*- coding: utf-8 -*-  

from PIL import Image

def get_key(bundle_id):
	key = bundle_id
	for i in range(0, 100):
		if len(key) >= 1024:
			break
		key += bundle_id
	return key

def message_to_binary(msg):
	if type(msg) == str:
		return ''.join([format(ord(i), '08b') for i in msg])
	elif type(msg) == bytes:
		return [format(i, '08b') for i in msg]
	elif type(msg) == int:
		return format(msg, '08b')
	else:
		raise TypeError('type error.')

def encode_key_to_image(image, bundle_id):
	secret_message = get_key(bundle_id)
	data_index = 0
	binary_secret_msg = message_to_binary(secret_message)
	data_len = len(binary_secret_msg)
	width = image.size[0]
	height = image.size[1]
	mode = image.mode
	if mode not in ('L', 'I', 'RGB', 'RGBA', 'CMYK'):
		return
	for y in range(0, height):
		for x in range(0, width):
			pixel = image.getpixel((x, y))
			if type(pixel) == int:
				if data_index < data_len:
					w = message_to_binary(pixel)
					w = int(w[:-1] + binary_secret_msg[data_index], 2)
					data_index += 1
					image.putpixel((x, y), w)
				break
			else:
				pixel_len = len(pixel)
				r = pixel[0]
				if pixel_len > 1:
					g = pixel[1]
				if pixel_len > 2:
					b = pixel[2]
				if pixel_len > 3:
					a = pixel[3]
				if data_index < data_len:
					r = message_to_binary(r)
					r = int(r[:-1] + binary_secret_msg[data_index], 2)
					data_index += 1
				if data_index < data_len and pixel_len > 1:
					g = message_to_binary(g)
					g = int(g[:-1] + binary_secret_msg[data_index], 2)
					data_index += 1
				if data_index < data_len and pixel_len > 2:
					b = message_to_binary(b)
					b = int(b[:-1] + binary_secret_msg[data_index], 2)
					data_index += 1
				if pixel_len == 4:
					image.putpixel((x, y), (r, g, b, a))
				elif pixel_len == 3:
					image.putpixel((x, y), (r, g, b))
				elif pixel_len == 2:
					image.putpixel((x, y), (r, g))
				else:
					image.putpixel((x, y), (r))
			if data_index >= data_len:
				break
	pass

