#!/usr/bin/python
# -*- coding: UTF-8 -*-

import sys
import os
import confuse_utils

def get_install_dir(install_path):
	last_idx = install_path.find('}')
	dir_name = install_path[2:last_idx]
	sub_dir = install_path[last_idx + 1:]
	return '%s%s' % (dir_name, sub_dir)

def code_sign_embed(work_dir, bundle_id, main_project_file, configure, target_name, project_file, product_type, product_target_name, file_path, install_path):
	new_target_name = confuse_utils.get_symbol_new_name(work_dir, bundle_id, target_name, 'target')
	new_product_target_name = confuse_utils.get_symbol_new_name(work_dir, bundle_id, product_target_name, 'target')
	app_build_settings = confuse_utils.get_build_settings(work_dir, bundle_id, main_project_file, configure, target_name, use_cache_file=True)
	app_product_file = confuse_utils.get_build_settings_value(app_build_settings, 'FULL_PRODUCT_NAME', '')
	product_file_name = confuse_utils.get_full_file_name(file_path)
	print('##code sign embed file %s##' % (product_target_name))
	package_dir = '%s/packages/%s' % (work_dir, bundle_id)
	
	if install_path.startswith('${Unsupport}'):
		print('❌ code sign %s fail(install unsupport path %s).' % (file_path, install_path))
		sys.exit(1)

	if not install_path.startswith('${'):
		print('❌ code sign %s fail(install absolute path %s).' % (file_path, install_path))
		sys.exit(1)
		return

	install_dir = get_install_dir(install_path)
	#mp,has_config,identify = confuse_utils.get_mobile_provision_file_info(work_dir, bundle_id, configure, product_bundle_id, product_target_name)
	#if mp == None:
	mp,has_config,identify = confuse_utils.get_mobile_provision_file_info(work_dir, bundle_id, configure, bundle_id, target_name)
	
	mobile_provision = mp['FILE_NAME']
	sign_key = mp['CODE_SIGN_IDENTITY']
	archive_path = '%s/%s.xcarchive' % (package_dir, target_name)

	cmds = []

	if mobile_provision != None:
		cmd = '/usr/bin/security cms -D -i \"%s\" > \"%s/temp_%s_entitlements_full.plist\"' % (mobile_provision, package_dir, bundle_id)
		ret = confuse_utils.exec_cmd(cmd)
		if ret != 0:
			sys.exit(1)
		full_entitlements_plist = '%s/%s.entitlements.plist' % (package_dir, bundle_id)
		cmd = '/usr/libexec/PlistBuddy -x -c \'Print\' \"%s/temp_%s_entitlements_full.plist\" > \"%s\"' % (package_dir, bundle_id, full_entitlements_plist)
		ret = confuse_utils.exec_cmd(cmd)
		if ret != 0:
			sys.exit(1)
		confuse_utils.write_configure_entitlements(work_dir, bundle_id, package_dir, project_file, product_target_name, configure, full_entitlements_plist)

	dst_file = '%s/Products/Applications/%s/%s/%s' % (archive_path, app_product_file, install_dir, product_file_name)
	if not os.path.exists(dst_file):
		print('⚠️ 找不到 %s' % dst_file)
		return
	cmd = '/usr/bin/codesign -f -s \"%s\" --preserve-metadata=identifier,entitlements,flags \"%s\"' % (sign_key, dst_file)
	ret = confuse_utils.exec_cmd(cmd)
	if ret != 0:
		sys.exit(1)
	pass

def main(argv):
	confuse_utils.print_cmd(argv)
	if len(argv) != 11:
		print('python code_sign_embed.py [work dir] [bundle id] [main project file] [Debug/Release] [target name] [project file] [product type] [product target] [file path] [install path]')
		sys.exit(1)
	code_sign_embed(argv[1], argv[2], argv[3], argv[4], argv[5], argv[6], argv[7], argv[8], argv[9], argv[10])

main(sys.argv)