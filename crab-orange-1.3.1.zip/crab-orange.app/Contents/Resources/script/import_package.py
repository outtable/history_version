#!/usr/bin/python
# -*- coding: UTF-8 -*-

import sys
import os
import zipfile
from xml.dom.minidom import parse
import xml.dom.minidom
import biplist
import plistlib
import json
import confuse_utils

def import_package(file_name, work_dir, bundle_id):
	package_dir = '%s/packages/%s' % (work_dir, bundle_id)
	f = zipfile.ZipFile(file_name)
	f.extractall(package_dir)

	depends_dir = '%s/depends' % package_dir

	depend_files = confuse_utils.read_settings_file(package_dir + '/depend_files.txt')

	info_plist_items = []
	if '*.plist' in depend_files:
		info_plist_items = depend_files['*.plist']

	info_plist_file = None
	if len(info_plist_items):
		info_plist_file = depends_dir + '/' + info_plist_items[0].replace('{..}/', '../')
	
	bundle_display_name = ''

	if info_plist_file != None:
		with open(info_plist_file, 'rb') as f:
			jsobj = biplist.readPlist(f)

			if 'CFBundleDisplayName' in jsobj:
				bundle_display_name = jsobj['CFBundleDisplayName']

			if 'CFBundleName' in jsobj:
				bundle_name = jsobj['CFBundleName']
				if bundle_name != '$(PRODUCT_NAME)':
					bundle_display_name = bundle_name
			f.close()

	app_icon_file = None

	xcassets_items = []
	if '*.xcasset' in depend_files:
		xcassets_items = depend_files['*.xcasset']

	if len(xcassets_items):
		appiconset_path = depends_dir + '/' + xcassets_items[0].replace('{..}/', '../') + '/AppIcon.appiconset'
		json_file = appiconset_path + '/Contents.json'
		if os.path.exists(json_file):
			fin = open(json_file, 'r')
			jsobj = json.load(fin)
			fin.close()
			images = jsobj['images']
			for image in images:
				if 'filename' in image:
					file_name = image['filename']
					size = image['size']
					if size == '20x20' or size == '40x40':
						app_icon_file = appiconset_path + '/' + file_name
						break

	config_file = '%s/config.xml' % package_dir
	print(config_file)
	with open(config_file, 'rb') as fin:
		jsobj = biplist.readPlist(fin)
		fin.close()
		if app_icon_file != None:
			jsobj['appIconFile'] = app_icon_file
		if bundle_display_name != None:
			jsobj['displayName'] = bundle_display_name
		plistlib.writePlist(jsobj, config_file)

	pass

#python package_export.py ~/Desktop/fuck.zip /Users/yangwei/Library/ipa-artifact com.zuimeiqidai.ios.test.objc
def main(argv):
	confuse_utils.print_cmd(argv)
	if len(argv) != 4:
		print('python import_package.py [zip file name] [work dir] [bundle id]')
		return
	print('import_package.py %s %s %s' % (argv[1], argv[2], argv[3]))
	import_package(argv[1], argv[2], argv[3])

main(sys.argv)