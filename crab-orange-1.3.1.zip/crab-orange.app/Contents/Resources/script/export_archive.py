#!/usr/bin/python
# -*- coding: UTF-8 -*-

import sys
import os
import confuse_utils
import getpass
import biplist

EXPORT_METHOD_APP_STORE = 'app-store'
EXPORT_METHOD_AD_HOC = 'ad-hoc'
EXPORT_METHOD_DEVELOPMENT = 'development'

#SIGNING_CERTIFICATE_DEVELOPER = 'iPhone Developer'
#SIGNING_CERTIFICATE_DISTRIBUTION = 'iPhone Distribution'

def output_export_options_plist(work_dir, configure, package_dir, method, identity, bundle_id, team_id, mobile_provision, bitcode, ext_bundle_id_and_target_names):
	#print(type(method))
	keep_symbs = confuse_utils.get_run_settings_value(work_dir, bundle_id, 'keep-symbs', False)
	fn = '%s/ExportOptions.plist' % (package_dir)
	f = open(fn, 'w')
	f.write('<?xml version="1.0" encoding="UTF-8"?>\n')
	f.write('<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">\n')
	f.write('<plist version="1.0">\n<dict>\n')
	f.write(f"<key>method</key><string>{method}</string>\n")
	f.write('<key>provisioningProfiles</key><dict>')
	f.write(f"<key>{bundle_id}</key><string>{mobile_provision}</string>")
	for i in range(0, len(ext_bundle_id_and_target_names)):
		ext_bundle_id = ext_bundle_id_and_target_names[i][0]
		ext_target_name = ext_bundle_id_and_target_names[i][1]
		mobile_provision_info,has_config,identity = confuse_utils.get_mobile_provision_file_info(work_dir, bundle_id, configure, ext_bundle_id, ext_target_name)
		if mobile_provision_info == None:
			print('not found mobile provision by %s-%s(%s)' % (ext_bundle_id, ext_target_name, configure))
			sys.exit(1)
		mobile_provision_uuid = mobile_provision_info['UUID']
		f.write(f"<key>{ext_bundle_id}</key><string>{mobile_provision_uuid}</string>\n")
	f.write('</dict>\n')
	f.write(f"<key>teamID</key><string>{team_id}</string>\n")
	if bitcode:
		f.write('<key>compileBitcode</key><true/>\n')
	else:
		f.write('<key>compileBitcode</key><false/>\n')

	f.write(f"<key>signingCertificate</key><string>{identity}</string>\n")
	f.write('<key>signingStyle</key><string>manual</string>\n')
	f.write('<key>thinning</key><string>&lt;none&gt;</string>\n')
	if keep_symbs:
		f.write('<key>stripSwiftSymbols</key><false/>\n')
	else:
		f.write('<key>stripSwiftSymbols</key><true/>\n')
	f.write('<key>uploadSymbols</key><true/>\n')
	f.write('</dict>\n</plist>')
	f.close()
	return fn

def list_files_with_suffix(directory, suffix):
    return [f for f in os.listdir(directory) if f.endswith(suffix)]
 
def export_archive(project_file, work_dir, bundle_id, target_name, configure, ext_bundle_id_and_target_names):
	print('##export archive ##')
	package_dir = '%s/packages/%s' % (work_dir, bundle_id)
	new_target_name = confuse_utils.get_symbol_new_name(work_dir, bundle_id, target_name, 'target')
	archive_path = '%s/%s.xcarchive' % (package_dir, target_name)
	export_path = '%s/Products' % package_dir
	cmds = []
	
	mobile_provision_info, has_config,identity = confuse_utils.get_mobile_provision_file_info(work_dir, bundle_id, configure, bundle_id, target_name)
	mobile_provision_uuid = mobile_provision_info['UUID']
	team_id = mobile_provision_info['TEAM_ID']

	if configure == 'Debug':
		method = EXPORT_METHOD_DEVELOPMENT
	else:
		if 'HasTestDevice' in mobile_provision_info:
			method = EXPORT_METHOD_AD_HOC
		else:
			method = EXPORT_METHOD_APP_STORE
	filename = output_export_options_plist(work_dir, configure, package_dir, method, identity, bundle_id, team_id, mobile_provision_uuid, False, ext_bundle_id_and_target_names)

	cmd = 'rm -rf \"%s\"' % (export_path)
	cmds.append(cmd)

	cmd = 'mkdir \"%s\"' % (export_path)
	cmds.append(cmd)

	cmd = 'xcodebuild -exportArchive -archivePath \"%s\" -exportPath \"%s\" -exportOptionsPlist \"%s\"' % (archive_path, export_path, filename)
	cmds.append(cmd)
	for cmd in cmds:
		ret = confuse_utils.exec_cmd(cmd)
		if ret != 0:
			sys.exit(1)

	build_settings = confuse_utils.get_build_settings(work_dir, bundle_id, project_file, configure, target_name, True)
	#info_plist_file = confuse_utils.get_build_settings_value(build_settings, 'PRODUCT_SETTINGS_PATH', '')
	products_dir = '%s/Products' % package_dir
	ipa_files = list_files_with_suffix(products_dir, '.ipa')
	if len(ipa_files) == 0:
		print('not found ipa in %s' % products_dir)
		sys.exit(1)
	pass

#cd /Users/carb/Documents/myprojects/iOS-artifact/resource/projectmanager/other/script
#python export_archive.py /Users/carb/Library/ipa-artifact com.zuimeiqidai.my.samplecode SampleCode
def main(argv):
	confuse_utils.print_cmd(argv)
	if len(argv) < 6:
		print('python export_archive.py [project file] [work dir] [bundle id] [target name] [Debug/Release] ...')
		return
	items = []
	i = 6;
	while i < len(argv):
		items.append([argv[i], argv[i + 1]])
		i += 2

	export_archive(argv[1], argv[2], argv[3], argv[4], argv[5], items)
	
main(sys.argv)
