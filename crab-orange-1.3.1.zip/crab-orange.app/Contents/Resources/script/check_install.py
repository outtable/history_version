#!python
# -*- coding: UTF-8 -*-

import sys
import os
import getpass
from distutils.sysconfig import get_python_lib
 
site_packages_path = get_python_lib()

abs_file_path = os.path.abspath(__file__)
script_dir = abs_file_path[0:abs_file_path.rfind('/')]

def get_clang_resource_dir():
	b = os.popen('clang -print-resource-dir')
	jstxt = ''.join(b.readlines())
	return jstxt

def get_clang_dir():
	resource_dir = get_clang_resource_dir()
	idx = resource_dir.find('/usr/lib/clang')
	if idx != -1:
		version = resource_dir[idx + 15:][:2]
		clang_dir = '%s/clang%s' % (script_dir, version)
		return clang_dir
	return ''

def check_clang_dir():
	if os.path.exists(get_clang_dir()):
		return True
	return False

def exec_cmd(cmd):
	return os.system(cmd)

def exec_cmd_ext(cmd):
	b = os.popen(cmd)
	text = b.read()
	ret = b.close()
	if ret == None:
		ret = 0
	return ret, text

def trace_success(msg):
	print('😊 %s' % msg)

def trace_faild(msg):
	print('😭 %s' % msg)

def need_break_system_packages():
	b = os.popen('pip3 install pypng')
	lines = b.readlines()
	text = ''.join(lines)
	if text.find('This environment is externally managed') != -1:
		return True
	return False

def main(argv):
	user = getpass.getuser()
	global site_packages_path
	print('🐍 python-site-packages:%s' % site_packages_path)
	shell = os.getenv('SHELL')
	exec_cmd('echo SHELL=${SHELL}')
	exec_cmd('echo PATH=${PATH}')
	if not check_clang_dir():
		trace_faild('❌ 不支持的Xcode版本 %s' % get_clang_resource_dir())
		sys.exit(1)
	else:
		trace_success('xcode兼容性校验成功.')
	ret = exec_cmd('which arch')
	has_arch = False
	if ret == 0:
		has_arch = True
	ret = exec_cmd('ccache --version')

	if ret != 0:
		print('ready install ccache')
		brew_install_cmd = 'brew install ccache'
		if has_arch:
			ret = exec_cmd('arch -arm64')
			if ret == 0:
				brew_install_cmd = 'arch -arm64 %s' % brew_install_cmd
		ret = exec_cmd(brew_install_cmd)
		if ret != 0:
			trace_faild('install ccache faild.')
			sys.exit(1)
		else:
			trace_success('install ccache success.')
	else:
		trace_success('check ccache ok.')
	ret = exec_cmd('xcode-select -p')
	if ret != 0:
		trace_faild('check xcode-select faild.')
	else:
		trace_success('check xcode-select ok.')
	ret = exec_cmd('xcodebuild -version')
	if ret != 0:
		trace_faild('check xcodebuild faild(xcode-select -p is empty dir).')
		sys.exit(1)
	else:
		trace_success('check xcodebuild ok.')

	ret,text = exec_cmd_ext('pip3 --version')
	if ret != 0:
		print('ready install pip...')
		print('download get-pip.py')
		ret = exec_cmd('curl https://bootstrap.pypa.io/pip/get-pip.py -o get-pip.py')
		if ret != 0:
			trace_faild('download get-pip.py faild.')
			sys.exit(1)
		ret = exec_cmd('python3 get-pip.py')
		if ret != 0:
			trace_faild('run get-pip.py faild.')
			sys.exit(1)
	else:
		if os.path.islink(site_packages_path):
			target_path = os.readlink(site_packages_path)
			site_packages_path = os.path.normpath(os.path.join(site_packages_path, target_path))
		idx = text.find(site_packages_path)
		if idx == -1:
			print('pip3:%s' % text)
			print('python-site-packages:%s' % site_packages_path)
			print('⚠️ pip3 site-packages 路径与python3默认路径不一致，请重新安装python3和pip3!')
			#sys.exit(1)
		trace_success('check pip ok.')

	fuck_param = '--break-system-packages'

	if not need_break_system_packages():
		fuck_param = ''
	
	libs = [
		#{
		#	'name' : 'pypng',#没啥用了
		#	'cmd' : 'pypng>=0.0.19'
		#}, 
		{
			'name' : 'Pillow',
			'cmd' : 'Pillow>=6.1.0'
		}, 
		{
			'name' : 'future',
			'cmd' : 'future>=0.18.0'
		},
		#{
		#	'name' : 'openstep_parser',
		#	'cmd' : 'openstep_parser==1.3.1'
		#},
		#{
		#	'name' : 'biplist',
		#	'cmd' : 'biplist>=1.0.3'
		#}
	]

	for lib in libs:
		ret = exec_cmd("pip3 install '%s' %s" % (lib['cmd'], fuck_param))
		if ret != 0:
			trace_faild('install %s faild.' % lib['name'])
			sys.exit(1)
		else:
			trace_success('install %s success.' % lib['name'])

	print('👌 runtime check success.')
main(sys.argv)