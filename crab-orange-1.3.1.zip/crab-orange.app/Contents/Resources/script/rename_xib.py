#!/usr/bin/python
# -*- coding: UTF-8 -*-

import sys
import os
import confuse_utils
import json

def rename_xib(work_dir, bundle_id, main_project_file, target_name, configure, product_type, product_file, install_dir, project_file, product_target_name, src_files, ref_folders):
	confuse_utils.begin_transaction(work_dir, bundle_id)
	for i in range(0, len(src_files)):
		src_file = src_files[i]
		ref_folder = ref_folders[i]
		if confuse_utils.get_file_rename(work_dir, bundle_id, src_file, close_connection = False) != src_file:
			continue
		print('##rename xib %s##' % (src_file))
		name = confuse_utils.get_file_name(src_file)
		file_extension = confuse_utils.get_file_extension(src_file)
		newname = confuse_utils.new_constant_value(work_dir, bundle_id, name, file_extension, None, close_connection = False)#创建一个新名字
		dir_name = confuse_utils.get_file_dir(src_file)
		dst_file = dir_name + '/' + newname + '.' + file_extension
		confuse_utils.add_file_rename(work_dir, bundle_id, src_file, dst_file, False)
	confuse_utils.commit_transaction()
	pass

def main(argv):
	confuse_utils.print_cmd(argv)
	if len(argv) != 13:
		print('python rename_xib.py [work dir] [bundle id] [target name] [product type] [product file] [install dir] [project file] [product target name] [src file] [ref folder]')
		sys.exit(1)
	rename_xib(argv[1], argv[2], argv[3], argv[4], argv[5], argv[6], argv[7], argv[8], argv[9], argv[10], confuse_utils.load_array_file(argv[11]), confuse_utils.load_array_file(argv[12]))
	
main(sys.argv)