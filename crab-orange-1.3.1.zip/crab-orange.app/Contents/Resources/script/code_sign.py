#!/usr/bin/python
# -*- coding: UTF-8 -*-

import sys
import os
import confuse_utils

def code_sign(work_dir, bundle_id, main_project_file, target_name, configure, project_file, product_type, product_bundle_id, product_target_name):
	new_target_name = confuse_utils.get_symbol_new_name(work_dir, bundle_id, target_name, 'target')
	new_product_target_name = confuse_utils.get_symbol_new_name(work_dir, bundle_id, product_target_name, 'target')
	app_build_settings = confuse_utils.get_build_settings(work_dir, bundle_id, main_project_file, configure, target_name, use_cache_file=True)
	app_product_file = confuse_utils.get_build_settings_value(app_build_settings, 'FULL_PRODUCT_NAME', '')
	build_settings = confuse_utils.get_build_settings(work_dir, bundle_id, project_file, configure, product_target_name, use_cache_file=True)
	product_file_name = confuse_utils.get_build_settings_value(build_settings, 'FULL_PRODUCT_NAME', '')
	print('##code sign %s##' % (product_target_name))
	package_dir = '%s/packages/%s' % (work_dir, bundle_id)
	mp,has_config,identify = confuse_utils.get_mobile_provision_file_info(work_dir, bundle_id, configure, product_bundle_id, product_target_name)
	if mp == None and product_type != '.framework':
		print('not found mobile provision by %s-%s(%s)' % (product_bundle_id, product_target_name, configure))
		sys.exit(1)

	if mp == None:
		mp,has_config,identify = confuse_utils.get_mobile_provision_file_info(work_dir, bundle_id, configure, bundle_id, target_name)

	mobile_provision = mp['FILE_NAME']
	sign_key = mp['CODE_SIGN_IDENTITY']
	archive_path = '%s/%s.xcarchive' % (package_dir, target_name)
	
	cmds = []

	if mobile_provision != None:
		cmd = '/usr/bin/security cms -D -i \"%s\" > \"%s/temp_%s_entitlements_full.plist\"' % (mobile_provision, package_dir, bundle_id)
		ret = confuse_utils.exec_cmd(cmd)
		if ret != 0:
			sys.exit(1)
		full_entitlements_plist = '%s/%s.entitlements.plist' % (package_dir, bundle_id)
		cmd = '/usr/libexec/PlistBuddy -x -c \'Print\' \"%s/temp_%s_entitlements_full.plist\" > \"%s\"' % (package_dir, bundle_id, full_entitlements_plist)
		ret = confuse_utils.exec_cmd(cmd)
		if ret != 0:
			sys.exit(1)
		confuse_utils.write_configure_entitlements(work_dir, bundle_id, package_dir, project_file, product_target_name, configure, full_entitlements_plist)

	if product_type == '.app':
		dst_file = '%s/Products/Applications/%s' % (archive_path, product_file_name)
	elif product_type == '.appex':
		dst_file = '%s/Products/Applications/%s/PlugIns/%s' % (archive_path, app_product_file, product_file_name)
	elif product_type == '.framework':
		dst_file = '%s/Products/Applications/%s/Frameworks/%s' % (archive_path, app_product_file, product_file_name)
	if not os.path.exists(dst_file):
		print('⚠️ 找不到 %s' % dst_file)
		return
	if product_type != '.framework':
		cmd = '/usr/bin/codesign -f -s \"%s\" --entitlements \"%s/%s.%s.%s.entitlements.plist\" \"%s\"' % (sign_key, package_dir, bundle_id, configure, product_target_name, dst_file)
	else:
		cmd = '/usr/bin/codesign -f -s \"%s\" --preserve-metadata=identifier,entitlements,flags \"%s\"' % (sign_key, dst_file)
	
	ret = confuse_utils.exec_cmd(cmd)
	if ret != 0:
		sys.exit(1)
	pass

def main(argv):
	confuse_utils.print_cmd(argv)
	if len(argv) != 10:
		print('python code_sign.py [work dir] [bundle id] [main poject file] [target name] [Debug/Release] [project file] [product type] [product bundle id] [product target]')
		sys.exit(1)
	code_sign(argv[1], argv[2], argv[3], argv[4], argv[5], argv[6], argv[7], argv[8], argv[9])

main(sys.argv)