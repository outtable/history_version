#!/usr/bin/python
# -*- coding: UTF-8 -*-

import sys
import os
import confuse_utils

def export_product(archive_dir, src_product_file, dst_product_file):
	dst_product_file = confuse_utils.pstr(dst_product_file)
	os.system('cp -rf \"%s\" \"%s\"' % (src_product_file, dst_product_file))
	os.system('cp -rf \"%s.back/dSYMs\" \"%s\"' % (archive_dir, dst_product_file))
	os.system('cp -rf \"%s/Products-no-strip\" \"%s\"' % (archive_dir, dst_product_file))
	os.system('open -R \"%s\"' % (dst_product_file))
	pass

def main(argv):
	if len(argv) != 4:
		print('python export_product.py [archive dir] [src product file] [dst product file]')
		return
	export_product(argv[1], argv[2], argv[3])
	
main(sys.argv)