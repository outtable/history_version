#!/usr/bin/python
# -*- coding: UTF-8 -*-

import sys
import os
import confuse_utils
import json
import importlib

importlib.reload(sys)
#sys.setdefaultencoding('utf8')

exclude_file_extensions = ['xib', 'storyboard']

def rename_resource(work_dir, bundle_id, main_project_file, target_name, configure, product_type, product_file, install_dir, project_file, product_target_name, src_files, ref_folders):
	confuse_utils.begin_transaction(work_dir, bundle_id)
	for i in range(0, len(src_files)):
		src_file = src_files[i]
		ref_folder = ref_folders[i]
		new_src_file = confuse_utils.get_file_rename(work_dir, bundle_id, src_file, close_connection = False)
		if confuse_utils.get_full_file_name(new_src_file) != confuse_utils.get_full_file_name(src_file):
			continue
		print('##rename resource %s##' % (src_file))
		name = confuse_utils.get_file_name(src_file)
		file_extension = confuse_utils.get_file_extension(src_file)
		if file_extension != None:
			newname = confuse_utils.new_constant_value(work_dir, bundle_id, name, file_extension, None, close_connection = False)#创建一个新名字
			confuse_utils.new_constant_value(work_dir, bundle_id, name, file_extension, '%s.%s' % (newname, file_extension), close_connection = False)#创建一个带文件名后缀的新名字
			path = '%s.%s' % (name, file_extension)
			new_path = '%s.%s' % (newname, file_extension)
		else:
			newname = confuse_utils.new_constant_value(work_dir, bundle_id, name, '[None]', None, close_connection = False)#创建一个新名字
			path = name
			new_path = newname
		
		if len(ref_folder):
			path = '%s/%s' % (ref_folder, path)
			new_path = '%s/%s' % (ref_folder, new_path)
		
		if product_type == '.framework':
			workspace_profile = confuse_utils.load_workspace_profile(work_dir, bundle_id)
			if confuse_utils.get_target_macho_type(workspace_profile, product_target_name) != 'staticlib':
				path = 'Frameworks/%s.framework/%s' % (product_target_name, path)
				new_path = 'Frameworks/%s.framework/%s' % (product_target_name, new_path)
			
		elif product_type == '.bundle':
			path = '%s/%s' % (product_file, path)
			new_path = '%s/%s' % (product_file, new_path)
			
		if file_extension not in exclude_file_extensions:
			#if len(file_extension):
			#	confuse_utils.add_path_to_map(work_dir, bundle_id, product_target_name, name[:-(len(file_extension) + 1)], newname[:-(len(file_extension) + 1)], close_connection = False)
			confuse_utils.add_path_to_map(work_dir, bundle_id, product_target_name, path, new_path, close_connection = False)
		
		if len(ref_folder):
			if file_extension != None:
				confuse_utils.new_constant_value(work_dir, bundle_id, name, file_extension, '%s/%s.%s' % (ref_folder, newname, file_extension), close_connection = False)#创建一个引用目录名
			else:	
				confuse_utils.new_constant_value(work_dir, bundle_id, name, '[None]', '%s/%s' % (ref_folder, newname), close_connection = False)#创建一个引用目录名
		dir_name = confuse_utils.get_file_dir(src_file)
		if file_extension != None:
			dst_file = dir_name + '/' + newname + '.' + file_extension
		else:
			dst_file = dir_name + '/' + newname
		confuse_utils.add_file_rename(work_dir, bundle_id, src_file, dst_file, False)
	confuse_utils.commit_transaction()
	pass

def main(argv):
	confuse_utils.print_cmd(argv)
	if len(argv) != 13:
		print('python rename_resource.py [work dir] [bundle id] [target name] [product type] [product file] [install dir] [project file] [product target name] [src files] [ref folders]')
		sys.exit(1)
	rename_resource(argv[1], argv[2], argv[3], argv[4], argv[5], argv[6], argv[7], argv[8], argv[9], argv[10], confuse_utils.load_array_file(argv[11]), confuse_utils.load_array_file(argv[12]))
	
main(sys.argv)