#!/usr/bin/python
# -*- coding: utf-8 -*-  

import sys
import importlib
import functools
importlib.reload(sys)
#sys.setdefaultencoding("utf-8")

import re
import os
import sqlite3
import json
import random
import shutil
from zlib import crc32
import biplist
import subprocess
import hashlib
from multiprocessing import cpu_count
import datetime
import fcntl
import time
import plistlib
import base64

transaction_enable = False
transaction_counter = 0

def load_workspace_profile(work_dir, bundle_id):
	package_dir = '%s/packages/%s' % (work_dir, bundle_id)
	file = '%s/workspace.profile' % (package_dir)
	workspace_profile = json.load(open(file, 'r'))
	return workspace_profile

def get_target_macho_type(profile, target_name):
	ret = ''
	projects = profile['projects']
	for project in projects:
		targets = project['targets']
		for target in targets:
			if target['name'] == target_name:
				return target['mach-o-type']
	return ret
	
def gen_choise_code_file(code_file_path, choise_files, new_code_file_path):
	files = []
	with open(code_file_path, 'r') as f:
		lines = f.readlines()
		i = 0
		while i < len(lines):
			filename = lines[i].strip()
			flags = lines[i + 1].strip()
			if filename in choise_files:
				files.append([filename, flags])
			i += 2
		f.close()

	with open(new_code_file_path, 'w') as f:
		for pair in files:
			f.write(pair[0] + '\n')
			f.write(pair[1] + '\n')
		f.close()
	pass

def pstr(str):
	ret = str.replace('\\', "\\\\")
	ret = str.replace('\"', '\\\"')
	return ret

def trace_error(msg):
	print(msg)
	sys.exit(1)

def get_std_value(value):
	if value == 'c++0x':
		return 'c++11'
	return value

def get_worker_count(work_dir, bundle_id):
	val = get_run_settings_value(work_dir, bundle_id, 'power', True)
	if val:
		return cpu_count() * 0.8
	return cpu_count() * 0.5

def get_rel_path(path1, path2):
	if path1 == path2:
		return path1[path1.rfind('/') + 1:]
	items1 = path1.split('/')
	items2 = path2.split('/')

	l1 = len(items1)
	l2 = len(items2)
	l = l1
	if l2 < l1:
		l = l2
	c = 0
	for i in range(0, l):
		if items1[i] == items2[i]:
			c = c + 1
		else:
			break
	ret = ''
	for i in range(c, len(items2)):
		if len(ret) > 0:
			ret += '/' + items2[i]
		else:
			ret += items2[i]

	return ret
	pass

def backup_dir(src_dir, dst_dir):
	if not os.path.exists(dst_dir):
		try:
			os.makedirs(dst_dir)
		except OSError:
			if not os.path.exists(dst_dir):
				print(('warning:makedir %s error.' % (dst_dir)))
			pass
	for root, dirs, files in os.walk(src_dir):
		rel_dir = root[len(src_dir):]
		newroot = '%s%s' % (dst_dir, rel_dir)
		for file in files:
			src_file = '%s/%s' % (root, file)
			dst_file = '%s/%s' % (newroot, file)
			fast_copy_file(src_file, dst_file)
	pass

def copy_dir(src_dir, dst_dir):
	if not os.path.exists(dst_dir):
		try:
			os.makedirs(dst_dir)
		except OSError:
			if not os.path.exists(dst_dir):
				print(('warning:makedir %s error.' % (dst_dir)))
			pass
	for root, dirs, files in os.walk(src_dir):
		rel_dir = root[len(src_dir):]
		newroot = '%s%s' % (dst_dir, rel_dir)
		for file in files:
			src_file = '%s/%s' % (root, file)
			dst_file = '%s/%s' % (newroot, file)
			if os.path.exists(dst_file):
				print(('remove %s' % dst_file)) 
				os.remove(dst_file)
			copy_file(src_file, dst_file)

def backup_file(src_file, dst_file):
	dir_name = os.path.dirname(dst_file)
	if not os.path.exists(dir_name):
		try:
			os.makedirs(dir_name)
		except OSError:
			if not os.path.exists(dir_name):
				print(('warning:makedir %s error.' % (dir_name)))
			pass
	if os.path.exists(dst_file):
		print(('remove %s' % dst_file)) 
		os.remove(dst_file)
	print(('link %s to %s' % (src_file, dst_file)))
	os.link(src_file, dst_file)
	pass

def fast_copy_file(src_file, dst_file):
	if os.path.isdir(src_file):
		backup_dir(src_file, dst_file)
	else:
		backup_file(src_file, dst_file)

def copy_file(src_file, dst_file):
	print(('copy file %s to %s' % (src_file, dst_file)))
	if os.path.isdir(src_file):
		copy_dir(src_file, dst_file)
	else:
		dir_name = os.path.dirname(dst_file)
		if not os.path.exists(dir_name):
			try:
				os.makedirs(dir_name)
			except OSError:
				if not os.path.exists(dir_name):
					print(('warning:makedir %s error.' % (dir_name)))
				pass
		if os.path.exists(dst_file):
			print(('remove %s' % dst_file)) 
			os.remove(dst_file)
		shutil.copyfile(src_file, dst_file)
	pass

def rename_dir(src_dir, dst_dir):
	if not os.path.exists(dst_dir):
		try:
			os.makedirs(dst_dir)
		except OSError:
			if not os.path.exists(dst_dir):
				print(('warning:makedir %s error.' % (dst_dir)))
			pass
	for root, dirs, files in os.walk(src_dir):
		rel_dir = root[len(src_dir):]
		newroot = '%s%s' % (dst_dir, rel_dir)
		for file in files:
			src_file = '%s/%s' % (root, file)
			dst_file = '%s/%s' % (newroot, file)
			rename_file(src_file, dst_file)

def rename_file(src_file, dst_file):
	if os.path.isdir(src_file):
		rename_dir(src_file, dst_file)
	else:
		dir_name = os.path.dirname(dst_file)
		if not os.path.exists(dir_name):
			try:
				os.makedirs(dir_name)
			except OSError:
				if not os.path.exists(dir_name):
					print(('warning:makedir %s error.' % (dir_name)))
				pass
		os.rename(src_file, dst_file)

def md5str(val):
	m1 = hashlib.md5()
	m1.update(bytearray(val, 'utf-8'))	
	return m1.hexdigest()

def get_xcode_sdk_path():
	b = os.popen('xcodebuild -quiet -showsdks -json')
	jstxt = ''.join(b.readlines())
	jsobj = json.loads(jstxt)
	for info in jsobj:
		platform = info['platform']
		sdkpath = info['sdkPath']
		if platform == 'iphoneos':
			return sdkpath[0:sdkpath.rfind('/')] + '/iPhoneOS.sdk'
	return ''

def get_toolchain_dir(sdk_path):
	s =  '/Contents/Developer/'
	idx = sdk_path.find(s)
	if idx != -1:
		dev_dir = sdk_path[0:idx + len(s)]
		return '%sToolchains/XcodeDefault.xctoolchain' % dev_dir
	return ''

def get_lib_clang_include(toolchain_dir):
	dirname = '%s/usr/lib/clang' % toolchain_dir
	for root, dirnames, filenames in os.walk(dirname):
		for name in dirnames:
			include_dir = '%s/%s' % (dirname, name)
			if os.path.exists(include_dir):
				return include_dir
	return ''

def get_xcode_derived_data_dir():
	return '%s/Library/ipa-artifact/DerivedData' % (os.path.expanduser('~'))

def check_expiration_data(dt):
	if datetime.datetime.now() < dt:
		return True
	return False

def read_plist(file_name):
	with open(file_name, 'r') as f:
		return biplist.readPlistFromString(bytearray(f.read(), 'utf-8'))
	return {}

def write_plist(file_name, dict):
	txt = plistlib.writePlistToBytes(dict)
	with open(file_name, 'wb') as f:
		f.write(txt)
	pass

def get_mobile_device_profiles(bundle_id, configure):
	search_dir = '%s/Library/MobileDevice/Provisioning Profiles' % (os.path.expanduser('~'))
	ret = []
	files = os.listdir(search_dir)
	for file in files:
		if file.endswith('.mobileprovision') != True:
			continue
		b = os.popen('security cms -D -i \"%s/%s\"' % (search_dir, file))
		jstxt = ''.join(b.readlines())
		json = biplist.readPlistFromString(bytearray(jstxt, 'utf-8'))
		entitlements = json['Entitlements']
		teamId = entitlements['com.apple.developer.team-identifier']
		appid = entitlements['application-identifier']
		if 'aps-environment' in entitlements:
			aps_environment = entitlements['aps-environment']
		#has_devices = False
		#if json.has_key('ProvisionedDevices'):
		#	has_devices = True
		expiration_data = json['ExpirationDate']

		if check_expiration_data(expiration_data) == False:
			continue
		creation_date = json['CreationDate'].strftime("%Y-%m-%d %H:%M:%S")
		expiration_data = json['ExpirationDate'].strftime("%Y-%m-%d %H:%M:%S")
		uuid = json['UUID']
		name = json['Name']
		team_name = json['TeamName']
		item_str = '%s/%s' % (search_dir, file)
		if appid[len(teamId) + 1:] == bundle_id:
			ret.append({'uuid' : uuid, 'name' : name, 'path' : item_str, 'team' : team_name, 'expiration-date' : expiration_data, 'creation-date' : creation_date})
			#if configure == 'Debug':
			#	if aps_environment == 'development':
			#		ret.append({'name' : name, 'path' : item_str, 'team' : team_name})
			#elif aps_environment != 'development':
			#		ret.append({'name' : name, 'path' : item_str, 'team' : team_name})
	return ret

def exec_cmd(cmd):
	print('🦶 %s' % cmd)
	process = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
	stdout, stderr = process.communicate()
	text = stdout.decode()
	if len(text):
		print(text)
	ret = process.poll()
	if ret != 0:
		if len(text):
			print(('~>❌ 🦶 %s(ExitCode:%d)' % (cmd, ret)))
		else:
			print(('~>❌ (ExitCode:%d)' % (ret)))
		print(stderr.decode())
	return ret

def remove_xcsets_file(work_dir, bundle_id, project_file, configure, target_name):
	cache_file_name =  '%s/packages/%s/%s-%s.xcsets' % (work_dir, bundle_id, target_name, configure)
	if os.path.exists(cache_file_name):
		os.remove(cache_file_name)

def get_project_build_settings(project_file):
	cmd = 'xcodebuild -quiet -showBuildSettings -project \"%s\"' % pstr(project_file)
	b = os.popen(cmd)
	lines = b.readlines()
	envs = {}
	for line in lines:
		sp = line.find('=')
		if sp != -1:
			key = line[0:sp].strip()
			value = line[sp + 1:].strip()
			envs[key] = value

	return envs

def get_workspace_build_settings(workspace_file, scheme, configure):
	cmd = 'xcodebuild -quiet -showBuildSettings -workspace \"%s\" -scheme \"%s\" -configuration \"%s\"' % (pstr(workspace_file), scheme, configure)
	print(cmd)
	b = os.popen(cmd)
	lines = b.readlines()
	envs = {}
	for line in lines:
		sp = line.find('=')
		if sp != -1:
			key = line[0:sp].strip()
			value = line[sp + 1:].strip()
			envs[key] = value
	return envs

def get_build_settings(work_dir, bundle_id, project_file, configure, target_name, use_cache_file=False, create_temp_file=False, use_archive_xcconfig=False):
	package_dir = '%s/packages/%s' % (work_dir, bundle_id)
	if create_temp_file:
		cache_file_name =  '%s/%s-%s-choise.xcsets' % (package_dir, target_name, configure)
	else:
		cache_file_name =  '%s/%s-%s.xcsets' % (package_dir, target_name, configure)
	print(cache_file_name)
	lines = []
	create_cache_file = False
	if use_cache_file:
		if os.path.exists(cache_file_name):
			with open(cache_file_name, 'r') as f:
				lines = f.readlines()
				f.close()
		else:
			create_cache_file = True
	else:
		create_cache_file = True

	cmd = ''
	if create_cache_file:
		cmd = 'xcodebuild -quiet -showBuildSettings -project \"%s\" -configuration \"%s\" -target \"%s\"' % (pstr(project_file), pstr(configure), pstr(target_name))
		if use_archive_xcconfig:
			cmd = '%s -xcconfig \"%s/archive.%s.xcconfig\"' % (cmd, package_dir, configure)
		print(cmd)
		b = os.popen(cmd)
		lines = b.readlines()
		if len(lines):
			with open(cache_file_name, 'w') as f:
				for line in lines:
					f.write(line)
				f.close()
		#temp file
		if create_temp_file:
			add_temp_file(work_dir, bundle_id, cache_file_name)

	envs = {}
	for line in lines:
		sp = line.find('=')
		if sp != -1:
			key = line[0:sp].strip()
			value = line[sp + 1:].strip()
			envs[key] = value
	if len(lines) == 0:
		print(('get build settings error(%s).' % cmd))
		sys.exit(1)

	if len(list(envs.keys())) == 0:
		print(('please remove file %s.' % cache_file_name))
		sys.exit(1)
	#print '\n'.join(lines)
	return envs

def write_build_settings_file(work_dir, bundle_id, project_file, configure, target_name):
	envs = get_build_setting(work_dir, bundle_id, project_file, configure, target_name)
	project_name = get_file_name(project_file)
	filename = '%s/packages/%s/%s_%s_%s.build_settings.txt' % (configure, project_name, target_name)
	with open(filename, 'w') as f:
		for key, value in envs.pairs():
			f.write('%s=%s' % (key, value))
		f.close()

def is_need_value(name):
	names = ['-iapinotes-modules', 
		'-iapinotes-path', 
		'-idirafter', 
		'-iframeworkwithsysroot', 
		'-iframework', 
		'-imacros',
		'-include-pch',
		'-include',
		'-iprefix',
		'-iquote',
		'-isysroot',
		'-isystem-after',
		'-isystem',
		'-cxx-isystem',
		'-ivfsoverlay',
		'-ivfsstatcache',
		'-iwithprefixbefore',
		'-iwithprefix',
		'-iwithsysroot',
		'-I',
		'-L',
		'-framework',
		'-weak_framework',
		'-weak-lSystem',
		'-Xlinker',
		'-F',
		'-L',
		'-D',
		'-H',
		'-U'
		]
	return name in names

def scan_lex(value,pos,end):
	text = ''
	state = 0
	savepos = pos
	stack = []
	while (pos < end):
		ch = value[pos]
		if state == 0:
			if ch == '"' or ch == "'":
				stack.append(ch)
				state = 1
			elif ch == '\\':
				state = 2
			elif ch == ' ' and len(text) == 0:
				pos = pos + 1
				while pos < end:
					if value[pos] != ' ':
						savepos = pos - 1
						break
					pos = pos + 1
				savepos = pos - 1
				break
			elif ch == '/' and len(text) == 0:
				text = text + ch
				state = 4
			else:
				text = text + ch
				state = 3
		elif state == 1:
			if ch == '"' or ch == "'":
				if stack[len(stack) - 1] == ch:
					stack.pop()
					state = 0
					if len(stack) == 0:
						nexch = value[pos]
						pos = pos + 1
						if pos < end:
							nexch = value[pos]
							if nexch == '"' or nexch == "'":
								state = 0
								continue
						break
				else:
					text = text + ch
			else:
				text = text + ch
		elif state == 2:
			if ch == ' ':
				text = text + ' '
				state = 0
			elif ch == '"':
				text = text + '"'
				state = 0
			elif ch == '\'':
				text = text + '\''
				state = 0
			else:
				break
		elif state == 3:
			if ch == '"' or ch == "'":
				stack.append(ch)
				state = 1
			elif ch == '\\':
				state = 2
			elif ch == ' ':
				break
			else:
				text = text + ch
		elif state == 4:
			if ch == '\\':
				state = 2
			elif ch == ' ':
				if pos + 1 < end:
					nexch = value[pos + 1]
					if nexch == '-' or nexch == '/' or nexch == ' ' or nexch == '"' or nexch == "'":
						break
					else:
						text = text + ch
			else:
				text = text + ch
			
		pos = pos + 1
	#rawtext = value[savepos:pos].strip()
	return text, pos

def get_settings_list_value(value, is_path):
	start = 0
	end = len(value)
	pos = 0
	items = []

	while True:
		save_pos = pos
		text, pos = scan_lex(value, pos, end)
		if len(text):
			items.append(text)
		if save_pos == pos:
			break
	
	pos = 0
	ret = []
	while (pos < len(items)):
		item = items[pos]
		if is_need_value(item.strip()):
			if pos + 1 < len(items):
				next_item = items[pos + 1]
				ret.append(item + ' ' + next_item)
				pos = pos + 2
				continue
		ret.append(items[pos])
		pos = pos + 1
	return ret


def get_build_settings_value(envs, name, defvalue, is_path = False):
	if name in envs:
		value = envs[name]
		if isinstance(defvalue, list):
			return get_settings_list_value(value, is_path)
		elif isinstance(defvalue, bool):
			if isinstance(value, str):
				return value == 'YES'
			elif isinstance(value,int):
				return bool(value)
		elif isinstance(defvalue, int):
			return int(value)
		else:
			return value
	return defvalue

def get_framework_search_paths_settings_value(envs):
	exclude_dirnames = get_build_settings_value(envs, 'EXCLUDED_RECURSIVE_SEARCH_PATH_SUBDIRECTORIES', [], False)
	ret = get_build_settings_value(envs, 'FRAMEWORK_SEARCH_PATHS', [], True)
	ret_ext = []
	for i in range(0, len(ret)):
		ret[i] = os.path.abspath(ret[i])
		if ret[i].endswith('/**'):
			ret[i] = ret[i][0:-3]
			list_dir(ret[i], ret_ext, exclude_dirnames)
	for item in ret_ext:
		if item not in ret:
			ret.append(item)
	return ret

def get_system_framework_search_paths_settings_value(envs):
	exclude_dirnames = get_build_settings_value(envs, 'EXCLUDED_RECURSIVE_SEARCH_PATH_SUBDIRECTORIES', [], False)
	ret = get_build_settings_value(envs, 'SYSTEM_FRAMEWORK_SEARCH_PATHS', [], True)
	ret_ext = []
	for i in range(0, len(ret)):
		ret[i] = os.path.abspath(ret[i])
		if ret[i].endswith('/**'):
			ret[i] = ret[i][0:-3]
			list_dir(ret[i], ret_ext, exclude_dirnames)
	for item in ret_ext:
		if item not in ret:
			ret.append(item)
	return ret

def reg_list_match(regs, value):
	for reg in regs:
		if reg.match(value) != None:
			return True
	return False

def list_dir(src_dir, result, exclude_dirs):
	reg_list = []
	for exclude_dir in exclude_dirs:
		#print '^%s$' % convert_to_re(exclude_dir)
		p = re.compile('^%s$' % convert_to_re(exclude_dir))
		reg_list.append(p)
	
	for root, dirs, files in os.walk(src_dir):
		for dirname in dirs:
			if reg_list_match(reg_list, dirname) == False:
				#print '%s/%s' % (root, dirname)
				result.append('%s/%s' % (root, dirname))
	
def get_header_search_paths_settings_value(envs):
	exclude_dirnames = get_build_settings_value(envs, 'EXCLUDED_RECURSIVE_SEARCH_PATH_SUBDIRECTORIES', [], False)
	ret = get_build_settings_value(envs, 'HEADER_SEARCH_PATHS', [], True)
	ret_ext = []
	for i in range(0, len(ret)):
		ret[i] = os.path.abspath(ret[i])
		if ret[i].endswith('/**'):
			ret[i] = ret[i][0:-3]
			list_dir(ret[i], ret_ext, exclude_dirnames)
	for item in ret_ext:
		if item not in ret:
			ret.append(item)
	return ret

def get_user_header_search_paths_settings_value(envs):
	exclude_dirnames = get_build_settings_value(envs, 'EXCLUDED_RECURSIVE_SEARCH_PATH_SUBDIRECTORIES', [], False)
	ret = get_build_settings_value(envs, 'USER_HEADER_SEARCH_PATHS', [], True)
	ret_ext = []
	for i in range(0, len(ret)):
		ret[i] = os.path.abspath(ret[i])
		if ret[i].endswith('/**'):
			ret[i] = ret[i][0:-3]
			list_dir(ret[i], ret_ext, exclude_dirnames)
	for item in ret_ext:
		if item not in ret:
			ret.append(item)
	return ret

def get_library_search_paths_settings_value(envs):
	exclude_dirnames = get_build_settings_value(envs, 'EXCLUDED_RECURSIVE_SEARCH_PATH_SUBDIRECTORIES', [], False)
	ret = get_build_settings_value(envs, 'LIBRARY_SEARCH_PATHS', [], True)
	ret_ext = []
	for i in range(0, len(ret)):
		ret[i] = os.path.abspath(ret[i])
		if ret[i].endswith('/**'):
			ret[i] = ret[i][0:-3]
			list_dir(ret[i], ret_ext, exclude_dirnames)
	for item in ret_ext:
		if item not in ret:
			ret.append(item)
	return ret

def get_preprocess_settings_value(envs, extend_names = []):
	items =  get_build_settings_value(envs, 'GCC_PREPROCESSOR_DEFINITIONS', [])
	for extend_name in extend_names:
		values = get_build_settings_value(envs, extend_name, [])
		for value in values:
			if value.startswith('-D'):
				items.append(value[2:])
	return items


def get_preprocess_settings_value_with_prefix(envs, prefixs, extend_names = []):
	items =  get_build_settings_value(envs, 'GCC_PREPROCESSOR_DEFINITIONS', [])
	for extend_name in extend_names:
		values = get_build_settings_value(envs, extend_name, [])
		for value in values:
			for prefix in prefixs:
				if value.startswith(prefix):
					items.append(value)
					break
	return items

def get_other_ldflags_settings_value(envs):
	return get_build_settings_value(envs, 'OTHER_LDFLAGS', [])

def get_other_cflags_settings_value(envs):
	return get_build_settings_value(envs, 'OTHER_CFLAGS', [])

def get_runtime_search_paths(envs):
	return get_build_settings_value(envs, 'LD_RUNPATH_SEARCH_PATHS', [], False)

def get_run_settings_value(work_dir, bundle_id, name, defvalue):
	filename = '%s/packages/%s/runsettings.cfg.txt' % (work_dir, bundle_id)
	with open(filename, 'r') as f:
		jstxt = ''.join(f.readlines())
		json = biplist.readPlistFromString(bytearray(jstxt, 'utf-8'))
		run_dict = json['run']
		if name in run_dict:
			value =  run_dict[name]
			if isinstance(value, str):
				if len(value) == 0:
					return defvalue
			return value
	return defvalue

def get_mobile_provision_info(filename, bundle_id, sign_key):
	info = {}
	b = os.popen('security cms -D -i \"%s\"' % (filename))
	jstxt = ''.join(b.readlines())
	json = biplist.readPlistFromString(bytearray(jstxt, 'utf-8'))
	teamId = json['Entitlements']['com.apple.developer.team-identifier']
	info['TEAM_ID'] = teamId
	info['UUID'] = json['UUID']
	info['CODE_SIGN_IDENTITY'] = sign_key
	info['FILE_NAME'] = filename
	appid = json['Entitlements']['application-identifier']
	info['BUNDLE_ID'] = appid[len(teamId) + 1:]
	if 'ProvisionedDevices' in json:
		info['HasTestDevice'] = True
		pass
	return info

def get_mobile_provision_file_info(work_dir, bundle_id, configure, target_bundle_id, target_name):
	package_dir = '%s/packages/%s' % (work_dir, bundle_id)
	file_name = '%s/compile_configs.txt' % (package_dir)
	settings = read_settings_file(file_name)
	certificate = None
	mobile_provision = None
	config_bundle_id = None
	identify = None
	
	for key in list(settings.keys()):
		if key == 'code-sign-list':
			continue
		items = settings[key]
		pairs = {}
		for item in items:
			pair = item.split('=')
			key = pair[0].strip()
			value = pair[1].strip()
			pairs[key] = value

		tn = pairs['target-name']
		cfg = pairs['configure']
		if  tn == target_name and cfg == configure:
			certificate = pairs['certificate']
			if 'identify' in pairs:
				identify = pairs['identify']
			config_bundle_id = pairs['bundle-id']
			mobile_provision = pairs['mobile-provision-file']
			break

	if mobile_provision == None or os.path.exists(mobile_provision) == False:
		return None,config_bundle_id,None
	return get_mobile_provision_info(mobile_provision, target_bundle_id, certificate), config_bundle_id, identify

exclude_rename_file_configs_groups = {}
exclude_confuse_file_configs_groups = {}
exclude_inflate_include_file_configs_groups = {}

file_prefix_configs = {}

def read_exclude_file_configs(package_dir):
	rename_file_path = '%s/exclude_rename_file_configs.txt' % package_dir
	confound_file_path = '%s/exclude_confuse_file_configs.txt' % package_dir
	inflate_file_path = '%s/exclude_inflate_file_configs.txt' % package_dir
	load_exclude_file_configs(exclude_rename_file_configs_groups, rename_file_path)
	load_exclude_file_configs(exclude_confuse_file_configs_groups, confound_file_path)
	load_exclude_file_configs(exclude_inflate_include_file_configs_groups, inflate_file_path)
	pass

def convert_to_re(text):
	sps = ['\\', '$', '(', ')', '*', '+', '.', '[','?', '^', '{', '|']
	for sp in sps:
		text = text.replace(sp, '\\%s' % (sp))
	text = text.replace('\\*\\*', '.+')
	text = text.replace('\\*', '.*')
	#print text
	return text

def load_exclude_file_configs(result, filename):
	with open(filename, 'r') as f:
		lines = f.readlines()
		group = None
		for line in lines:
			value = line.strip()
			if len(value):
				if value[0] == '<' and value[len(value) - 1] == '>':
					name = value[1:len(value) - 1]
					group = []
					result[name] = group
				elif group != None:
					p = re.compile('^%s$' % convert_to_re(value))
					group.append(p)
		f.close()


def replace_text_vars(envs, item):
	start = 0
	end = len(item)
	toitem = ''
	while start < end:
		idx1 = item.find('${', start)
		idx2 = -1
		if idx1 != -1:
			idx2 = item.find('}', idx1)

		if idx1 == -1 and idx2 == -1:
			idx1 = item.find('$(', start)
			if idx1 != -1:
				idx2 = item.find(')', idx1)

		if idx1 != -1 and idx2 != -1:
			if idx1 > start:
				toitem = '%s%s' % (toitem, item[start:idx1])
			envname = item[idx1 + 2:idx2]

			if envname in envs:
				toitem = '%s%s' % (toitem, envs[envname])
			else:
				toitem = '%s${%s}' % (toitem, envname)
			start = idx2 + 1
		else:
			t = item[start:end]

			if len(t):
				toitem = toitem + t
			start = end
		pass
	return toitem
	
	
def is_rename_include(filetype, filepath):
	items = ['.h', '.m', '.mm', '.c', '.cpp', '.cc', '.swift']
	if filetype in items:
		return False
	if filetype in exclude_rename_file_configs_groups:
		regs = exclude_rename_file_configs_groups[filetype]
		for reg in regs:
			#print filepath
			if reg.match(filepath) != None:
				return False
	return True

def is_confuse_include(filetype, filepath):
	if filetype in exclude_confuse_file_configs_groups:
		regs = exclude_confuse_file_configs_groups[filetype]
		for reg in regs:
			if reg.match(filepath) != None:
				return False
	return True

def is_inflate_include(filetype, filepath):
	items = []
	if filetype in items:
		return False
	if filetype in exclude_inflate_include_file_configs_groups:
		regs = exclude_inflate_include_file_configs_groups[filetype]
		for reg in regs:
			if reg.match(filepath) != None:
				return False
	return True

def read_settings_file(filename):
	ret = {}
	with open(filename, 'r') as f:
		lines = f.readlines()
		group = None
		for line in lines:
			value = line.strip()
			if len(value):
				if value[0] == '<' and value[len(value) - 1] == '>':
					name = value[1:len(value) - 1]
					group = []
					ret[name] = group
				elif group != None:
					group.append(value)
		f.close()
	return ret

def get_oldcat_sdk_path(work_dir, bundle_id):
	package_dir = '%s/packages/%s' % (work_dir, bundle_id)
	depends_file = '%s/depend_files.txt' % (package_dir)
	groups = read_settings_file(depends_file)
	oldcat = groups['cosdk']
	for item in oldcat:
		if item.endswith('.h'):
			return get_file_dir(item)
	return None

def read_properties_file(filename):
	ret = {}
	with open(filename, 'r') as f:
		lines = f.readlines()
		for line in lines:
			idx = line.find('=')
			if idx != -1:
				line = line.strip()
				paris = line.split('=')
				if len(paris) == 2:
					key = paris[0].strip()
					value = paris[1].strip()
					ret[key] = value
	return ret

def add_file_rename(work_dir, bundle_id, src_file, dst_file, close_connection = True):
	open_connect(work_dir, bundle_id)
	db_cursor.execute('select * from t_file_rename where file_name = \"%s\" and bundle_id = (select id from t_bundle where name=\"%s\")' % (src_file, bundle_id))
	res = db_cursor.fetchone()
	if res == None:
		db_cursor.execute('insert into t_file_rename VALUES(NULL, \"%s\", \"%s\", (select id from t_bundle where name=\"%s\"), 1)' % (src_file, dst_file, bundle_id))
		if not transaction_enable:
			db_connect.commit()
		else:
			global transaction_counter
			transaction_counter = transaction_counter + 1
	if close_connection:
		close_connect()
	pass

def fetch_bundle_activite_code(bundle_id):
	db_cursor.execute('select id,unique_id,valid_product_code,rand_seed from t_activity_code where bundle_identifier = \"%s\"' % bundle_id)
	res = db_cursor.fetchone()
	if res == None:
		return None
	info = {}
	info['id'] = res[0]
	info['unique_id'] = res[1]
	info['valid_product_code'] = res[2]
	info['rand_seed'] = res[3]
	return info

def sort_files(paths):
	levels = {}
	ret = []
	for path in paths:
		sep_count = path.count(os.sep)
		level_items = []
		if sep_count in levels:
			level_items = levels[sep_count]
		else:
			levels[sep_count] = level_items
		level_items.append(path)

	level_keys = list(levels.keys())
	level_keys.sort(reverse=True)
	ret = []
	for key in level_keys:
		level_items = levels[key]
		for level_item in level_items:
			ret.append(level_item)
	return ret

def get_all_file_rename(work_dir, bundle_id, close_connection = True):
	ret = []
	open_connect(work_dir, bundle_id)
	db_cursor.execute('select file_name, new_name from t_file_rename where bundle_id = (select id from t_bundle where name=\"%s\") order by length(file_name) desc' % bundle_id)
	res = db_cursor.fetchall()
	map = {}
	for item in res:
		name = item[0]
		newname = item[1]
		map[name] = newname
	files = []
	keys = list(map.keys())
	for key in keys:
		files.append(key)
	#ret = sort_files(files)
	files.sort(reverse=True)
	for file in files:
		ret.append([file, map[file]])
	if close_connection:
		close_connect()
	return ret

file_rename_map = {}
def load_file_rename_map(work_dir, bundle_id, close_connection = True):
	open_connect(work_dir, bundle_id)
	
	db_cursor.execute('select file_name, new_name from t_file_rename where kind = 1 and bundle_id = (select id from t_bundle where name=\"%s\") order by length(file_name) desc' % bundle_id)
	res = db_cursor.fetchall()
	for item in res:
		file_rename_map[item[0]]=item[1]
	
	if close_connection:
		close_connect()

def roll_backup_files(work_dir, bundle_id):
	files = get_backup_files(work_dir, bundle_id)
	open_connect(work_dir, bundle_id)
	changed = {}
	for i in range(0, len(files)):
		file = files[i]
		bid = file[0]
		filename = file[1]
		backup = file[2]
		if filename in changed.keys():
			continue
		changed[filename] = backup
		print(('backup %s\n' % backup))
		print(('filename %s\n' % filename))
		if os.path.exists(backup):
			fast_copy_file(backup, filename)
			if os.path.isdir(backup):
				shutil.rmtree(backup)
			else:
				os.remove(backup)
		db_cursor.execute('delete from t_backup_file where id = %d' % bid)
		db_connect.commit()
	close_connect()

def mark_warnings(work_dir, bundle_id, close_connection = True):
	open_connect(work_dir, bundle_id)
	db_cursor.execute('update t_warning set status = status | 4 where source_file_id in(select id from t_source_file where bundle_id = (select id from t_bundle where name = \"%s\"))' % (bundle_id))
	db_connect.commit()
	if close_connection:
		close_connect()
	pass

def copy_warnings(work_dir, bundle_id, main_bundle_id, close_connection = True):
	open_connect(work_dir, bundle_id)
	db_cursor.execute('select id,version from t_bundle where name = "%s"' % (bundle_id))
	res = db_cursor.fetchone()
	nbid = res[0]
	nver = res[1] + 1
	db_cursor.execute('select id from t_bundle where name in(select bundle_identifier from t_activity_code where main_bundle_identifier = "%s" and bundle_identifier != "%s")' % (main_bundle_id, bundle_id))
	res = db_cursor.fetchall()
	for item in res:
		bid = item[0]
		db_cursor.execute('select * from t_target where bundle_id = %d' % (bid))
		tres = db_cursor.fetchall()
		for titem in tres:
			db_cursor.execute('select * from t_target where name=?', (titem[1],))
			ttres = db_cursor.fetchone()
			if ttres == None:
				db_cursor.execute('insert into t_target VALUES(NULL, ?, ?, ?)', (titem[1], nbid, nver,))
				db_connect.commit()
				ntid = db_cursor.lastrowid
				#print 'insert t_target id=%d, name=%s, bundle_id=%d, version=%d' % (ntid, titem[1], nbid, nver)
			else:
				ntid = ttres[0]
			db_cursor.execute('select * from t_source_file where bundle_id = %d and target_id = %d' % (bid, titem[0],))
			sres = db_cursor.fetchall()
			for sitem in sres:
				ssres = db_cursor.fetchone()
				if ssres == None:
					db_cursor.execute('insert into t_source_file VALUES(NULL, ?, ?, ?)', (sitem[1], nbid, ntid,))
					db_connect.commit()
					nsid = db_cursor.lastrowid
					#print 'insert t_source_file id=%d, name=%s, bundle_id=%d target_id=%d' % (nsid, sitem[1], nbid, ntid)
				else:
					nsid = ssres[0]
				db_cursor.execute('select * from t_warning where source_file_id = %d' % (sitem[0]))
				wres = db_cursor.fetchall()
				for witem in wres:
					db_cursor.execute('select * from t_warning where message = ? and lineno = ? and code =?', (witem[2], witem[4], witem[5],))
					wwres = db_cursor.fetchone()
					if wwres == None:
						db_cursor.execute('insert into t_warning VALUES(NULL, ?, ?, ?, ?, ?, ?)', (nsid, witem[2], witem[3], witem[4], witem[5], witem[6]))
						#print 'insert t_warning source_fild_id=%d,message=%s,status=%d,lineno=%d,code=%s' % (nsid, witem[2], witem[3], witem[4], witem[5])
						db_connect.commit()
	if close_connection:
		close_connect()
	pass

def copy_match_strings(work_dir, bundle_id, main_bundle_id, close_connection = True):
	open_connect(work_dir, bundle_id)
	db_cursor.execute('select id,version from t_bundle where name = "%s"' % (bundle_id))
	res = db_cursor.fetchone()
	nbid = res[0]
	nver = res[1] + 1
	db_cursor.execute('select id from t_bundle where name in(select bundle_identifier from t_activity_code where main_bundle_identifier = "%s" and bundle_identifier != "%s")' % (main_bundle_id, bundle_id))
	res = db_cursor.fetchall()
	for item in res:
		bid = item[0]
		db_cursor.execute('select * from t_target where bundle_id = %d' % (bid))
		tres = db_cursor.fetchall()
		for titem in tres:
			db_cursor.execute('select * from t_target where name=?', (titem[1],))
			ttres = db_cursor.fetchone()
			if ttres == None:
				db_cursor.execute('insert into t_target VALUES(NULL, ?, ?, ?)', (titem[1], nbid, nver,))
				db_connect.commit()
				ntid = db_cursor.lastrowid
			else:
				ntid = ttres[0]
			#print 'insert t_target id=%d, name=%s, bundle_id=%d, version=%d' % (ntid, titem[1], nbid, nver)
			db_cursor.execute('select * from t_source_file where bundle_id = %d and target_id = %d' % (bid, titem[0],))
			sres = db_cursor.fetchall()
			for sitem in sres:
				db_cursor.execute('select * from t_source_file where name = ?', (sitem[1],))
				ssres = db_cursor.fetchone()
				if ssres == None:
					db_cursor.execute('insert into t_source_file VALUES(NULL, ?, ?, ?)', (sitem[1], nbid, ntid,))
					db_connect.commit()
					nsid = db_cursor.lastrowid
				else:
					nsid = ssres[0]
				#print 'insert t_source_file id=%d, name=%s, bundle_id=%d target_id=%d' % (nsid, sitem[1], nbid, ntid)
				db_cursor.execute('select * from t_match_string where source_file_id = %d' % (sitem[0]))
				mres = db_cursor.fetchall()
				for mitem in mres:
					db_cursor.execute('select * from t_match_string where value = ? and type = ?', (mitem[2], mitem[3],))
					mmres = db_cursor.fetchone()
					if mmres == None:
						db_cursor.execute('insert into t_match_string VALUES(NULL, ?, ?, ?, ?)' % (nsid, mitem[2], mitem[3], mitem[4],))
						#print 'insert t_match_string source_fild_id=%d,value=%s,type=%s,status=%d' % (nsid, mitem[2], mitem[3], mitem[4])
						db_connect.commit()
	if close_connection:
		close_connect()
	pass

def get_file_rename_map(work_dir, bundle_id):
	if len(list(file_rename_map.keys())) == 0:
		load_file_rename_map(work_dir, bundle_id)

	ret = {}
	files = list(file_rename_map.keys())
	for file in files:
		ret[file] = get_file_rename(work_dir, bundle_id, file_rename_map[file])
	return ret

def get_file_rename(work_dir, bundle_id, src_file, close_connection = True):
	if len(list(file_rename_map.keys())) == 0:
		load_file_rename_map(work_dir, bundle_id, close_connection)
	pairs = os.path.realpath(src_file).split('/')
	new_path = []
	for i in range(0, len(pairs)):
		path = '/'.join(pairs[0:i + 1])
		if path in file_rename_map:
			new_path.append(file_rename_map[path].split('/')[-1])
		else:
			new_path.append(path.split('/')[-1])
	return '/'.join(new_path)

def add_backup_file(work_dir, bundle_id, src_file, backup_file, need_close_connect = True):
	open_connect(work_dir, bundle_id)
	db_cursor.execute('insert into t_backup_file VALUES(NULL, (select id from t_bundle where name=\"%s\"), \"%s\", \"%s\")' % (bundle_id, src_file, backup_file))
	db_connect.commit()
	if need_close_connect:
		close_connect()
	pass

def back_file(workspace_dir, work_dir, bundle_id, src_file, need_close_connect = True):
	#print('😄 "%s" "%s"' % (workspace_dir, src_file))
	open_connect(work_dir, bundle_id)
	db_cursor.execute('select * from t_backup_file where filename = \"%s\" and bundle_id = (select id from t_bundle where name=\"%s\")' % (pstr(src_file), bundle_id))
	res = db_cursor.fetchall()
	if len(res):
		if need_close_connect:
			close_connect()
		return
	rel_path = os.path.relpath(src_file, workspace_dir)
	new_rel_path = rel_path.replace('../', '{..}/')
	#print('😄 "%s" "%s"' % (rel_path, new_rel_path))
	backup_file = '%s/packages/%s/back/%s' % (work_dir, bundle_id, new_rel_path)
	fast_copy_file(src_file, backup_file)
	add_backup_file(work_dir, bundle_id, src_file, backup_file, need_close_connect)
	pass

def compare_backupfile(a, b):
	ret = len(a[1]) - len(b[1])
	if ret > 0:
		return -1
	elif ret < 0:
		return 1
	else:
		return 0

def get_backup_files(work_dir, bundle_id):
	open_connect(work_dir, bundle_id)
	db_cursor.execute('select id,filename,backup from t_backup_file where bundle_id = (select id from t_bundle where name=\"%s\")' % bundle_id)
	res = db_cursor.fetchall()
	ret = []
	for row in res:
		bid = row[0]
		filename = row[1]
		backup = row[2]
		ret.append([bid, filename, backup])
		pass
	close_connect()
	ret.sort(key=functools.cmp_to_key(compare_backupfile))
	return ret
	pass

def add_temp_file(work_dir, bundle_id, src_file, close_connection = True):
	open_connect(work_dir, bundle_id)
	db_cursor.execute('insert into t_temp_file VALUES(NULL, (select id from t_bundle where name=?), ?)', (bundle_id, src_file, ))
	if not transaction_enable:
		db_connect.commit()
	else:
		global transaction_counter
		transaction_counter = transaction_counter + 1
	if close_connection:
		close_connect()
	pass
 
PathType_Fixup = 0
PathType_Ruote = 1
PathType_ImageName = 2
PathType_ObjCClass = 3
PathType_ObjCProtocol = 4
PathType_ObjCSelector = 5

def add_path_to_map(work_dir, bundle_id, target_name, path, new_path, type = PathType_Fixup, close_connection = True):
	print('add path to map type:%d %s %s' % (type, path, new_path))
	open_connect(work_dir, bundle_id)
	db_cursor.execute('insert into t_path_map VALUES(NULL, ?, ?, (select id from t_bundle where name=?), (select id from t_target where name=?), ?)', (path, new_path, bundle_id, target_name, type,))
	if not transaction_enable:
		db_connect.commit()
	else:
		global transaction_counter
		transaction_counter = transaction_counter + 1
	
	if close_connection:
		close_connect()
	pass

def get_path_map(work_dir, bundle_id, target_name, type, close_connection = True):
	ret = {}
	open_connect(work_dir, bundle_id)
	#cmd = 'select path,newpath from t_path_map where bundle_id = (select id from t_bundle where name=%s) and type = %d' % (bundle_id, type)
	#print('get path map:%s' % cmd)
	db_cursor.execute('select path,newpath from t_path_map where bundle_id = (select id from t_bundle where name=?) and type = ?', (bundle_id, type,))
	res = db_cursor.fetchall()
	for row in res:
		ret[row[0]] = row[1]
	print('get path map type:%d %s' % (type, ret))
	if close_connection:
		close_connect()
	return ret

def get_fixup_path_map(work_dir, bundle_id, target_name, close_connection = True):
	return get_path_map(work_dir, bundle_id, target_name, PathType_Fixup, close_connection)

def get_route_path_map(work_dir, bundle_id, target_name, close_connection = True):
	return get_path_map(work_dir, bundle_id, target_name, PathType_Ruote, close_connection)

def get_image_name_path_map(work_dir, bundle_id, target_name, close_connection = True):
	return get_path_map(work_dir, bundle_id, target_name, PathType_ImageName, close_connection)

def compare_tempfile(a, b):
	ret = len(a[1]) - len(b[1])
	if ret > 0:
		return -1
	elif ret < 0:
		return 1
	else:
		return 0

def get_file_name(filepath):
	start = filepath.rfind('/')
	end = filepath.rfind('.')

	if start != -1 and end != -1:
		if end > start:
			return filepath[start + 1: end]
	elif start != -1:
		return filepath[start + 1:]
	elif end != -1:
		return filepath[:end]
	return ""

def get_file_dir(filepath):
	return filepath[:filepath.rfind('/')]

def get_full_file_name(filepath):
	start = filepath.rfind('/')
	return filepath[start + 1:]

def get_file_extension(filepath):
	idx = filepath.rfind('.')
	if idx != -1:
		return filepath[idx + 1:]
	return None

def get_file_dir(filepath):
	idx = filepath.rfind('/')
	if idx != -1:
		return filepath[0:idx]
	return None

def get_bundle_name(filepath):
	idx = filepath.rfind('.bundle/')
	if idx == -1:
		return None
	prefix = filepath[0:idx]
	idx = prefix.rfind('/')
	return prefix[idx + 1:]

resource = {}

def load_keywords_file(package_dir):
	path = '%s/confound-keywords.txt' % package_dir
	jsobj = json.load(open(path, 'r'))
	res = jsobj['resource']
	for key in list(res.keys()):
		resource[key] = res[key]
	pass

def get_seed_key(package_dir):
	path = '%s/confound-keywords.txt' % package_dir
	jsobj = json.load(open(path, 'r'))
	return int(jsobj['seed-key'], 16)

def split_words(name, words):
	isupcase = False
	size = 0
	for i in range(0, len(name)):
		if name[i] >= 'A' and name[i] <= 'Z':
			if isupcase == False:
				if size > 0:
					words.append(name[i - size:i])
				size = 0
			isupcase = True
			size = size + 1
		else:
			if name[i] == '_':
				if size > 0:
					words.append(name[i - size:i])
				size = 0
			isupcase = False
			size = size + 1
	if size > 0:
		words.append(name[len(name) - size:len(name)])
	pass

def all_is_upcase(word):
	c = 0
	for i in range(0, len(word) - 1):
		if word[i] >= 'A' and word[i] <= 'Z':
			c += 1
	return c == len(word)

def merge_words(words):
	result = ''
	upcase_count = 0
	underline_count = 0
	for v in words:
		if v[0] >='A' and v[0] <= 'Z':
			upcase_count += 1
		elif v[0] == '_':
			underline_count += 1

	if upcase_count >= len(words) / 2:
		for v in words:
			if all_is_upcase(v):
				result += v
			else:
				result += v.capitalize()
	else:
		for v in words:
			result += v.lower()
	return result

name_rand_seed = 0

def name_rand_int(start, end):
	global name_rand_seed
	name_rand_seed = (name_rand_seed * 1333333) * 33
	if end - start == 0:
		return start
	v = name_rand_seed % (end - start)
	return start + v

def gen_new_name(prefixs, infixs, suffixs, name):
	name_rand_seed = crc32(bytearray(name, 'utf-8'))
	v = name_rand_int(0, 100)
	words = []
	split_words(name, words)
	add_prefix = False
	add_suffix = False
	if len(prefixs) and len(suffixs):
		if v < 60:
			add_prefix = True
		else:
			add_suffix = True
	elif len(prefixs):
		add_prefix = True
	elif len(suffixs):
		add_suffix = True
	if add_prefix:
		while len(prefixs):
			idx = name_rand_int(0, len(prefixs) - 1)
			if name.startswith(prefixs[idx]) == False:
				words.insert(0, prefixs[idx])
				break
			del prefixs[idx]
	while len(infixs):
		idx = name_rand_int(0, len(infixs) - 1)
		found = False
		for v in words:
			if v == infixs[idx]:
				found = True
				break
		if found == False:
			last_pos = len(words) - 2
			if last_pos > 1:
				insert_pos = name_rand_int(1, len(words) - 2)
				words.insert(insert_pos, infixs[idx])
			break
		del infixs[idx]
	if add_suffix:
		while len(suffixs):
			idx = name_rand_int(0, len(suffixs) - 1)
			if name.endswith(suffixs[idx]) == False:
				words.append(suffixs[idx])
				break
			del suffixs[idx]
	return merge_words(words)

def load_file_group_configs(work_dir, bundle_id, prefixs, infixs, suffixs, close_connection = True):
	package_dir = '%s/packages/%s' % (work_dir, bundle_id)
	filename = '%s/file_group_configs.txt' % package_dir
	settings = read_settings_file(filename)
	if ('file-name-prefix' in settings) == False:
		return
	open_connect(work_dir, bundle_id)
	items = settings['file-name-prefix']
	for item in items:
		name = item.strip()

		db_cursor.execute('select * from t_file_group where prefix = \"%s\" and bundle_id = (select id from t_bundle where name=\"%s\")' % (name, bundle_id))
		res = db_cursor.fetchone()
		if res == None:
			newname = gen_new_name(prefixs, infixs, suffixs, name)
			db_cursor.execute('insert into t_file_group values(NULL, \"%s\", \"%s\", (select id from t_bundle where name=\"%s\"))' % (name, newname, bundle_id))
			db_connect.commit()
		else:
			newname = res[2]
		file_prefix_configs[name] = newname
	if close_connection:
		close_connect()
	pass

def get_symbol_new_name(work_dir, bundle_id, name, tag, close_connection = True):
	open_connect(work_dir, bundle_id)

	bundle_info = get_bundle_info(bundle_id)
	db_cursor.execute('select new_name from t_symbol_rename where string_id = (select id from t_string where id = (select id from t_string where value = \"%s\" and bundle_id = %d)) and tag_id = (select id from t_tag where name = \"%s\") and bundle_id = %d' % (name, bundle_info[0], tag, bundle_info[0]))
	res = db_cursor.fetchone()
	
	if close_connection:
		close_connect()
	if res == None:
		#print 'get symbol new name %s %s %s' % (name, tag, name)
		return name
	#print 'get symbol new name %s %s %s' % (name, tag, res[0])
	return res[0]

def get_constant_new_value(work_dir, bundle_id, value, close_connection = True):
	open_connect(work_dir, bundle_id)
	
	db_cursor.execute('select new_value from t_constant_new_value where string_id = (select id from t_string where value = \"%s\") and bundle_id = (select id from t_bundle where name = \"%s\")' % (value, bundle_id))
	res = db_cursor.fetchone()
	
	if close_connection:
		close_connect()
	if res == None:
		return value
	return res[0]

def new_symbol_name(work_dir, bundle_id, name, typename):
	newname = get_symbol_new_name(work_dir, bundle_id, name, typename)

	if newname != name:
		return newname
		
	package_dir = '%s/packages/%s' % (work_dir, bundle_id)

	if len(list(resource.keys())) == 0:
		load_keywords_file(package_dir)

	fixs = resource['default']

	if typename in resource:
		fixs = resource[typename]

	prefixs = []
	if 'prefix' in fixs:
		prefixs = fixs['prefix']
	infixs = []
	if 'infix' in fixs:
		infixs = fixs['infix']
	suffixs = []
	if 'suffix' in fixs:
		suffixs = fixs['suffix']

	#find cache
	if len(list(file_prefix_configs.keys())) == 0:
		load_file_group_configs(work_dir, bundle_id, prefixs[:], infixs[:], suffixs[:])

	newname = None
	#file group
	file_prefixs = list(file_prefix_configs.keys())
	file_prefixs.sort()
	for prefix in file_prefixs:
		if name.startswith(prefix):
			new_prefix = file_prefix_configs[prefix]
			newname = new_prefix + name[len(prefix):]
			break

	open_connect(work_dir, bundle_id)
	if newname == None:
		newname = gen_new_name(prefixs[:], infixs[:], suffixs[:], name)

	symbol = get_symbol(name, typename)
	open_connect(work_dir, bundle_id)
	db_connect.execute('begin;')
	if symbol == None:
		symbol = add_symbol(work_dir, bundle_id, name, typename, False)
	string_id = symbol.string_id
	#new name
	tag_id = get_tag_id(typename)
	db_cursor.execute('insert into t_symbol_rename values(%s, \"%s\", (select id from t_bundle where name=\"%s\"), %d)' % (string_id, newname, bundle_id, tag_id))
	db_connect.commit()
	close_connect()
	return newname

def set_bundle_config_value(work_dir, bundle_id, key_name, value, need_close_connect = True):
	open_connect(work_dir, bundle_id)
	db_cursor.execute('insert into t_configs values((select id from t_bundle where name=\"%s\"), \"%s\", \"%s\")' % (bundle_id, key_name, value))
	db_connect.commit()
	if need_close_connect:
		close_connect()

def get_bundle_config_value(work_dir, bundle_id, key_name, def_value, need_close_connect = True):
	open_connect(work_dir, bundle_id)
	db_cursor.execute('select * from t_configs where bundle_id = (select id from t_bundle where name=\"%s\") and name = \"%s\"' % (bundle_id, key_name))
	ret_value = def_value
	ret = db_cursor.fetchone()
	if ret != None:
		ret_value = ret[2]
	if need_close_connect:
		close_connect()
	return ret_value

def clean_configs(work_dir, bundle_id):
	open_connect(work_dir, bundle_id)
	db_cursor.execute('delete from t_configs where bundle_id = (select id from t_bundle where name=\"%s\")' % (bundle_id))
	db_connect.commit()
	close_connect()

def new_resource_name(work_dir, bundle_id, name, typename = 'default'):
	package_dir = '%s/packages/%s' % (work_dir, bundle_id)
	if len(list(resource.keys())) == 0:
		load_keywords_file(package_dir)

	fixs = resource['default']

	if typename in resource:
		fixs = resource[typename]

	prefixs = []
	if 'prefix' in fixs:
		prefixs = fixs['prefix']
	infixs = []
	if 'infix' in fixs:
		infixs = fixs['infix']
	suffixs = []
	if 'suffix' in fixs:
		suffixs = fixs['suffix']
	return gen_new_name(prefixs[:], infixs[:], suffixs[:], name)

def new_constant_value(work_dir, bundle_id, value, typename, defvalue = None, close_connection = True):
	open_connect(work_dir, bundle_id)
	constant = get_constant(value, typename)
	if constant == None:
		constant = add_constant(work_dir, bundle_id, value, typename, False)
	string_id = constant.string_id
	newvalue = get_constant_new_value(work_dir, bundle_id, value, False)
	package_dir = '%s/packages/%s' % (work_dir, bundle_id)

	if defvalue == None:
		if len(list(resource.keys())) == 0:
			load_keywords_file(package_dir)

		fixs = resource['default']

		if typename in resource:
			fixs = resource[typename]

		prefixs = []
		if 'prefix' in fixs:
			prefixs = fixs['prefix']
		infixs = []
		if 'infix' in fixs:
			infixs = fixs['infix']
		suffixs = []
		if 'suffix' in fixs:
			suffixs = fixs['suffix']

		#find cache
		if len(list(file_prefix_configs.keys())) == 0:
			load_file_group_configs(work_dir, bundle_id, prefixs[:], infixs[:], suffixs[:], False)

		newvalue = None
		#file group
		file_prefixs = list(file_prefix_configs.keys())
		for prefix in file_prefixs:
			if value.startswith(prefix):
				new_prefix = file_prefix_configs[prefix]
				newvalue = new_prefix + value[len(prefix):]
				break

		if newvalue == None:
			newvalue = gen_new_name(prefixs[:], infixs[:], suffixs[:], value)
	else:
		newvalue = defvalue

	print(('new constant value:%s newvalue:%s' % (value, newvalue)))
	#open_connect(work_dir, bundle_id)
	#new value
	db_cursor.execute('insert into t_constant_new_value values(%s, \"%s\", (select id from t_bundle where name=\"%s\"))' % (string_id, newvalue, bundle_id))
	if not transaction_enable:
		db_connect.commit()
	else:
		global transaction_counter
		transaction_counter = transaction_counter + 1

	if close_connection:
		close_connect()
	return newvalue

def get_user(package_dir):
	if len(list(resource.keys())) == 0:
		load_keywords_file(package_dir)
	if user is None:
		return 'system user'
	return user

db_connect = None
db_cursor = None
db_semlock = -1
db_string_id = 0
db_bundle_id = None

def open_connect(work_dir, bundle_id):
	global db_connect
	global db_cursor
	global db_bundle_id
	if db_connect == None:
		db_connect = sqlite3.connect('%s/symbols.db' % work_dir, timeout = 30)
		db_connect.text_factory = str
		db_connect.execute('PRAGMA synchronous = OFF') #关闭同步
		db_cursor = db_connect.cursor()
		db_bundle_id = bundle_id
	pass

def close_connect():
	global db_connect
	global db_cursor
	if db_connect != None:
		db_connect.close()
		db_cursor = None
		db_connect = None

def dbfile_lock():
	global db_semlock
	if db_semlock == -1:
		db_semlock = open('/var/tmp/crab-db-lock', 'a+')
		fcntl.flock(db_semlock, fcntl.LOCK_EX)
		#db_semlock = pysemlock.PySemLock_get('crab-db-lock')
	#print 'try-lock'
	#pysemlock.PySemLock_lock(db_semlock)
	#print 'locked'
	pass

def dbfile_unlock():
	#print 'try-unlock'
	if db_semlock != -1:
		fcntl.flock(db_semlock, fcntl.LOCK_UN)
	#pysemlock.PySemLock_unlock(db_semlock)
	#print 'unlocked'
	pass

def begin_transaction(work_dir, bundle_id):
	global transaction_enable
	dbfile_lock()
	open_connect(work_dir, bundle_id)
	db_connect.execute('begin;')
	transaction_enable = True
	pass

def commit_transaction():
	global transaction_enable
	transaction_enable = False
	if transaction_counter > 0:
		db_connect.commit()
	close_connect()
	dbfile_unlock()
	pass

tag_map = {}
def read_tags():
	db_cursor.execute('select * from t_tag')
	res = db_cursor.fetchall()
	#print 'read strings %s' %(len(res))
	for item in res:
		tag_id = item[0]
		name = item[1]
		tag_map[name] = tag_id
	pass

def get_tag_name(id):
	if len(tag_map.keys()) == 0:
		read_tags()
	for key, val in list(tag_map.items()):
		if id == val:
			return key
	return None

def create_tag(name):
	if len(tag_map.keys()) == 0:
		read_tags()
	db_cursor.execute('insert into t_tag VALUES(NULL, \"%s\")' % name)
	db_connect.commit()
	db_cursor.execute('select * from t_tag where name = \"%s\"' % name)
	res = db_cursor.fetchone()
	tag_id = res[0]
	tag_map[name] = tag_id
	return tag_id

string_map = {}
def read_strings():
	bundle_id = db_bundle_id
	db_cursor.execute('select * from t_string where bundle_id = (select id from t_bundle where name = \"%s\")' % bundle_id)
	res = db_cursor.fetchall()
	#print 'read strings %s' %(len(res))
	global db_string_id
	db_string_id = 0
	for item in res:
		string_id = item[0]
		if string_id > db_string_id:
			db_string_id = string_id + 1
		value = item[1]
		string_map[string_id] = value
	pass

def create_string(name, bundle_id):
	global db_string_id
	db_string_id = db_string_id + 1
	db_cursor.execute('insert into t_string VALUES(%d, \"%s\", %d)' % (db_string_id, name, bundle_id))
	db_connect.commit()
	return db_string_id

def get_string_id(name):
	if len(string_map.keys()) == 0:
		read_strings()
	if name in string_map:
		return string_map[name]
	return -1

def get_tag_id(name):
	if len(tag_map.keys()) == 0:
		read_tags()
	if name in tag_map:
		return tag_map[name]
	return -1

class Symbol:
	def __init__(self,string_id):
		self.string_id = string_id
		self.tags = []

	def string_id(self):
		return self.string_id

	def tags(self):
		return self.tags

	def hasTag(self,tag_id):
		for v in self.tags:
			if v == tag_id:
				return True
		return False

	def addTag(self,tag_id):
		self.tags.append(tag_id)

symbol_map = {}
def read_symbols():
	bundle_id = db_bundle_id
	if len(string_map.keys()) == 0:
		read_strings()

	db_cursor.execute('select * from t_symbol where bundle_id = (select id from t_bundle where name = \"%s\")' % bundle_id)
	res = db_cursor.fetchall()

	#print 'read symbols %s' % (len(res))
	for item in res:
		symbol_id = item[0]
		string_id = item[1]
		tag_id = item[4]
		name = string_map[string_id]
		if name in symbol_map:
			symbol = symbol_map[name]
		else:
			symbol = Symbol(string_id)
			symbol_map[name] = symbol
		symbol.addTag(tag_id)
	pass

constant_map = {}
def read_constants():
	bundle_id = db_bundle_id
	if len(string_map.keys()) == 0:
		read_strings()

	db_cursor.execute('select * from t_constant where bundle_id = (select id from t_bundle where name = \"%s\") and target_id is NULL' % bundle_id)
	res = db_cursor.fetchall()
	for item in res:
		constant_id = item[0]
		string_id = item[1]
		tag_id = item[5]
		value = string_map[string_id]
		if value in constant_map:
			constant = constant_map[value]
		else:
			constant = Symbol(string_id)
			constant_map[value] = constant
		constant.addTag(tag_id)
	pass

def create_symbol(name, string_id, tag_id, bundle_id, version):
	if len(symbol_map.keys()) == 0:
		read_symbols()
	db_cursor.execute('insert into t_symbol VALUES(NULL, %s, %s, %s, %s)' % (string_id, bundle_id, version, tag_id))
	db_connect.commit()
	if name in symbol_map:
		symbol = symbol_map[name]
	else:
		symbol = Symbol(string_id)
		symbol_map[name] = symbol
	symbol.addTag(tag_id)
	return symbol

def get_symbol(name, type):
	if len(symbol_map.keys()) == 0:
		read_symbols()
	if name in symbol_map:
		symbol =  symbol_map[name]
		if symbol.hasTag(get_tag_id(type)):
			return symbol
	return None

def create_constant(value, string_id, tag_id, bundle_id, version):
	if len(constant_map.keys()) == 0:
		read_constants()
	db_cursor.execute('insert into t_constant VALUES(NULL, %s, %s, NULL, NULL, %s)' % (string_id, bundle_id, tag_id))
	db_connect.commit()
	symbol = Symbol(string_id)
	symbol.addTag(tag_id)
	constant_map[value] = symbol
	return symbol
	
def get_constant(value, type):
	if len(constant_map.keys()) == 0:
		read_constants()
	if value in constant_map:
		symbol =  constant_map[value]
		if symbol.hasTag(get_tag_id(type)):
			return symbol
	return None

def get_bundle_info(name):
	db_cursor.execute('select id,version from t_bundle where name = \"%s\"' % name)
	res = db_cursor.fetchone()
	return res

def add_symbol(work_dir, bundle_name, name, tag, need_close_connect = True):
	open_connect(work_dir, bundle_name)
	if len(symbol_map.keys()) == 0:
		read_symbols()
	res = get_bundle_info(bundle_name)
	bundle_id = res[0]
	bundle_version = res[1]
	if name in string_map:
		string_id = string_map[name]
	else:
		string_id = create_string(name, bundle_id)
	if tag in tag_map:
		tag_id = tag_map[tag]
	else:
		tag_id = create_tag(tag)

	if name in symbol_map:
		symbol = symbol_map[name]
		if symbol.hasTag(tag_id) == False:
			symbol.addTag(tag_id)
			ret = create_symbol(name, string_id, tag_id, bundle_id, bundle_version + 1)
			if need_close_connect:
				close_connect()
			return ret
		close_connect()
		return symbol
	else:
		symbol_map[name] = create_symbol(name, string_id, tag_id, bundle_id, bundle_version + 1)
		if need_close_connect:
			close_connect()
		return symbol_map[name]
	pass

def add_constant(work_dir, bundle_name, value, tag, close_connection = True):
	open_connect(work_dir, bundle_name)

	if len(constant_map.keys()) == 0:
		read_constants()
	
	res = get_bundle_info(bundle_name)
	bundle_id = res[0]
	bundle_version = res[1]
	if value in string_map:
		string_id = string_map[value]
	else:
		string_id = create_string(value, bundle_id)
	if tag in tag_map:
		tag_id = tag_map[tag]
	else:
		tag_id = create_tag(tag)

	if value in constant_map:
		symbol = constant_map[value]
		if symbol.hasTag(tag_id) == False:
			symbol.addTag(tag_id)
			ret = create_constant(value, string_id, tag_id, bundle_id, bundle_version)
			if close_connection:
				close_connect()
			return ret
		if close_connection:
			close_connect()
		return symbol
	else:
		constant_map[value] = create_constant(value, string_id, tag_id, bundle_id, bundle_version + 1)
		if close_connection:
			close_connect()
		return constant_map[value]
	pass

def clean_symbols(work_dir, bundle_name, close_connection = True):
	open_connect(work_dir, bundle_name)
	bundle_info = get_bundle_info(bundle_name)
	bundle_id = bundle_info[0]
	bundle_version = bundle_info[1]
	print('clean symbols.')
	db_cursor.execute('delete from t_symbol where bundle_id = %s and version = %s' % (bundle_id, bundle_version))
	db_connect.commit()
	if close_connection:
		close_connect()
	pass

def clean_constants(work_dir, bundle_name, close_connection = True):
	open_connect(work_dir, bundle_name)
	bundle_info = get_bundle_info(bundle_name)
	bundle_id = bundle_info[0]
	bundle_version = bundle_info[1]
	print('clean constants.')
	db_cursor.execute('delete from t_constant where bundle_id = %s' % (bundle_id))
	db_connect.commit()
	if close_connection:
		close_connect()
	pass

def clean_constant_new_values(work_dir, bundle_name, close_connection = True):
	open_connect(work_dir, bundle_name)
	bundle_info = get_bundle_info(bundle_name)
	bundle_id = bundle_info[0]
	bundle_version = bundle_info[1]
	print('clean new constant values.')
	db_cursor.execute('delete from t_constant_new_value where bundle_id = %s' % (bundle_id))
	db_connect.commit()
	if close_connection:
		close_connect()
	pass

def clean_symbol_renames(work_dir, bundle_name, close_connection = True):
	open_connect(work_dir, bundle_name)
	bundle_info = get_bundle_info(bundle_name)
	bundle_id = bundle_info[0]
	bundle_version = bundle_info[1]
	print('clean symbol renames')
	db_cursor.execute('delete from t_symbol_rename where bundle_id = %s' % (bundle_id))
	db_connect.commit()
	if close_connection:
		close_connect()

def clean_strings(work_dir, bundle_name, close_connection = True):
	open_connect(work_dir, bundle_name)
	bundle_info = get_bundle_info(bundle_name)
	bundle_id = bundle_info[0]
	bundle_version = bundle_info[1]
	print('clean strings.')
	db_cursor.execute('delete from t_string where bundle_id = %d' % (bundle_id))
	db_connect.commit()
	if close_connection:
		close_connect()
	pass

def clean_tags(work_dir, bundle_name, close_connection = True):
	open_connect(work_dir, bundle_name)
	bundle_info = get_bundle_info(bundle_name)
	bundle_id = bundle_info[0]
	bundle_version = bundle_info[1]
	print('clean tags.')
	db_cursor.execute('delete from t_tag where id not in(select tag_id from t_symbol union select tag_id from t_export_symbol group by tag_id union select tag_id from t_constant group by tag_id)')
	db_connect.commit()
	if close_connection:
		close_connect()
	pass

def clean_backup_files(work_dir, bundle_id, close_connection = True):
	open_connect(work_dir, bundle_id)
	db_cursor.execute('delete from t_backup_file where bundle_id = (select id from t_bundle where name =?)', (bundle_id, ))
	if close_connection:
		close_connect()


def clean_file_renames(work_dir, bundle_id, close_connection = True):
	open_connect(work_dir, bundle_id)
	db_cursor.execute('delete from t_file_rename where bundle_id = (select id from t_bundle where name = \"%s\")' % (bundle_id))
	db_connect.commit()
	if close_connection:
		close_connect()
	pass

def clean_path_map(work_dir, bundle_name, close_connection = True):
	open_connect(work_dir, bundle_name)
	bundle_info = get_bundle_info(bundle_name)
	bundle_id = bundle_info[0]
	bundle_version = bundle_info[1]
	print('clean path map.')
	db_cursor.execute('delete from t_path_map where bundle_id = %s' % (bundle_id))
	db_connect.commit()
	if close_connection:
		close_connect()

def clean_temp_files(work_dir, bundle_id, close_connection = True):
	open_connect(work_dir, bundle_id)
	db_cursor.execute('select id,filename from t_temp_file where bundle_id = (select id from t_bundle where name=\"%s\")' % bundle_id)
	res = db_cursor.fetchall()
	ret = []
	for row in res:
		tid = row[0]
		filename = row[1]
		ret.append([tid, filename])

	ret.sort(key=functools.cmp_to_key(compare_tempfile))
	for item in ret:
		tid = item[0]
		filename = item[1]
		if os.path.exists(filename):
			if os.path.isdir(filename):
				shutil.rmtree(filename)
			else:
				os.remove(filename)
		db_cursor.execute('delete from t_temp_file where id = %d' % (tid))
		db_connect.commit()
	if close_connection:
		close_connect()
	pass

def get_all_rename_map(work_dir, bundle_name, close_connection = True):
	ret = {}
	get_symbol_rename_map(ret, work_dir, bundle_name, close_connection)
	get_constant_rename_map(ret, work_dir, bundle_name, close_connection)
	return ret

def get_symbol_rename_map(ret, work_dir, bundle_name, close_connection = True):
	open_connect(work_dir, bundle_name)

	if len(string_map.keys()) == 0:
		read_strings()
	if len(symbol_map.keys()) == 0:
		read_symbols()
	
	db_cursor.execute('select string_id,new_name,tag_id from t_symbol_rename where bundle_id = (select id from t_bundle where name = \"%s\")' % (bundle_name))
	res = db_cursor.fetchall()
	for item in res:
		string_id = item[0]
		name = string_map[string_id]
		newname = item[1]
		tag_id = item[2]
		symbol = symbol_map[name]
		tag_name = get_tag_name(tag_id)
		key = '%s<%s>' % (name, tag_name)
		ret[key] = newname
	if close_connection:
		close_connect()

def get_constant_rename_map(ret, work_dir, bundle_name, close_connection = True):
	open_connect(work_dir, bundle_name)

	if len(constant_map.keys()) == 0:
		read_constants()
	
	db_cursor.execute('select string_id,new_value from t_constant_new_value where bundle_id = (select id from t_bundle where name = \"%s\")' % (bundle_name))
	res = db_cursor.fetchall()
	for item in res:
		string_id = item[0]
		value = string_map[string_id]
		newvalue = item[1]
		if (value in constant_map) == False:
			continue
		constant = constant_map[value]
		#print 'value:%s tags:%s' % (value, constant.tags)
		for tag_id in constant.tags:
			tag_name = get_tag_name(tag_id)
			key = '%s<%s>' % (value, tag_name)
			ret[key] = newvalue
	
	if close_connection:
		close_connect()
	pass

def get_system_clang_resource_dir():
	b = os.popen('clang -print-resource-dir')
	jstxt = ''.join(b.readlines())
	return jstxt

def get_clang_version():
	resource_dir = get_system_clang_resource_dir()
	idx = resource_dir.find('/usr/lib/clang')
	if idx != -1:
		version = resource_dir[idx + 15:][:2]
		return int(version)
	return 0

def get_clang_dir(settings):
	resource_dir = get_system_clang_resource_dir()
	idx = resource_dir.find('/usr/lib/clang')
	if idx != -1:
		version = resource_dir[idx + 15:][:2]
		return 'clang%s' % version
	return 'clang14'

def get_clang_resource_dir():
	clang_dir = get_clang_dir(None)
	if clang_dir == 'clang15':
		return get_system_clang_resource_dir()
	abs_file_path = os.path.abspath(__file__)
	script_dir = abs_file_path[0:abs_file_path.rfind('/')]
	return '%s/%s/include' % (script_dir, clang_dir)

def load_array_file(name):
	ret = []
	with open(name, 'r') as f:
		ret = json.loads(f.read())
		f.close()
	return ret

def transfromList(configure_list, vars):
	ret = []
	for value in configure_list:
		if isinstance(value, dict):
			value = transfromDict(valuel, vars)
		elif isinstance(value, list):
			value = transfromList(value, vars)
		elif isinstance(value, str):
			value = transfromString(value, vars)
		ret.append(value)
	return ret

def transfromString(string_value, vars):
	idx = string_value.find('$(')
	if idx != -1:
		for name in vars.keys():
			value = vars[name]
			string_value = string_value.replace('$(%s)' % name, value)
	return string_value

def transfromDict(configure_dict, vars):
	ret = {}
	for key in configure_dict.keys():
		value = configure_dict[key]
		if isinstance(value, dict):
			value = transfromDict(value, vars)
		elif isinstance(value, list):
			value = transfromList(value, vars)
		elif isinstance(value, str):
			value = transfromString(value, vars)
		ret[key] = value
	return ret

def write_configure_entitlements(work_dir, bundle_id, package_dir, project_file, target_name, configure, full_entitlements_plist):
	envs = get_build_settings(work_dir, bundle_id, project_file, configure, target_name, True)
	#print envs
	if 'CODE_SIGN_ENTITLEMENTS' in envs:
		entitlment_file = envs['CODE_SIGN_ENTITLEMENTS']
		srcroot = envs['SRCROOT']
		filename = '%s/%s' % (srcroot, entitlment_file)
		full_dict = read_plist(full_entitlements_plist)
		app_identify_prefixs = full_dict['ApplicationIdentifierPrefix']
		full_dict = full_dict['Entitlements']
		vars = {'AppIdentifierPrefix' : '%s.' % app_identify_prefixs[0]}
		configure_dict = transfromDict(read_plist(filename), vars)
		full_keys = ["application-identifier", "com.apple.developer.team-identifier", "get-task-allow"]
		keys = configure_dict.keys()
		for key in keys:
			value = configure_dict[key]
			has_var = False
			if isinstance(value, list):
				for item in value:
					if item.find('$(') != -1:
						has_var = True
						break
			elif isinstance(value, str):
				if value.find('$(') != -1:
					has_var = True
			if has_var:
				full_keys.append(key)
		for key in full_keys:
			if key in full_dict.keys():
				configure_dict[key] = full_dict[key]
		write_plist('%s/%s.%s.%s.entitlements.plist' % (package_dir, bundle_id, configure, target_name), configure_dict)
	else:
		full_dict = read_plist(full_entitlements_plist)
		full_dict = full_dict['Entitlements']
		write_plist('%s/%s.%s.%s.entitlements.plist' % (package_dir, bundle_id, configure, target_name), full_dict)

def print_cmd(argvs):
	cmd = ''
	for argv in argvs:
		arg_str = argv
		cmd = '%s \"%s\"' % (cmd, pstr(arg_str))
	print('🦶 python3 %s' % cmd)

def get_swift_bridge_headers_dir(work_dir, bundle_id, project_name = None, target_name = None):
	package_dir = '%s/packages/%s' % (work_dir, bundle_id)
	if project_name == None and target_name == None:
		target_dir = '%s/SwiftBridgeHeaders' % (package_dir)
	else:
		target_dir = '%s/SwiftBridgeHeaders/%s/%s' % (package_dir, md5str(project_name), target_name)
	return target_dir

def format_product_name(name):
	return name.replace('-', '_')

def get_inflate_data():
	today = datetime.datetime.today()
	size = today.timetuple().tm_yday
	data = bytearray([random.getrandbits(8) for _ in range(size)])
	return data

def inflate_file(file_name):
	temp_data = this.get_inflate_data()
	with open(file_name, 'ab') as f:
		f.write(temp_data)
		f.close()
	pass

def encode_string(text):
	data = text.encode('utf-8')
	encode_str = base64.b64encode(data).decode('utf-8')
	today = datetime.datetime.today()
	no = today.timetuple().tm_yday
	return '\\t@%s.%s' % (hex(no),encode_str)

def makedirs(path):
	if not os.path.exists(path):
		os.makedirs(path)
	pass


def load_xcconfig_file(path, configs):
	if not os.path.exists(path):
		return
	with open(path, 'r') as xccfile:
		lines = xccfile.readlines()
		for line in lines:
			prop = line.strip()
			if len(prop):
				pair = prop.split(' = ')
				if len(pair) == 2:
					name = pair[0].strip()
					value = pair[1].strip()
					configs[name] = value
		xccfile.close()
	return configs
	pass
	