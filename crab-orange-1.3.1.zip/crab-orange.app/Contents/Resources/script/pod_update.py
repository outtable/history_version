#!/usr/bin/python
# -*- coding: UTF-8 -*-

import sys
import os
import confuse_utils
import subprocess
import getpass

def pod_update(work_space_dir, sh_file, work_dir, target_name, bundle_id):
	new_target_name = confuse_utils.get_symbol_new_name(work_dir, bundle_id, target_name, 'target')
	os.environ['NEW_TARGET_NAME'] = new_target_name
	os.environ['WORK_SPACE_DIR'] = work_space_dir
	os.environ['HOME'] = os.path.expanduser('~')
	os.environ['USER'] = getpass.getuser()
	os.environ['LANG'] = 'en_US.UTF-8'
	shell = os.environ['SHELL']
	print(os.environ)
	os.system('chmod 777 \'%s\'' % sh_file)
	p = subprocess.Popen([shell,'--login', '-c', '\'%s\'' % sh_file], env=os.environ,cwd=work_space_dir)
	if p.wait() != 0:
		sys.exit(1)
		pass
	pass

def main(argv):
	if len(argv) != 6:
		print('python pod_update.py [workspacedir] [sh file] [work dir] [target name] [bundle id]')
		sys.exit(1)
	pod_update(argv[1], argv[2], argv[3], argv[4], argv[5])

main(sys.argv)