#!/usr/bin/python
# -*- coding: UTF-8 -*-

import sys
import os
import datetime

from pbxproj import XcodeProject
from pbxproj import PBXAggregateTarget
from pbxproj import XCConfigurationList
from pbxproj import XCBuildConfiguration
from pbxproj import PBXTargetDependency
from pbxproj import PBXContainerItemProxy
import getpass

import confuse_utils
import random;
import json
import shutil
import hashlib
import importlib

importlib.reload(sys)
#sys.setdefaultencoding("utf-8")

abs_file_path = os.path.abspath(__file__)
exe_dir = abs_file_path[0:abs_file_path.rfind('/')]

bundle_id = ''

PRODUCT_TYPE_STATIC = 'com.apple.product-type.library.static'

PRODUCT_TYPE_DYNAMIC = 'com.apple.product-type.library.dynamic'

PRODUCT_TYPE_APPLICATION = 'com.apple.product-type.application'

PRODUCT_TYPE_FRAMEWORK = 'com.apple.product-type.framework'

def rename_file_info(project, fileref, file_path, entitys):
	if file_path in entitys:
		newfilepath = entitys[file_path]
		print('save project - rename %s to %s' % (file_path, newfilepath))
		fileref.path = newfilepath
		#fileref.name = newfilepath[newfilepath.rfind('/') + 1:]
		new_name = confuse_utils.get_full_file_name(newfilepath)
		old_name = confuse_utils.get_full_file_name(file_path)
		fileref.name = '%s=>%s' % (old_name, new_name)
		return True
	return False

def copy_list(cfgmap, target_name, config_name, src):
	target_obj = {}
	if target_name in cfgmap.keys():
		target_obj = cfgmap[target_name]
	else:
		cfgmap[target_name] = target_obj
	dst = []
	if config_name in target_obj.keys():
		dst = target_obj[config_name]
	else:
		target_obj[config_name] = dst
	for item in src:
		dst.append(item)

def join_items(items):
	#print('😄:%s' % items)
	pos = 0
	count = len(items)
	ret = []
	while pos < count:
		item = items[pos]
		if confuse_utils.is_need_value(item.strip()) and pos + 1 < count:
			next_item = items[pos + 1]
			ret.append(item + ' ' + next_item)
			continue
		ret.append(item)
		pos = pos + 1
	return ret

def get_abs_path(relpath, source_root, file_info):
	path = file_info['path']
	name = file_info['name']

	if path == None:
		return os.path.abspath(relpath)

	if file_info.sourceTree == 'SOURCE_ROOT':
		abspath = source_root + '/' + path
	elif file_info.sourceTree == 'BUILT_PRODUCTS_DIR' or file_info.sourceTree == 'SDKROOT':
		abspath = '${%s}/%s' % (file_info.sourceTree, path)
		return abspath
	else:
		abspath = relpath + '/' + path
	return os.path.abspath(abspath)
	
def rename_project_files(project, relpath, group, entitys):
	group_path = get_abs_path(relpath, project._source_root, group)

	for child_id in group.children:
		child = project.get_object(child_id)

		if isinstance(child, project._get_class_reference('PBXGroup')):
			rename_project_files(project, group_path, child, entitys)
			pass
		elif isinstance(child, project._get_class_reference('PBXFileReference')):
			child_path = child['path']
			filepath = get_abs_path(group_path, project._source_root, child)
			rename_file_info(project, child, filepath, entitys)
			pass
		elif isinstance(child, project._get_class_reference('PBXVariantGroup')):
			renamed = False
			lastname = None
			for child_id in child.children:
				child_file = project.get_object(child_id)
				child_path = child_file['path']
				filepath = get_abs_path(group_path, project._source_root, child_file)
				if not hasattr(child_file, 'name'):
					print(child_file)
					continue
				renamed = rename_file_info(project, child_file, filepath, entitys)
				lastname = child_file['name']
			if renamed and len(child.children) == 1:
				child.name = lastname
			pass

	pass

def get_dat_file(package_dir):
	fs = os.listdir(package_dir)

	for f in fs:
		if os.path.splitext(f)[1] == '.dat':
			return '%s/%s' % (package_dir, f)
	return None

def get_project_info_by_name(profile, name):
	for project in profile['projects']:
		if project['name'] == name:
			return project
	return None

def append_once(arr, item):
	for v in arr:
		if v == item:
			return
	arr.append(item)

def get_product_file_by_target(project, target_object):
	productReference = target_object['productReference']
	fileRef = project.get_object(productReference)
	return fileRef['path']

def get_input_file_list(input_files, arch):
	if input_files == None:
		return None
	ret = []
	for input_file in input_files:
		if arch in input_file:
			ret.append(input_file[arch])
	return ret

def get_exclude_input_file_list(exclude_input_files, arch):
	if exclude_input_files == None:
		return None
	ret = []
	for exclude_input_file in exclude_input_files:
		if arch in exclude_input_file:
			ret.append(exclude_input_file[arch])
	return ret

def create_confuse_binary_script(workspace_file, package_dir, project_file, work_dir, bundle_id, main_bundle_id, target_name, archs, configure):
	script_dir = os.getenv('script_dir')
	project_name = confuse_utils.get_file_name(project_file)
	return 'python3 %s/create_confuse_binary_script.py \"%s\" \"%s\" \"%s\" \"%s\" \"%s\" \"%s\" \"%s\" \"%s\"' % (script_dir, workspace_file, project_file, work_dir, bundle_id, main_bundle_id, target_name, archs, configure)

def create_export_envs_and_create_confuse_script(workspace_file, package_dir, project_name, target_name, project_file, work_dir, bundle_id, main_bundle_id, archs, configure):
	cmd1 = create_export_envs_sh_script(work_dir, bundle_id, project_file, configure, target_name)
	cmd2 = create_confuse_binary_script(workspace_file, package_dir, project_file, work_dir, bundle_id, main_bundle_id, target_name, archs, configure)
	return '\n'.join([cmd1,cmd2])

def new_build_version():
	return datetime.datetime.now().strftime('%Y%m%d%H%m')


def create_preprocess_pod_resource_sh_script(work_dir, bundle_id, target_name, sh_file):
	script_dir = os.getenv('script_dir')
	#cmd1 = '\"%s/packages/%s/export_%s_envs.sh\"' % (work_dir, bundle_id, target_name)
	cmd2 =  'python3 %s/preprocess_pod_resource_sh.py \"%s\" \"%s\" \"%s\" %s' % (script_dir, work_dir, bundle_id, target_name, sh_file)
	#return '\n'.join([cmd1, cmd2])
	return cmd2
	
def create_export_envs_sh_script(work_dir, bundle_id, project_file, configure, target_name):
	sh_file_name = '%s/packages/%s/export_%s_envs.sh' % (work_dir, bundle_id, target_name)
	names = list(confuse_utils.get_build_settings(work_dir, bundle_id, project_file, configure, target_name).keys())
	package_dir = '%s/packages/%s' % (work_dir, bundle_id)
	file_name = '%s/%s_environment_variables.txt' % (package_dir, target_name)

	with open(sh_file_name, 'w') as f:
		f.write('TO_FILE_NAME=\"%s\"' % (confuse_utils.pstr(file_name)))
		for i in range(0, len(names)):
			cmd = ''
			name = names[i]
			if i == 0:
				cmd = '%s\n echo %s=${%s} > ${TO_FILE_NAME}' % (cmd, name, name)
			else:
				cmd = '%s\n echo %s=${%s} >> ${TO_FILE_NAME}' % (cmd, name, name)
			f.write(cmd)
		f.close()

	os.system('chmod 777 \"%s\"' % (sh_file_name))
	return '\"%s\"' % sh_file_name

def add_preprocess_pod_resource_script(work_dir, bundle_id, project_file, configure, target_name, project):
	rootObject = project.get_object(project.rootObject)
	for targetId in rootObject.targets:
			targetObject = project.get_object(targetId)
			if not isinstance(targetObject, project._get_class_reference('PBXNativeTarget')):
				continue
			if targetObject['name'] == target_name:
				for build_phase_id in targetObject.buildPhases:
					build_phase = project.get_object(build_phase_id)
					if not isinstance(build_phase, project._get_class_reference('PBXShellScriptBuildPhase')):
						continue
					shellScript = build_phase['shellScript']

					if hasattr(build_phase, 'name'):
						if build_phase['name'] == '[CP] Copy Pods Resources':
							#确认是pod资源拷贝版本
							build_phase['shellScript'] = '%s\n%s\nchmod 777 %s\n%s' % (create_export_envs_sh_script(work_dir, bundle_id, project_file, configure, target_name), create_preprocess_pod_resource_sh_script(work_dir, bundle_id, target_name, shellScript), shellScript, shellScript)
							return True
	return False

def get_scheme_list(project_file):
	ret = []
	b = os.popen('xcodebuild -project "%s" -list' % (project_file))
	jstxt = ''.join(b.readlines())
	print(jstxt)
	start = jstxt.rfind('Schemes:')
	if start == -1:
		return []
	scheme_str = jstxt[start + 9:]
	lines = scheme_str.split('\n')
	for line in lines:
		scheme = line.strip()
		if len(scheme):
			ret.append(scheme)
	return ret

abs_file_path = os.path.abspath(__file__)
script_dir = abs_file_path[0:abs_file_path.rfind('/')]

PRODUCT_TYPE_APPLICATION = 'com.apple.product-type.application'

PRODUCT_TYPE_APPEXTENSION = 'com.apple.product-type.app-extension'

def write_template_file(template_file_name, out_file_name, envs):
	lines = []
	with open(template_file_name, 'r') as fin:
		lines = fin.readlines()
		fin.close()

	with open(out_file_name, 'w') as fout:
		for line in lines:
			i = 0
			while i < len(line):
				start = line.find('####')
				if start == -1:
					break
				end = line.find('####', start + 4)
				if end == -1:
					break;
				name = line[start + 4:end]
				if name in envs:
					line = line[0:start] + envs[name] + line[end + 4:]
				else:
					line = line[0:start] + line[end + 4:]
			fout.write(line)
		fout.close()
	pass

def scheme_dir_is_exists(project_file):
		dirname = '%s/xcuserdata/%s.xcuserdatad/xcschemes' % (project_file, getpass.getuser())
		if os.path.exists(dirname):
			return True
		dirname = '%s/xcshareddata/%s.xcuserdatad/xcschemes' % (project_file, getpass.getuser())
		if os.path.exists(dirname):
			return True
		return False

def create_identifier(target_name):
	hash = hashlib.md5()
	hash.update(bytearray(target_name, 'utf-8'))
	return hash.hexdigest()[0:24].upper()

def create_scheme_file(project_file, target_name, mach_o_type):
	if mach_o_type == PRODUCT_TYPE_APPLICATION or mach_o_type == PRODUCT_TYPE_APPEXTENSION:
		resource_dir = '%s/..' % script_dir
		share_scheme_dir = '%s/xcshareddata/xcschemes/%s.xcscheme' % (resource_dir, target_name)
		if os.path.exists(share_scheme_dir):
			return
		print('create scheme file %s' % mach_o_type)
		envs = {}
		envs['TARGET_NAME'] = target_name
		envs['PROJECT_FILE'] = project_file
		envs['IDENTIFIER'] = create_identifier(target_name)
		plist_template_file = '%s/template/defapp.xcscheme' % resource_dir
		print('write template file %s' % plist_template_file)

		dirname = '%s/xcuserdata/%s.xcuserdatad/xcschemes' % (project_file, getpass.getuser())
		try:
			os.makedirs(dirname)
		except:
			pass
		out_file_name = '%s/%s.xcscheme' % (dirname, target_name)
		write_template_file(plist_template_file, out_file_name, envs)
	pass

def read_ccache_file(package_dir):
	return confuse_utils.read_settings_file(package_dir + '/ccache_configs.txt')

def check_confilict_source_files(workspace_dir, work_dir, bundle_id, project_file, entitys):
	rename_confilict_source_file = confuse_utils.get_run_settings_value(work_dir, bundle_id, 'rename-confilict-source-file', False)
	if not rename_confilict_source_file:
		return
	project_info = confuse_utils.load_workspace_profile(work_dir, bundle_id)
	projects = project_info['projects']
	for project in projects:
		if project['path'] != project_file:
			continue
		targets = project['targets']
		for target in targets:
			source_files = target['source-files']
			for source_file in source_files:
				for file_type in source_file.keys():
					files = source_file[file_type]
					for file in files:
						file_path = file['path']
						if 'alias-path' in file:
							new_file_path = file['alias-path']
							confuse_utils.back_file(workspace_dir, work_dir, bundle_id, file_path, False)
							if not os.path.exists(new_file_path) and os.path.exists(file_path):
								confuse_utils.rename_file(file_path, new_file_path)
								confuse_utils.add_temp_file(work_dir, bundle_id, new_file_path, False)
							entitys[file_path] = new_file_path
							#confuse_utils.add_file_rename(work_dir, bundle_id, file_path, file_path_alias, False)
	pass

def has_swift_file(project, target_object):
	buildPhases = target_object['buildPhases']
	for buildPhaseId in buildPhases:
		buildPhase = project.get_object(buildPhaseId)
		if isinstance(buildPhase, project._get_class_reference('PBXSourcesBuildPhase')):
			files = buildPhase['files']
			for fileId in files:
				phase_file = project.get_object(fileId)
				fileRefId = phase_file['fileRef']
				fileRef = project.get_object(fileRefId)
				last_known_file_type = None
				if hasattr(fileRef, 'lastKnownFileType'):
					last_known_file_type = fileRef.lastKnownFileType
				if hasattr(fileRef, 'explicitFileType'):
					last_known_file_type = fileRef.explicitFileType
				if last_known_file_type == 'sourcecode.swift':
					return True
	return False

workspace_profile = None

def load_workspace_profile(package_dir):
	global workspace_profile
	if workspace_profile == None:
		file = '%s/workspace.profile' % (package_dir)
		workspace_profile = json.load(open(file, 'r'))
	return workspace_profile

def get_project_info(project_file):
	projects = workspace_profile['projects']
	for project in projects:
		if project['path'] == project_file:
			return project
	return None

def join_str(settings, key):
	value = settings[key]
	if isinstance(value, list):
		return ' '.join(value)
	return value

def get_search_framework_paths(buildSettings, envs, cfgmap, target_name, config_name):
	key = 'FRAMEWORK_SEARCH_PATHS'
	if hasattr(buildSettings, key):
		tmp = {}
		tmp[key] = join_str(buildSettings, key)
		base_items = confuse_utils.get_build_settings_value(tmp, key, [], False)
	else:
		base_items = confuse_utils.get_build_settings_value(envs, key, [], True)
	copy_list(cfgmap, target_name, config_name, base_items)

def get_search_library_paths(buildSettings, envs, cfgmap, target_name, config_name):
	key = 'LIBRARY_SEARCH_PATHS'
	if hasattr(buildSettings, key):
		tmp = {}
		tmp[key] = join_str(buildSettings, key)
		base_items = confuse_utils.get_build_settings_value(tmp, key, [], False)
		buildSettings[key] = base_items
	else:
		base_items = confuse_utils.get_build_settings_value(envs, key, [], True)
	copy_list(cfgmap, target_name, config_name, base_items)

def get_header_search_paths(buildSettings, envs, cfgmap, target_name, config_name):
	key = 'HEADER_SEARCH_PATHS'
	if hasattr(buildSettings, key):
		tmp = {}
		tmp[key] = join_str(buildSettings, key)
		base_items = confuse_utils.get_build_settings_value(tmp, key, [], False)
		buildSettings[key] = base_items
	else:
		base_items = confuse_utils.get_build_settings_value(envs, key, [], True)
	copy_list(cfgmap, target_name, config_name, base_items)

def get_other_ldflags(buildSettings, envs, cfgmap, target_name, config_name):
	key = 'OTHER_LDFLAGS'
	if hasattr(buildSettings, key):
		tmp = {}
		tmp[key] = join_str(buildSettings, key)
		base_items = confuse_utils.get_build_settings_value(tmp, key, [], False)
		buildSettings[key] = base_items
	else:
		base_items = confuse_utils.get_build_settings_value(envs, key, [], False)
	copy_list(cfgmap, target_name, config_name, base_items)

def get_other_cflags(buildSettings, envs, cfgmap, target_name, config_name):
	key = 'OTHER_CFLAGS'
	if hasattr(buildSettings, key):
		tmp = {}
		tmp[key] = join_str(buildSettings, key)
		base_items = confuse_utils.get_build_settings_value(tmp, key, [], False)
		buildSettings[key] = base_items
	else:
		base_items = confuse_utils.get_build_settings_value(envs, key, [], False)
	copy_list(cfgmap, target_name, config_name, base_items)

def add_framework_search_paths(project, cfgmap, target_name, config_name):
	if target_name not in cfgmap.keys():
		return
	items = cfgmap[target_name][config_name]
	project.add_framework_search_paths(join_items(items), recursive=False, configuration_name=config_name, target_name=target_name)

def add_library_search_paths(project, cfgmap, target_name, config_name):
	if target_name not in cfgmap.keys():
		return
	target_obj = cfgmap[target_name]
	if config_name not in target_obj.keys():
		return
	items = target_obj[config_name]
	project.add_library_search_paths(join_items(items), recursive=False, configuration_name=config_name, target_name=target_name)

def add_header_search_paths(project, cfgmap, target_name, config_name):
	if target_name not in cfgmap.keys():
		return
	target_obj = cfgmap[target_name]
	if config_name not in target_obj.keys():
		return
	items = target_obj[config_name]
	project.add_header_search_paths(join_items(items), recursive=False, configuration_name=config_name, target_name=target_name)

def add_other_cflags(project, cfgmap, target_name, config_name):
	if target_name not in cfgmap.keys():
		return
	target_obj = cfgmap[target_name]
	if config_name not in target_obj.keys():
		return
	items = target_obj[config_name]
	project.add_other_cflags(join_items(items), configuration_name=config_name, target_name=target_name)

def add_other_ldflags(project, cfgmap, target_name, config_name):
	if target_name not in cfgmap.keys():
		return
	target_obj = cfgmap[target_name]
	if config_name not in target_obj.keys():
		return
	items = target_obj[config_name]
	project.add_other_ldflags(join_items(items), configuration_name=config_name, target_name=target_name)


def save_project_file(workspace_file, project_file, work_dir, target_name, bundle_identifer, main_bundle_id, archs, configure, bundle_version, build_version):
	pbxprojfile = '%s/project.pbxproj' % project_file
	global bundle_id
	global embed_swift
	global disable_rename_main_target
	global keep_symbs
	global use_dyn_cosdk
	workspace_dir = workspace_file[0:workspace_file.rfind('/')]

	bundle_id = bundle_identifer

	scheme_list = get_scheme_list(project_file)

	print('save project file %s target name %s' % (project_file, target_name))
	backname = '%s.back' % pbxprojfile
	print('schemes:%s' % scheme_list)
	keep_symbs = confuse_utils.get_run_settings_value(work_dir, bundle_id, 'keep-symbs', False)

	embed_swift = confuse_utils.get_run_settings_value(work_dir, bundle_id, 'embed-swift', False)

	disable_rename_main_target = confuse_utils.get_run_settings_value(work_dir, bundle_id, 'disable-rename-main-target', False)

	use_dyn_cosdk = confuse_utils.get_run_settings_value(work_dir, bundle_id, 'use-dyn-cosdk', False)

	cosdk_name = confuse_utils.get_run_settings_value(work_dir, bundle_id, 'cosdk-name', 'COSDK')

	has_backup = False
	if os.path.exists(backname):
		print('load %s ...' % (backname))
		project = XcodeProject.load(backname)
		has_backup = True
	else:
		print('load %s ...' % (pbxprojfile))
		project = XcodeProject.load(pbxprojfile)

	package_dir = '%s/packages/%s' % (work_dir, bundle_id)
	old_cat_dat = get_dat_file(package_dir)

	load_workspace_profile(package_dir)
	project_info = get_project_info(project_file)
	xcconfigs = project_info['xcconfigs']
	print('xcconfigs:%s' % xcconfigs)

	entitys = confuse_utils.get_file_rename_map(work_dir, bundle_id)
	check_confilict_source_files(workspace_dir, work_dir, bundle_id, project_file, entitys)
	
	rootObject = project.get_object(project.rootObject)
	mainGroupId = rootObject.mainGroup
	mainGroup = project.get_object(mainGroupId)
	rename_project_files(project, project._source_root, mainGroup, entitys)

	depend_files = confuse_utils.read_settings_file(package_dir + '/depend_files.txt')

	depend_frameworks = read_ccache_file(package_dir)
	cosdk_items = []

	if 'cosdk' in depend_files:
		cosdk_items = depend_files['cosdk']

	cosdk_framework_path = ''
	cosdk_dat_path = ''

	cosdk_framework_name = '%s.framework/%s' % (cosdk_name, cosdk_name)
	for item in cosdk_items:
		if item.endswith(cosdk_framework_name):
			item = item[:-(len(cosdk_framework_name) + 1)]
			if len(item):
				cosdk_framework_path = '%s/%s' % (workspace_dir, item.replace('{..}/', '../'))
			else:
				cosdk_framework_path = '%s' % (workspace_dir)
		elif item.endswith('.dat'):
			cosdk_dat_path = '%s/%s' % (workspace_dir, item.replace('{..}/', '../'))

	#print cosdk_framework_path
	if os.path.exists(cosdk_framework_path) == False:
		print('not found COSDK.framework/COSDK file in %s' % cosdk_framework_path)

	if os.path.exists(cosdk_dat_path) == False:
		print('not found COSDK(*.dat) file in %s' % cosdk_dat_path)
	
	framework_search_paths = ['\"%s\"' % confuse_utils.pstr(cosdk_framework_path)]
	if embed_swift and disable_rename_main_target == False:
		framework_search_paths.append(confuse_utils.get_swift_bridge_headers_dir(work_dir, bundle_id, None, None))
	
	debug_other_cflags = ['-DNSCOSDK_DEBUG=1']
	release_other_cflags = ['-DNSCOSDK_DEBUG=0']

	ld_flags = ['-framework %s' % cosdk_name]

	#if embed_swift == True:
	#	ld_flags.append('-iquote\"%s\"' % confuse_utils.get_swift_bridge_headers_dir(work_dir, bundle_id, project_file, target_name))
	
	replace_main = False
	if confuse_utils.get_run_settings_value(work_dir, bundle_id, 'replace-main', False):
		replace_main = True
	temp_archive_dir = '%s/temp-archive-dir' % package_dir

	library_search_paths = ['\"%s\"' % confuse_utils.pstr(temp_archive_dir)]

	if replace_main:
		ld_flags.append('-lCOSDK_main')
	#has_swift = has_swift_file(project)
	#if has_swift:
	#	ld_flags.append('-lCOSDK_swift')
	
	info_plist_items = []
	if '*.plist' in depend_files:
		info_plist_items = depend_files['*.plist']

	info_plist_file = None
	if len(info_plist_items):
		info_plist_file = workspace_dir + '/' + info_plist_items[0].replace('{..}/', '../')
	
	header_search_paths = []
	
	new_target_name = target_name
	is_main_project = False
	ccache_enable = False

	ccahce_configs = confuse_utils.read_settings_file('%s/ccache_configs.txt' % (package_dir))

	if confuse_utils.get_run_settings_value(work_dir, bundle_id, 'ccache', False):
		ccache_enable = True

	link_type = confuse_utils.get_run_settings_value(work_dir, bundle_id, 'link-type', 'main-target')

	add_cpp_lib = True
	add_run_script = True

	map_framework_search_paths = {}
	map_library_search_paths = {}
	map_other_ldflags = {}
	map_other_cflags = {}
	map_header_search_paths = {}

	for targetId in rootObject.targets:
		targetObject = project.get_object(targetId)
		if not isinstance(targetObject, project._get_class_reference('PBXNativeTarget')):
			continue
		targetName = targetObject['name']
		product_type = targetObject['productType']

		#添加用户定义的依赖
		if targetName in depend_frameworks:
			depend_items = depend_frameworks[targetName]
			for depend_item in depend_items:
				if depend_item.endswith('.framework'):
					print('😊 %s System/Library/Frameworks/%s' % (targetName, depend_item))
					project.add_framework(targetName, 'System/Library/Frameworks/%s' % depend_item)
				else:
					print('😊 %s usr/lib/%s' % (targeetName, depend_item))
					project.add_framework(targetName, 'usr/lib/%s' % (depend_item))

		#有swift文件才需要这个
		if has_swift_file(project, targetObject):
			ld_flags.append('-lCOSDK_swift')
			has_swift = True

		is_main_target = False
		is_main_project = False
		if targetName == target_name:
			is_main_target = True
			is_main_project = True

		if targetName not in scheme_list:
			create_scheme_file(project_file, targetName, product_type)
		elif scheme_dir_is_exists(project_file) == False:
			create_scheme_file(project_file, targetName, product_type)

		buildConfigurationList = project.get_object(targetObject['buildConfigurationList'])
		for buildConfigurationId in buildConfigurationList['buildConfigurations']:
			buildConfiguration = project.get_object(buildConfigurationId)
			buildSettings =  buildConfiguration['buildSettings']
			config_name = buildConfiguration['name']
			baseConfigurationReference = buildConfiguration['baseConfigurationReference']
			#if hasattr(buildSettings, 'baseConfigurationReference'):
			#	if baseConfigurationReference in xcconfigs.keys():
			xcconfig_key = '%s.%s' % (targetName, config_name)
			if xcconfig_key in xcconfigs.keys():
				xcconfig_filepath = xcconfigs[xcconfig_key] 
				xcconfig_settongs = {}
				confuse_utils.load_xcconfig_file(xcconfig_filepath, xcconfig_settongs)
				#print('😄:%s' % xcconfig_settongs)
				get_search_framework_paths(buildSettings, xcconfig_settongs, map_framework_search_paths, targetName, config_name)
				get_search_library_paths(buildSettings, xcconfig_settongs, map_library_search_paths, targetName, config_name)
				get_other_ldflags(buildSettings, xcconfig_settongs, map_other_ldflags, targetName, config_name)
				get_other_cflags(buildSettings, xcconfig_settongs, map_other_cflags, targetName, config_name)
				get_header_search_paths(buildSettings, xcconfig_settongs, map_header_search_paths, targetName, config_name)
				#loadxcconfigfile()
			else:
				print('⚠️ not found %s in %s.' % (xcconfig_key, targetName))

			product_bundle_id =  buildSettings['PRODUCT_BUNDLE_IDENTIFIER']
			#is_main_target = False

			if is_main_target and info_plist_file != None:
				buildSettings['INFOPLIST_FILE'] = info_plist_file
				#buildSettings['LD_GENERATE_MAP_FILE'] = 'YES'
			if is_main_target or use_dyn_cosdk:
				if add_cpp_lib:
					add_cpp_lib = False
					project.add_framework(targetName, 'usr/lib/%s' % ('libc++.tbd'))
			
			if ccache_enable or link_type == 'custom':
				#if targetName in ccahce_configs:
				#	linkOptions = ccahce_configs[targetName]
				#	for linkOption in linkOptions:
				#		if linkOption.endswith('framework'):
				#			project.add_framework(targetName, 'System/Library/Frameworks/%s' % linkOption)
				#		else:
				#			project.add_framework(targetName, 'usr/lib/%s' % (linkOption))
				#		pass
				#	pass
				if ccache_enable:
					if not hasattr(buildSettings, 'CC'):
						buildSettings['CC'] = '%s/ccache-clang' % (exe_dir)
					if not hasattr(buildSettings, 'CXX'):
						buildSettings['CXX'] = '%s/ccache-clang++' % (exe_dir)
					buildSettings['CLANG_ENABLE_MODULES'] = 'NO'
			else:
				if hasattr(buildSettings, 'CC'):
					delattr(buildSettings, 'CC')
				if hasattr(buildSettings, 'CXX'):
					delattr(buildSettings, 'CXX')
				if buildSettings['CLANG_ENABLE_MODULES'] == 'NO':
					buildSettings['CLANG_ENABLE_MODULES'] = 'YES'

			buildSettings['ENABLE_BITCODE'] = 'NO'
			buildSettings['ASSETCATALOG_COMPILER_GENERATE_ASSET_SYMBOLS'] = 'NO'

			if keep_symbs:
				buildSettings['DEPLOYMENT_POSTPROCESSING'] = 'YES'
				buildSettings['STRIP_INSTALLED_PRODUCT'] = 'NO'
			
			if embed_swift:
				if not disable_rename_main_target:
					target_swift_bridge_file = confuse_utils.get_swift_bridge_headers_dir(work_dir, bundle_id, project_file, target_name)
					header_search_paths.append(target_swift_bridge_file)
			#if is_main_target:
			#	if configure == 'Debug':
			#		buildSettings['DEBUG_INFORMATION_FORMAT'] = 'dwarf'
			#	else:
			#		buildSettings['DEBUG_INFORMATION_FORMAT'] = 'dwarf-with-dsym'
					
			mobile_provision_info,config_bundle_id,identity = confuse_utils.get_mobile_provision_file_info(work_dir, bundle_id, configure, product_bundle_id, targetName)
			if mobile_provision_info != None:
				mobile_provision_uuid = mobile_provision_info['UUID']
				team_id = mobile_provision_info['TEAM_ID']
				if is_main_target:
					if len(bundle_version):
						buildSettings['MARKETING_VERSION'] = bundle_version
					if len(build_version):
						buildSettings['CURRENT_PROJECT_VERSION'] =  build_version
				buildSettings['CODE_SIGN_STYLE'] = 'Manual'
				buildSettings['DEVELOPMENT_TEAM'] = team_id
				if hasattr(buildSettings, 'DEVELOPMENT_TEAM[sdk=iphoneos*]'):
					buildSettings['DEVELOPMENT_TEAM[sdk=iphoneos*]'] = team_id
				code_sign_identity = mobile_provision_info['CODE_SIGN_IDENTITY']
				if hasattr(buildSettings, 'CODE_SIGN_IDENTITY[sdk=iphoneos*]'):
					buildSettings['CODE_SIGN_IDENTITY[sdk=iphoneos*]'] = code_sign_identity
				buildSettings['CODE_SIGN_IDENTITY'] = code_sign_identity
				if configure == 'Debug':
					if identity == None:
						buildSettings['CODE_SIGN_IDENTITY[sdk=iphoneos*]'] = 'iPhone Developer'
					else:
						buildSettings['CODE_SIGN_IDENTITY[sdk=iphoneos*]'] = identity
				else:
					if identity == None:
						buildSettings['CODE_SIGN_IDENTITY[sdk=iphoneos*]'] = 'iPhone Distribution'
					else:
						buildSettings['CODE_SIGN_IDENTITY[sdk=iphoneos*]'] = identity
				if product_type != PRODUCT_TYPE_FRAMEWORK:
					buildSettings['PROVISIONING_PROFILE_SPECIFIER'] = mobile_provision_uuid
					if hasattr(buildSettings, 'PROVISIONING_PROFILE_SPECIFIER[sdk=iphoneos*]'):
						buildSettings['PROVISIONING_PROFILE_SPECIFIER[sdk=iphoneos*]'] = mobile_provision_uuid

				cur_bundle_id = mobile_provision_info['BUNDLE_ID']
				if is_main_target:
					if cur_bundle_id != bundle_id:
						print(cur_bundle_id)
						print('mobile profile file %s error.' % (mobile_provision_info['FILE_NAME']))
						sys.exit(1)
				buildSettings['PRODUCT_BUNDLE_IDENTIFIER'] = cur_bundle_id
				if is_main_target:
					if disable_rename_main_target:
						new_target_name = targetName
					else:
						new_target_name = confuse_utils.get_symbol_new_name(work_dir, bundle_id, targetName, 'target', False)
						if new_target_name == targetName:
							new_target_name = confuse_utils.new_symbol_name(work_dir, bundle_id, targetName, 'target')
						if hasattr(buildSettings, 'PRODUCT_MODULE_NAME'):
							buildSettings['PRODUCT_MODULE_NAME'] = confuse_utils.new_constant_value(work_dir, bundle_id, targetName, 'swiftmodule', confuse_utils.format_product_name(new_target_name))
						old_product_name = buildSettings['PRODUCT_NAME']
						confuse_utils.set_bundle_config_value(work_dir, bundle_id, 'PRODUCT_NAME', old_product_name)
						buildSettings['PRODUCT_NAME'] = new_target_name
					buildSettings['ENABLE_USER_SCRIPT_SANDBOXING'] = 'NO'
			elif config_bundle_id != None:
				buildSettings['PRODUCT_BUNDLE_IDENTIFIER'] = config_bundle_id
			elif is_main_target == True:
				print('not found sign key config by %s(%s)' % (configure, targetName))
				sys.exit(1)
			

		#if old_cat_dat_exists == False and os.path.exists(old_cat_dat_path):
		#	project.add_file(old_cat_dat_path)
		if is_main_project and add_run_script:
			add_run_script = False
			project_name = confuse_utils.get_file_name(project_file)
			#add_aggregate_target(project_file, work_dir, bundle_id, target_name, new_target_name, project, package_dir)
			if add_preprocess_pod_resource_script(work_dir, bundle_id, project_file, configure, target_name, project):
				project.add_run_script(create_confuse_binary_script(workspace_file, package_dir, project_file, work_dir, bundle_id, main_bundle_id, target_name, archs, configure), target_name)
			else:
				project.add_run_script(create_export_envs_and_create_confuse_script(workspace_file, package_dir, project_name, target_name, project_file, work_dir, bundle_id, main_bundle_id, archs, configure), target_name)


	for targetId in rootObject.targets:
		targetObject = project.get_object(targetId)
		if not isinstance(targetObject, project._get_class_reference('PBXNativeTarget')):
			continue
		targetName = targetObject['name']

		buildConfigurationList = project.get_object(targetObject['buildConfigurationList'])
		for buildConfigurationId in buildConfigurationList['buildConfigurations']:
			buildConfiguration = project.get_object(buildConfigurationId)
			config_name = buildConfiguration['name']
			#if targetName == 'RxRelay':
			#	print('😁😁😁(target:%s):%s' %(targetName, framework_search_paths[targetName][config_name]))
			copy_list(map_framework_search_paths, targetName, config_name, framework_search_paths)
			copy_list(map_library_search_paths, targetName, config_name, library_search_paths)
			copy_list(map_header_search_paths, targetName, config_name, header_search_paths)
			if config_name == 'Debug':
				copy_list(map_other_cflags, targetName, config_name, debug_other_cflags)
			elif config_name == 'Release':
				copy_list(map_other_cflags, targetName, config_name, release_other_cflags)
			copy_list(map_other_ldflags, targetName, config_name, ld_flags)
			add_framework_search_paths(project, map_framework_search_paths, targetName, config_name)
			add_library_search_paths(project, map_library_search_paths, targetName, config_name)
			add_header_search_paths(project, map_header_search_paths, targetName, config_name)
			add_other_cflags(project, map_other_cflags, targetName, config_name)
			add_other_ldflags(project, map_other_ldflags, targetName, config_name)
			#project.add_header_search_paths(map_header_search_paths[targetName][config_name], configuration_name=config_name, target_name=targetName)
	
	#备份一下
	if has_backup == False:
		confuse_utils.add_backup_file(work_dir, bundle_id, pbxprojfile, backname)
		shutil.copy2(pbxprojfile, backname)
	project.save(pbxprojfile)
	print('save project file %s finish' % project_file)
	##sys.exit(1)
	pass

# cd /Users/crab/Documents/myprojects/iOS-artifact/resource/projectmanager/other/script
# python save_project_file.py /Users/crab/Documents/swapshell/samplecode/objc_sample_code /Users/crab/Documents/swapshell/samplecode/objc_sample_code/SampleCode.xcodeproj /Users/crab/Library/ipa-artifact SampleCode com.zuimeiqidai.my.samplecode

def main(argv):
	confuse_utils.print_cmd(argv)
	if len(argv) != 11:
		print('python save_project_file.py [workspace file] [project file] [work dir] [target name] [bundle id] [main bundle id] [archs] [Debug/Release] [bundle version] [build version]')
		sys.exit(1)
	save_project_file(argv[1], argv[2], argv[3], argv[4], argv[5], argv[6], argv[7], argv[8], argv[9],argv[10])
main(sys.argv)
