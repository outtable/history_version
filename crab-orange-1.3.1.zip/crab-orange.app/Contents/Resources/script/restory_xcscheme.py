#!/usr/bin/python
# -*- coding: UTF-8 -*-

import sys
import os

def back_xcscheme(work_dir, bundle_id, project_file, target_name):
	print('##back xcscheme##')
	pass

def main(argv):
	if len(argv) != 4:
		print('python back_xcscheme.py [work dir] [bundle id] [project file]')
		return
	back_xcscheme(argv[1], argv[2], argv[3])

main(sys.argv)