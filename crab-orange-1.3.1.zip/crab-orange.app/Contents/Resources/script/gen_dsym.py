#!/usr/bin/python
# -*- coding: UTF-8 -*-

import sys
import os
import confuse_utils
import shutil

abs_file_path = os.path.abspath(__file__)
exe_dir = abs_file_path[0:abs_file_path.rfind('/')]

def gen_dsym(work_dir, bundle_id, main_project_file, target_name, configure, project_file, product_type, product_target_name):
	print('##gen dsym %s##' % (product_target_name))
	app_build_settings = confuse_utils.get_build_settings(work_dir, bundle_id, main_project_file, configure, target_name, use_cache_file=True)
	app_product_file = confuse_utils.get_build_settings_value(app_build_settings, 'FULL_PRODUCT_NAME', '')
	app_product_name = confuse_utils.get_build_settings_value(app_build_settings, 'PRODUCT_NAME', '')
	build_settings = confuse_utils.get_build_settings(work_dir, bundle_id, project_file, configure, product_target_name, use_cache_file=True)
	product_file = confuse_utils.get_build_settings_value(build_settings, 'FULL_PRODUCT_NAME', '')
	product_name = confuse_utils.get_build_settings_value(build_settings, 'PRODUCT_NAME', '')
	strip_linkd_product = confuse_utils.get_build_settings_value(build_settings, 'STRIP_INSTALLED_PRODUCT', 'YES')
	strip_style = confuse_utils.get_build_settings_value(build_settings, 'STRIP_STYLE', '')
	#strip_swift = confuse_utils.get_build_settings_value(build_settings, 'STRIP_SWIFT_SYMBOLS', 'YES')
	package_dir = '%s/packages/%s' % (work_dir, bundle_id)
	file_name = '%s/compile_configs.txt' % (package_dir)
	archive_path = '%s/%s.xcarchive' % (package_dir, target_name)
	file_name = '%s/%s_environment_variables.txt' % (package_dir, target_name)
	envs = confuse_utils.read_properties_file(file_name)

	archive_path = '%s/%s.xcarchive' % (package_dir, target_name)
	keep_symbs_dir = '%s/Products-no-strip/Payload' % archive_path
	full_product_file_path = ''
	dsym_file_name = '%s/dSYMs/%s.dSYM' % (archive_path, product_file)
	if product_type == '.app':
		full_product_file_path = '%s/Products/Applications/%s' % (archive_path, app_product_file)
		binary_file = '%s/%s' % (full_product_file_path, product_name)
	elif product_type == '.appex':
		keep_symbs_dir = '%s/%s/PlugIns' % (keep_symbs_dir, app_product_file)
		full_product_file_path = '%s/Products/Applications/%s/PlugIns/%s' % (archive_path, app_product_file, product_file)
		binary_file = '%s/%s' % (full_product_file_path, product_name)
	elif product_type == '.framework':
		keep_symbs_dir = '%s/%s/Frameworks' % (keep_symbs_dir, app_product_file)
		full_product_file_path = '%s/Products/Applications/%s/Frameworks/%s' % (archive_path, app_product_file, product_file)
		binary_file = '%s/%s' % (full_product_file_path, product_name)
	back_binary_file = '%s.back/%s.binary.back' % (archive_path, confuse_utils.md5str(binary_file))
    
	if os.path.exists(back_binary_file):
		os.remove(binary_file)
		os.rename(back_binary_file, binary_file)
	shutil.copyfile(binary_file, back_binary_file)
    
	back_dsym_file_name = '%s.back/dSYMs/%s.dSYM' % (archive_path, product_file)
	dbfile = '%s/symbols.db' % work_dir

	cmds = []
	cmds.append('rm -rf \"%s\"' % back_dsym_file_name)
	cmds.append('${TOOLCHAIN_DIR}/usr/bin/dsymutil \"%s\" -o \"%s\"' % (binary_file, dsym_file_name))
	cmds.append('cp -r \"%s\" \"%s\"' % (dsym_file_name, back_dsym_file_name))

	keep_symbs = confuse_utils.get_run_settings_value(work_dir, bundle_id, 'keep-symbs', False)
	keep_dsym_binary_backup = confuse_utils.get_run_settings_value(work_dir, bundle_id, 'keep-dsym-binary-backup', False)
	dsym_recover = confuse_utils.get_run_settings_value(work_dir, bundle_id, 'dsym-recover', False)

	if keep_dsym_binary_backup == False:
		backup_dsym_binary_file = 'false'
	else:
		backup_dsym_binary_file = 'true'

	if keep_symbs:
		cmds.append('mkdir -p \"%s\"' % keep_symbs_dir)
		cmds.append('cp -rf \"%s\" \"%s\"' % (full_product_file_path, keep_symbs_dir))
	
	strip_flags = ''
	if strip_linkd_product == 'YES':
		if strip_style == 'non-global':
			strip_flags = '-x'
		#elif strip_style == 'all':
		#	strip_flags = '-s'
		elif strip_style == 'debugging':
			strip_flags = '-S'
	else:
		if product_type != '.app':
			strip_flags = '-S'
	#if strip_swift == 'YES':
	#	strip_flags = '%s -T' % strip_flags
	cmds.append('${TOOLCHAIN_DIR}/usr/bin/strip -D %s \"%s\"' % (strip_flags, binary_file))
	
	#需要恢复DSYM文件
	if dsym_recover:
		cmds.append('%s/dsym-rewriter \"--listen-file=%s/%s.listenkey\" --bundle-id=\"%s\" --dbfile=\"%s\" --input-dsym=\"%s\" --output-dsym=\"%s\" --recover-symbols --backup-binary=\"%s\" --binary-file=\"%s\"' % (exe_dir, package_dir, bundle_id, bundle_id, dbfile, dsym_file_name, back_dsym_file_name, backup_dsym_binary_file, product_name))
		cmds.append('mv \"%s\" \"%s.move\"' % (back_dsym_file_name, dsym_file_name))
		cmds.append('mv \"%s\" \"%s\"' % (dsym_file_name, back_dsym_file_name))
		cmds.append('mv \"%s.move\" \"%s\"' % (dsym_file_name, dsym_file_name))
	
	for cmd in cmds:
		cmd_txt = confuse_utils.replace_text_vars(envs, cmd)
		ret = confuse_utils.exec_cmd(cmd_txt)
		if ret != 0:
			sys.exit(ret)
	pass

def main(argv):
	confuse_utils.print_cmd(argv)
	if len(argv) != 9:
		print('python gen_dsym.py [work dir] [bundle id]  [main poject file] [target name]  [Debug/Release] [project file] [product type] [product target name]')
		sys.exit(1)
	gen_dsym(argv[1], argv[2], argv[3], argv[4], argv[5], argv[6], argv[7], argv[8])

main(sys.argv)
