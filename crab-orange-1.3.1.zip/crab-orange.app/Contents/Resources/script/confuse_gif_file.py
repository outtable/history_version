#!/usr/bin/python
# -*- coding: UTF-8 -*-

import sys
import os
import confuse_utils
import image_utils
import importlib
from PIL import Image

importlib.reload(sys)
#sys.setdefaultencoding('utf8')

def confuse_gif(work_dir, bundle_id, main_project_file, target_name, configure, product_type, product_file, install_dir, project_file, product_target_name, src_file, ref_folder):
	print('##confuse gif file %s##' % src_file)
	confuse_utils.dbfile_lock()
	src_file = confuse_utils.get_file_rename(work_dir, bundle_id, src_file)
	confuse_utils.dbfile_unlock()
	package_dir = '%s/packages/%s' % (work_dir, bundle_id)
	if not os.path.exists(src_file):
		print('warning:not found %s' % src_file)
		return
	try:
		src_file_back = src_file + '.back' 
		os.link(src_file, src_file_back)
		src_img = Image.open(src_file)
		imgs = []
		iter = ImageSequence.Iterator(src_img)
		for frame in iter:
			rgb_img = frame.convert('RGB')
			image_utils.encode_key_to_image(rgb_img, bundle_id)
			imgs.append(rgb_img)
		src_img.close()
		os.remove(src_file)
		imgs[0].save(src_file, save_all=True, append_images=imgs[1:])
		os.remove(src_file_back)
	except:
		os.rename(src_file_back, src_file)
		print('warning:ios error in %s' % (src_file))
	pass

def main(argv):
	confuse_utils.print_cmd(argv)
	if len(argv) != 13:
		print('python confuse_gif.py [work dir] [bundle id] [main project file] [target name] [configure] [product type] [product file] [install dir] [project file] [product target name] [src file] [ref folder]')
		return
	confuse_gif(argv[1], argv[2], argv[3], argv[4], argv[5], argv[6], argv[7], argv[8], argv[9], argv[10], argv[11], argv[12])
	
main(sys.argv)