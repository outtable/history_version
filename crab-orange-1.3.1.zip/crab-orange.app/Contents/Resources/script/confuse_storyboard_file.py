#!/usr/bin/python
# -*- coding: UTF-8 -*-

import sys
from xml.dom.minidom import parse
import xml.dom.minidom
import random
import re
import confuse_utils
import os
import shutil
import importlib

importlib.reload(sys)

default_module = ''
confuse_xib_string = False
#sys.setdefaultencoding('utf-8')

TAG_OJBC_INTERFACE = 'objcinterface'
TAG_SWIFT_RECORD = 'swiftrecord'
TAG_OBJC_METHOD = 'objcmethod'
TAG_OBJC_PROPERTY = 'objcproperty'

def get_key(tag, name):
	k = '%s<%s>' % (name, tag)
	return k

def get_customClass_by_id(node, id, defname):
	if  node.nodeType == xml.dom.Node.ELEMENT_NODE:
		if node.hasAttribute('id'):
			if node.getAttribute('id') == id:
				return node.getAttribute('customClass')

	if node.parentNode != None:
		customClass =  get_customClass_by_id(node.parentNode, id, defname)

		if customClass != defname:
			return customClass
	return defname


def change_class(node, idmap, customclass):
	if node.nodeType == xml.dom.Node.ELEMENT_NODE:
		if node.hasAttribute('customClass'):
			customclass = node.getAttribute('customClass')
			key = get_key(TAG_OJBC_INTERFACE, customclass)
			if key in idmap:
				newcustomclass = idmap[key]
				node.setAttribute('customClass', newcustomclass)
				print('rename customClass \'%s\' to \'%s\'' % (customclass, newcustomclass))
			else:
				key = get_key(TAG_SWIFT_RECORD, '%s.%s' % (default_module, customclass))
				if key in idmap:
					newcustomclass = idmap[key]
					newcustomclass = newcustomclass[newcustomclass.rfind('.') + 1:]
					node.setAttribute('customClass', newcustomclass)
					print('rename customClass \'%s\' to \'%s\'' % (customclass, newcustomclass))

	for child in node.childNodes:
		change_class(child, idmap, customclass)
	pass

def change_other(node, idmap, customclass):
	if node.nodeType == xml.dom.Node.ELEMENT_NODE:
		if node.hasAttribute('image'):
			imagename = node.getAttribute('image')
			key = get_key('image', imagename)
			if key in idmap:
				newimagename = idmap[key]
				print('rename image attribute \'%s\' to \'%s\'' % (imagename, newimagename))
				node.setAttribute('image', newimagename)
		if node.hasAttribute('backgroundImage'):
			imagename = node.getAttribute('backgroundImage')
			key = get_key('image', imagename)
			if key in idmap:
				newimagename = idmap[key]
				print('rename backgroundImage attribute \'%s\' to \'%s\'' % (imagename, newimagename))
				node.setAttribute('backgroundImage', newimagename)

		if node.nodeType == xml.dom.Node.ELEMENT_NODE:
			if node.hasAttribute('customClass'):
				customclass = node.getAttribute('customClass')
				#key = get_key(['class'], customclass)
				#if idmap.has_key(key):
					#newcustomclass = idmap[key]
					#node.setAttribute('customClass', newcustomclass)
					#print 'rename customClass \'%s\' to \'%s\'' % (customclass, newcustomclass)

		if node.hasAttribute('selector'):
			selector = node.getAttribute('selector')
			destination = node.getAttribute('destination')
			key = get_key(TAG_OBJC_METHOD, selector)
			print('find selector %s' % key)
			if key in idmap:
				newselector = idmap[key]
				node.setAttribute('selector', newselector)
				print('rename selector \'%s\' to \'%s\'' % (selector, newselector))
				
		if node.nodeName == 'outlet' or node.nodeName == 'outletCollection':
			if node.hasAttribute('property'):
				prop = node.getAttribute('property')
				destination = node.getAttribute('destination')
				key = get_key(TAG_OBJC_PROPERTY, prop)
				print('find outlet %s' % key)
				if key in idmap:
					newprop = idmap[key]
					node.setAttribute('property', newprop)
					print('rename outlet property \'%s\' to \'%s\'' % (prop, newprop))

		if node.nodeName == 'image':
			if node.hasAttribute('name'):
				name = node.getAttribute('name')
				key = get_key('image', name)
				if key in idmap:
					newname = idmap[key]
					node.setAttribute('name', newname)
					print('rename image name \'%s\' to \'%s\'' % (name, newname))

		if confuse_xib_string:
			if node.nodeName == 'label':
				if node.hasAttribute('text'):
					text = node.getAttribute('text')
					node.setAttribute('text', confuse_utils.encode_string(text))
					print('加密字符串 %s' % text)
			if node.nodeName == 'buttonConfiguration':
				if node.hasAttribute('title'):
					text = node.getAttribute('title')
					node.setAttribute('title', confuse_utils.encode_string(text))
					print('加密字符串 %s' % text)
			if node.nodeName == 'state' and node.parentNode.nodeName == 'button':
				if node.hasAttribute('title'):
					text = node.getAttribute('title')
					node.setAttribute('title', confuse_utils.encode_string(text))
					print('加密字符串 %s' % text)
		
		if node.nodeName == 'userDefinedRuntimeAttribute':
			if node.hasAttribute('keyPath'):
				keyPath = node.getAttribute('keyPath')
				pairs = keyPath.split('.')
				newKeyPath = ''
				for i in range(0, len(pairs)):
					if i != 0:
						newKeyPath = newKeyPath + ','
					key = get_key(TAG_OBJC_PROPERTY, pairs[i])
					if key in idmap:
						newname = idmap[key]
						newKeyPath = newKeyPath + newname
					else:
						newKeyPath = newKeyPath + pairs[i]
				if newKeyPath != keyPath:
					node.setAttribute('keyPath', newKeyPath)
					print('rename keyPath \'%s\' to \'%s\'' % (keyPath, newKeyPath))

	for child in node.childNodes:
		change_other(child, idmap, customclass)
	pass

def confuse_storyboard_file(work_dir, bundle_id, main_project_file, target_name, configure, product_type, product_file, install_dir, project_file, product_target_name, src_file, ref_folder):
	print('##confuse storyboard file %s##' % src_file)
	confuse_utils.dbfile_lock()
	dst_file = confuse_utils.get_file_rename(work_dir, bundle_id, src_file)
	confuse_utils.dbfile_unlock()
	if not os.path.exists(dst_file):
		print('warning:not found %s' % dst_file)
		return

	back_file = dst_file + '.back'
	if os.path.exists(back_file):
		if os.path.exists(dst_file):
			os.remove(dst_file)
		os.rename(back_file, dst_file)
	shutil.copyfile(dst_file, back_file)
	
	confuse_utils.dbfile_lock()
	global default_module

	global confuse_xib_string

	confuse_xib_string = confuse_utils.get_run_settings_value(work_dir, bundle_id, 'xib-string-encode', False)

	build_settings = confuse_utils.get_build_settings(work_dir, bundle_id, project_file, configure, product_target_name, use_cache_file=True)
	default_module = confuse_utils.get_build_settings_value(build_settings, 'PRODUCT_MODULE_NAME', '')
	idmap = confuse_utils.get_all_rename_map(work_dir, bundle_id)
	confuse_utils.dbfile_unlock()
	with open(dst_file, 'r') as fin:
		dom = xml.dom.minidom.parse(fin)
		fin.close()
		os.remove(dst_file)
		change_other(dom.documentElement, idmap, ' ')
		change_class(dom.documentElement, idmap, ' ')

		with open(dst_file, 'w') as fout:
			dom.writexml(fout, encoding='utf-8')
			fout.close()

	os.remove(back_file)
	pass

def main(argv):
	if len(argv) != 13:
		print('python confuse_storyboard_file.py [work dir] [bundle id] [main project file] [target name] [configure] [product type] [product file] [install dir] [project file] [product target name] [src file] [ref folder]')
		sys.exit(1)
	confuse_storyboard_file(argv[1], argv[2], argv[3], argv[4], argv[5], argv[6], argv[7], argv[8], argv[9], argv[10], argv[11], argv[12])
	
main(sys.argv)