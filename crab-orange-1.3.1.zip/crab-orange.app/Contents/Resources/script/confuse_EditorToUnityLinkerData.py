#!/usr/bin/python
# -*- coding: UTF-8 -*-

import sys
import os
import confuse_utils
import json
import shutil

def get_class_name(name, idmap):
	key_name = '%s<U3DClass>' % name
	if key_name in idmap:
		#print 'found %s' % idmap[key_name]
		return idmap[key_name]
	return name

def rename_scene(work_dir, bundle_id, filename, idmap):
	paths = filename.split('/')
	if len(paths):
		items = paths[-1].split('.')
		name = items[0]
		items[0] = get_class_name(items[0], idmap)
		if items[0] == name:
			items[0] = confuse_utils.new_resource_name(work_dir, bundle_id, name)
		paths[-1] = '.'.join(items)
		return '/'.join(paths)
	return filename

def rename_native_class(name, idmap):
	return get_class_name(name, idmap)

def rename_full_managed_type_name(name, idmap):
	items = name.split('.')

	if len(items):
		for i in range(0,len(items)):
			items[i] = get_class_name(items[i], idmap)
		return '.'.join(items)
	return name

def rename_module_name(name, idmap):
	return name

def get_rel_file_name(name, app_dir):
	return os.path.relpath(name, app_dir)

def confuse_EditorToUnityLinkerData(work_dir, bundle_id, main_project_file, configure, target_name, product_type, install_dir, product_file, project_file, product_target_name, filename, ref_folder):
	if not os.path.exists(filename):
		return
	print('##confuse %s EditorToUnityLinkerData.json##' % (target_name))
	package_dir = '%s/packages/%s' % (work_dir, bundle_id)
	archive_path = '%s/%s.xcarchive' % (package_dir, target_name)
	new_target_name = confuse_utils.get_symbol_new_name(work_dir, bundle_id, target_name, 'target')

	#back_filename = filename + '.back'
	#if os.path.exists(back_filename):
	#	if os.path.exists(filename):
	#		os.remove(filename)
	#	os.rename(back_filename, filename)
	#shutil.copyfile(filename, back_filename)
	
	app_dir = '%s/Products/Applications/%s' % (archive_path, product_file)
	name = confuse_utils.get_file_name(filename)
	oldfilename = '%s/%s%s.json' % (app_dir, '%s/' % ref_folder if len(ref_folder) else '', name)
	newfilename = '%s/%s%s.cp.json' % (app_dir, '%s/' % ref_folder if len(ref_folder) else '', name)

	f = open(filename, 'r')
	jsonDict = json.loads(f.read())
	f.close()

	shutil.copyfile(filename, newfilename)

	#confuse_utils.dbfile_lock()
	idmap = confuse_utils.get_all_rename_map(work_dir, bundle_id)
	#confuse_utils.dbfile_unlock()
	#print idmap

	typesInScenes = jsonDict['typesInScenes']
	for typesInScene in typesInScenes:
		nativeClass = typesInScene['nativeClass']
		typesInScene['nativeClass'] = rename_native_class(nativeClass, idmap)
		fullManagedTypeName = typesInScene['fullManagedTypeName']
		typesInScene['fullManagedTypeName'] = rename_full_managed_type_name(fullManagedTypeName, idmap)
		moduleName = typesInScene['moduleName']
		typesInScene['moduleName'] = rename_module_name(moduleName, idmap)
		usedInScenes = typesInScene['usedInScenes']
		for i in range(0, len(usedInScenes)):
			usedInScene = usedInScenes[i]
			usedInScenes[i] = rename_scene(work_dir, bundle_id, usedInScene, idmap)
	
	allNativeTypes = jsonDict['allNativeTypes']
	for nativeType in allNativeTypes:
		name = nativeType['name']
		nativeType['name'] = rename_native_class(name, idmap)
		baseName = nativeType['baseName']
		nativeType['baseName'] = rename_native_class(baseName, idmap)

	#print 'old filename :%s' % oldfilename
	f = open(oldfilename, 'w')
	f.write(json.dumps(jsonDict, indent=4))
	f.close()


	#confuse_utils.dbfile_lock()
	confuse_utils.add_path_to_map(work_dir, bundle_id, target_name, get_rel_file_name(oldfilename, app_dir), get_rel_file_name(newfilename, app_dir), confuse_utils.PathType_Ruote)
	#confuse_utils.dbfile_unlock()
	#os.rename(oldfilename + '.tmp', oldfilename)
	#os.exit(1)
	pass

def main(argv):
	confuse_utils.print_cmd(argv)
	if len(argv) != 13:
		print('python confuse_EditorToUnityLinkerData.py [work dir] [bundle id] [main project file]  [configure] [target name] [product type] [product file] [install dir] [project file] [product target name] [src file] [ref folder]')
		sys.exit(1)
	confuse_EditorToUnityLinkerData(argv[1], argv[2], argv[3], argv[4], argv[5], argv[6], argv[7], argv[8], argv[9], argv[10], argv[11], argv[12])

main(sys.argv)
