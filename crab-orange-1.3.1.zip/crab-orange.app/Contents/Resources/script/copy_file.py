#!/usr/bin/python
# -*- coding: UTF-8 -*-

import sys
import os
import shutil

def copy_file(src_file, dst_file):
	dst_dir = os.path.dirname(dst_file)
	if not os.path.exists(dst_dir):
		os.makedirs(dst_dir)
	if os.path.isdir(src_file):
		if os.path.exists(dst_file):
			shutil.rmtree(dst_file)
		shutil.copytree(src_file, dst_file)
	else:
		shutil.copyfile(src_file, dst_file)
	pass

def main(argv):
	if len(argv) != 3:
		print('python copy_file.py [src file] [dst file]')
		return
	copy_file(argv[1], argv[2])
	
main(sys.argv)