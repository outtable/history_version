#!/usr/bin/python
# -*- coding: UTF-8 -*-

import sys
import os
import confuse_utils
import shutil

def clean_symbols(work_dir, bundle_id, main_bundle_id):
	print('##clean symbols %s##' % bundle_id)
	clear_derived_data = confuse_utils.get_run_settings_value(work_dir, bundle_id, 'clear-derived-data', True)
	tmpdir = confuse_utils.get_xcode_derived_data_dir()
	if clear_derived_data:
		count = 0
		while os.path.exists(tmpdir):
			if count > 5:
				print('删除目录%s失败了.' % tmpdir)
				sys.exit(1)
				break
			try:
				shutil.rmtree(tmpdir)
				pass
			except Exception as e:
				pass
			count = count + 1
		pass

	ncdir = tmpdir + '/ModuleCache.noindex'
	if os.path.exists(ncdir) == False:
		os.makedirs(ncdir)

	mvf = '%s/Session.modulevalidation' % ncdir
	if os.path.exists(mvf) == False:
		with open(mvf, 'w') as f:
			f.write('Module build session file for module cache at %s/ModuleCache.noindex' % tmpdir)
			f.close()

	confuse_utils.clean_symbols(work_dir, bundle_id, False)
	confuse_utils.clean_symbol_renames(work_dir, bundle_id, False)
	confuse_utils.clean_constants(work_dir, bundle_id, False)
	confuse_utils.clean_constant_new_values(work_dir, bundle_id, False)
	confuse_utils.clean_file_renames(work_dir, bundle_id, False)
	confuse_utils.clean_strings(work_dir, bundle_id, False)
	confuse_utils.clean_tags(work_dir, bundle_id, False)
	confuse_utils.clean_path_map(work_dir, bundle_id, False)
	confuse_utils.mark_warnings(work_dir, bundle_id, False)
	confuse_utils.clean_backup_files(work_dir, bundle_id, False)
	confuse_utils.clean_temp_files(work_dir, bundle_id, False)
	confuse_utils.copy_warnings(work_dir, bundle_id, main_bundle_id, False)
	confuse_utils.copy_match_strings(work_dir, bundle_id, main_bundle_id, False)
	confuse_utils.clean_configs(work_dir, bundle_id)
	pass

def main(argv):
	confuse_utils.print_cmd(argv)
	if len(argv) != 4:
		print('python clean_symbols.py [work dir] [bundle id] [main bundle id]')
		sys.exit(1)
	clean_symbols(argv[1], argv[2], argv[3])
	
main(sys.argv)