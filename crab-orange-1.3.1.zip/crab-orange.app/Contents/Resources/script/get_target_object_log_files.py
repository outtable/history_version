#!/usr/bin/python
# -*- coding: UTF-8 -*-

import sys
import os
import confuse_utils
import json
import importlib

importlib.reload(sys)

#sys.setdefaultencoding('utf-8')

def get_target_object_log_files(work_dir, bundle_id, configure, arch, target_name, product_type, project_file, product_target_name, src_file):
	project_name = confuse_utils.get_file_name(project_file)
	package_dir = '%s/packages/%s' % (work_dir, bundle_id)
	confuse_utils.dbfile_lock()
	new_target_name = confuse_utils.get_symbol_new_name(work_dir, bundle_id, target_name, 'target')
	confuse_utils.dbfile_unlock()
	env_file_name = '%s/%s_environment_variables.txt' % (package_dir, target_name)
	envs = confuse_utils.read_properties_file(env_file_name)
	filename = confuse_utils.get_file_name(src_file)
	objc_root = envs['OBJROOT']
	effective_platform_name = envs['EFFECTIVE_PLATFORM_NAME']
	path1 = '%s/%s.build/%s%s/%s.build/Objects-normal/%s/%s.o.metadata.dump.txt' % (objc_root, project_name, configure, effective_platform_name, product_target_name, arch, filename)
	path2 = '%s/%s.build/%s%s/%s.build/Objects-normal/%s/%s.o.tmp.metadata.dump.txt' % (objc_root, project_name, configure, effective_platform_name, product_target_name, arch, filename)
	jsonDict = {}
	if os.path.exists(path1):
		jsonDict['original.metadata.dump.txt'] = path1
	if os.path.exists(path2):
		jsonDict['confused.metadata.dump.txt'] = path2
	print(json.dumps(jsonDict,ensure_ascii=False))
	pass

def main(argv):
	if len(argv) != 10:
		print('python get_target_object_log_files.py [work dir] [bundle id] [configure] [arch] [target name] [product type] [project file] [product target name] [src file]')
		sys.exit(1)
	get_target_object_log_files(argv[1], argv[2], argv[3], argv[4], argv[5], argv[6], argv[7], argv[8], argv[9])
	
main(sys.argv)