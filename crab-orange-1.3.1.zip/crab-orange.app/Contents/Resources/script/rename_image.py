#!/usr/bin/python
# -*- coding: UTF-8 -*-

import sys
import os
import confuse_utils
import time
import json
import importlib

importlib.reload(sys)
#sys.setdefaultencoding('utf-8')

def rename_image(work_dir, bundle_id, main_project_file, target_name, configure, product_type, product_file, install_dir, project_file, product_target_name, src_files, ref_folders):
	confuse_utils.begin_transaction(work_dir, bundle_id)
	for i in range(0, len(src_files)):
		src_file = src_files[i]
		ref_folder = ref_folders[i]
		new_src_file = confuse_utils.get_file_rename(work_dir, bundle_id, src_file, close_connection = False)
		if confuse_utils.get_full_file_name(new_src_file) != confuse_utils.get_full_file_name(src_file):
			continue
		print('rename image %s' % (src_file))
		name = confuse_utils.get_file_name(src_file)
		file_extension = confuse_utils.get_file_extension(src_file)

		scaleIndex = name.rfind('@')
		scaleValue = ''
		if scaleIndex != -1:
			scaleValue = name[scaleIndex + 1:]
			name = name[:scaleIndex]

		newname = confuse_utils.new_constant_value(work_dir, bundle_id, name, "image", None, close_connection = False)
		confuse_utils.add_path_to_map(work_dir, bundle_id, product_target_name, name, newname, confuse_utils.PathType_ImageName, False)
		
		path = '%s.%s' % (name, file_extension)
		new_path = '%s.%s' % (newname, file_extension)

		if scaleIndex != -1:
			path = '%s@%s.%s' % (name, scaleValue, file_extension)
			new_path = '%s@%s.%s' % (newname, scaleValue, file_extension)

		if len(ref_folder):
			path = '%s/%s' % (ref_folder, path)
			new_path = '%s/%s' % (ref_folder, new_path)

		if product_type == '.framework':
			path = 'Frameworks/%s.framework/%s' % (product_target_name, path)
			new_path = 'Frameworks/%s.framework/%s' % (product_target_name, new_path)
		elif product_type == '.bundle':
			path = '%s/%s' % (product_file, path)
			new_path = '%s/%s' % (product_file, new_path)
		
		confuse_utils.add_path_to_map(work_dir, bundle_id, product_target_name, name, newname, close_connection = False)
		confuse_utils.add_path_to_map(work_dir, bundle_id, product_target_name, path, new_path, close_connection = False)
		confuse_utils.new_constant_value(work_dir, bundle_id, '%s.%s' % (name, file_extension), 'image', '%s.%s' % (newname, file_extension), close_connection = False)
		if len(ref_folder):
			confuse_utils.new_constant_value(work_dir, bundle_id, '%s.%s' % (name, file_extension), 'image', '%s/%s.%s' % (ref_folder, newname, file_extension), close_connection = False)

		if scaleIndex != -1:
			confuse_utils.add_path_to_map(work_dir, bundle_id, product_target_name, '%s@%dx' % (name, scaleIndex), '%s@%dx' % (newname, scaleIndex), confuse_utils.PathType_ImageName, False)
			confuse_utils.new_constant_value(work_dir, bundle_id, '%s@%s.%s' % (name, scaleValue, file_extension), 'image', '%s@%s.%s' % (newname, scaleValue, file_extension), close_connection = False)
			confuse_utils.new_constant_value(work_dir, bundle_id, '%s@%s' % (name, scaleValue), 'image', '%s@%s' % (newname, scaleValue), close_connection = False)

			if len(ref_folder):
				confuse_utils.new_constant_value(work_dir, bundle_id, '%s@%s.%s' % (name, scaleValue, file_extension), 'image', '%s/%s@%s.%s' % (ref_folder, newname, scaleValue, file_extension), close_connection = False)
				confuse_utils.new_constant_value(work_dir, bundle_id, '%s@%s' % (name, scaleValue), 'image', '%s/%s@%s' % (ref_folder, newname, scaleValue), close_connection = False)

		#添加一个需要更名的文件
		dir_name = confuse_utils.get_file_dir(src_file)
		dst_file = dir_name + '/' + newname

		if scaleIndex != -1:
			dst_file = dst_file + '@' + scaleValue

		dst_file = dst_file + '.' + file_extension
		confuse_utils.add_file_rename(work_dir, bundle_id, src_file, dst_file, False)
	confuse_utils.commit_transaction()
	pass

def main(argv):
	confuse_utils.print_cmd(argv)
	if len(argv) != 13:
		print('python rename_image.py [work dir] [bundle id] [main project file] [target name] [configure] [product type] [product file] [install dir] [project file] [product target name] [src files] [ref folders]')
		sys.exit(1)
	rename_image(argv[1], argv[2], argv[3], argv[4], argv[5], argv[6], argv[7], argv[8], argv[9], argv[10], confuse_utils.load_array_file(argv[11]), confuse_utils.load_array_file(argv[12]))
main(sys.argv)